
#include "DSP2833x_Project.h"
#include "DSP2833x_Device.h"   
#include "DSP2833x_Examples.h"  
#include "math.h"


#define	EPWM1_TIMER_TBPRD		2500/1.5

#define set_Kp                  1.2
#define set_Ki                  1.3
#define set_Kd                  0.7
#define set_speed               15
#define AD7606_SCK_LOW				    GpioDataRegs.GPACLEAR.bit.GPIO25=1;
#define AD7606_SCK_HIGH					GpioDataRegs.GPASET.bit.GPIO25=1;												

#define AD7606_RST_LOW				    GpioDataRegs.GPACLEAR.bit.GPIO27=1;
#define AD7606_RST_HIGH					GpioDataRegs.GPASET.bit.GPIO27=1;												

#define AD7606_CNVST_LOW				GpioDataRegs.GPACLEAR.bit.GPIO24=1;
#define AD7606_CNVST_HIGH				GpioDataRegs.GPASET.bit.GPIO24=1;												

#define AD7606_SCS_LOW				    GpioDataRegs.GPBCLEAR.bit.GPIO61=1;
#define AD7606_SCS_HIGH					GpioDataRegs.GPBSET.bit.GPIO61=1;												

#define AD7606_BUSY_READ                GpioDataRegs.GPADAT.bit.GPIO26
#define AD7606_DOUTA_READ               GpioDataRegs.GPBDAT.bit.GPIO60
#define AD7606_DOUTB_READ               GpioDataRegs.GPBDAT.bit.GPIO32 

struct _pid_parameters
{
	double setspeed;          //�����趨ֵ
	double actualspeed;       //����ʵ��ֵ
	double err;               //����ƫ��ֵ
	double err_next;          //������һ��ƫ��ֵ
	double err_last;          //��������ǰ��ƫ��ֵ
	float Kp,Ki,Kd;          //������������֡�΢��ϵ��
	double incermentspeed;
	
}pid;


void PID_init(void);
void PID_realize(void);
void configtestled(void);
int DOUT[8]; 
float AdcSample[8];

float CH1_Sample[10];
float CH2_Sample[10];
/*float CH3_Sample[240];
float CH4_Sample[240];
float CH5_Sample[240];
float CH6_Sample[240];
float CH7_Sample[240];
float CH8_Sample[240]; */
Uint16 adc_cnt=0;
int conv_flg=0;
double CH1  = 0;
float CH = 0;
double sum  = 0;
float DC_feedback = 0;
float DC_output = 0;

void InitEPwm2Example(void);
void InitEPwm1Example(void);
interrupt void epwm1_timer_isr(void);


float m = 0;
float pm = 0;
Uint32 k1;
Uint32 k2;

void AD7606ReadOneSample(int * buf)
{
	unsigned char j, k;
	unsigned short int TempA, TempB;
	AD7606_CNVST_LOW;
	DELAY_US(10);
	AD7606_CNVST_HIGH;
	DELAY_US(1);
	while(AD7606_BUSY_READ==1)
	{
	}
	AD7606_SCS_LOW;
	for(j=0; j<4; j++)
	{
		TempA=0;
		TempB=0;

		for(k=0; k<16; k++)
		{
			AD7606_SCK_LOW;

			TempA=(TempA<<1) + AD7606_DOUTA_READ;
			//TempB=(TempB<<1) + AD7606_DOUTB_READ;

			AD7606_SCK_HIGH;
		}
		
		buf[j]=(int)TempA;
		buf[4+j]=(int)TempB;

	} 
	AD7606_SCS_HIGH;
	conv_flg=1;

} 


void AD7606Reset(void)
{
	AD7606_RST_HIGH;
	DELAY_US(1000);
	AD7606_RST_LOW;
	DELAY_US(1000);
}

void main(void)
{
int i;

   // Step 1. Initialize System Control:
// PLL, WatchDog, enable Peripheral Clocks
// This example function is found in the DSP2833x_SysCtrl.c file.
   InitSysCtrl();
// Step 2. Initalize GPIO:
// This example function is found in the DSP2833x_Gpio.c file and
// illustrates how to set the GPIO to it's default state.
// InitGpio();  // Skipped for this example

// For this case just init GPIO pins for ePWM1, ePWM2, ePWM3
// These functions are in the DSP2833x_EPwm.c file

   InitEPwm1Gpio();    // ����gpio
   InitEPwm2Gpio();
   //InitEPwm3Gpio();
   //InitEPwm4Gpio();

   InitXintf16Gpio();	//zq
// Step 3. Clear all interrupts and initialize PIE vector table:
// Disable CPU interrupts
   DINT;

// Initialize the PIE control registers to their default state.
// The default state is all PIE interrupts disabled and flags
// are cleared.
// This function is found in the DSP2833x_PieCtrl.c file.
   InitPieCtrl();

// Disable CPU interrupts and clear all CPU interrupt flags:
   IER = 0x0000;
   IFR = 0x0000;

// Initialize the PIE vector table with pointers to the shell Interrupt
// Service Routines (ISR).
// This will populate the entire table, even if the interrupt
// is not used in this example.  This is useful for debug purposes.
// The shell ISR routines are found in DSP2833x_DefaultIsr.c.
// This function is found in DSP2833x_PieVect.c.
   InitPieVectTable();
   EALLOW;  // This is needed to write to EALLOW protected registers
    PieVectTable.EPWM1_INT = &epwm1_timer_isr;
    //PieVectTable.TINT0 = &ISRTimer0;
   //PieVectTable.EPWM2_INT = &epwm2_timer_isr;
   //PieVectTable.EPWM3_INT = &epwm3_timer_isr;
   EDIS;    // This is needed to disable write to EALLOW protected registers
// Interrupts that are used in this example are re-mapped to
// ISR functions found within this file.
   InitCpuTimers();
// Step 4. Initialize all the Device Peripherals:
// This function is found in DSP2833x_InitPeripherals.c
// InitPeripherals();  // Not required for this example
  // ConfigCpuTimer(&CpuTimer0, 150, 500);
// For this example, only initialize the ePWM

   EALLOW;
   SysCtrlRegs.PCLKCR0.bit.TBCLKSYNC = 0;
   EDIS;
   PID_init();
   InitEPwm1Example();  
   InitEPwm2Example();
   //InitEPwm3Example();
   configtestled();
   AD7606Reset();


   EALLOW;
   SysCtrlRegs.PCLKCR0.bit.TBCLKSYNC = 1;
   EDIS;

   IER |= M_INT3;

// Enable EPWM INTn in the PIE: Group 3 interrupt 1-3


    PieCtrlRegs.PIEIER3.bit.INTx1 = 1;
   //PieCtrlRegs.PIEIER3.bit.INTx2 = 1;
  // PieCtrlRegs.PIEIER3.bit.INTx3 = 1;


// Enable global Interrupts and higher priority real-time debug events:
   EINT;   // Enable Global interrupt INTM
   ERTM;   // Enable Global realtime interrupt DBGM

// Step 6. IDLE loop. Just sit and loop forever (optional):
    for(;;)
   {
       if(conv_flg==1)
	   {  
	      for(i=0;i<8;i++)
	         AdcSample[i] = (20.0/65536.0)* DOUT[i];//������ת��Ϊģ����,���뷶Χ������10V,����Ϊ16λ
			                                //�൱�ڽ�20V�ֳ���65536��,��ʽΪA=(20.0/65536.0)*D;AΪģ����ֵ��DΪ������ֵ;
			                                //������뷶Χ������5V��ʽΪA=(10.0/65536.0)*D
		  conv_flg=0; 
		   //CH1_Sample[0] = 0;


		  CH1_Sample[k2] = AdcSample[0];  //���ÿ��ͨ������ʷ��ֵ
		  CH2_Sample[k2] = AdcSample[1];
		  //CH3_Sample[adc_cnt] = AdcSample[2];
		  //CH4_Sample[adc_cnt] = AdcSample[3];
		  //CH5_Sample[adc_cnt] = AdcSample[4];
		  //CH6_Sample[adc_cnt] = AdcSample[5];
		 // CH7_Sample[adc_cnt] = AdcSample[6];
		  //CH8_Sample[adc_cnt] = AdcSample[7];	   
		  sum = sum+CH1_Sample[k2];
		  //adc_cnt++;
		  /*if(adc_cnt > 2) 
		     {
		     	adc_cnt = 0;
		     	CH =1.0/3.0*CH1;
		     	CH1 = 0;
		     	AC_rms_feedback = CH*10;
		     	PID_realize();
		     }	*/
	   }  
   }
}

void PID_init()
{
	pid.setspeed = 0.0;
	pid.actualspeed = 0.0;
	pid.err = 0.0;
	pid.err_last = 0.0;
	pid.err_next = 0.0;
	pid.Kp = set_Kp;
	pid.Ki = set_Ki;
	pid.Kd = set_Kd;
}
void PID_realize()
{
	pid.actualspeed = DC_feedback;
	pid.setspeed = set_speed;
	pid.err = pid.setspeed-pid.actualspeed;
	pid.incermentspeed = pid.Kp*(pid.err-pid.err_next)+pid.Ki*pid.err+pid.Kd*(pid.err-2*pid.err_next+pid.err_last);
	pid.actualspeed = pid.actualspeed+pid.incermentspeed;
	pid.err_last = pid.err_next;
	pid.err_next = pid.err;
	DC_output = pid.actualspeed;
	if(DC_output<=0)
	DC_output = 0;
}

interrupt void epwm1_timer_isr(void)
{
   if(k1>=5)
   {

   		k1 = 0;
   		AD7606ReadOneSample(DOUT);
   	 if(k2 >=10)
        {       k2 = 0;
            	CH =sum/10;
		     	sum = 0;
		     	DC_feedback = (CH)*4.5+3;
		     	PID_realize();
		     	 m = DC_output/69/2.5;
                if(m<0)
                 m = 0;
               if(m>0.29)
               m = 0.29;
               pm = m;
        }

   	k2++;
   }
    k1++;

   EPwm1Regs.CMPA.half.CMPA = 2*pm*EPWM1_TIMER_TBPRD;
   EPwm2Regs.CMPA.half.CMPA = (1-2*pm)*EPWM1_TIMER_TBPRD;


   EPwm1Regs.ETCLR.bit.INT = 1;
   PieCtrlRegs.PIEACK.all = PIEACK_GROUP3;

}

void InitEPwm1Example()
{
 // Setup TBCLK
   EPwm1Regs.TBCTL.bit.CTRMODE = 0x2; //    �ϼ���
   EPwm1Regs.TBPRD = EPWM1_TIMER_TBPRD;       // Set timer period  EPWM1_TIMER_TBPRD=6250
   EPwm1Regs.TBCTL.bit.PHSEN = 0x0;    // Disable phase loading
   EPwm1Regs.TBPHS.half.TBPHS = 0x0000;       // Phase is 0
   EPwm1Regs.TBCTR = 0x0000;                  // Clear counter
   EPwm1Regs.TBCTL.bit.HSPCLKDIV = 0;   // TBCLK= SYSCLKOUT
   EPwm1Regs.TBCTL.bit.CLKDIV = 0;
   
   EPwm1Regs.ETSEL.bit.SOCAEN = 1;        // Enable SOC on A group
   EPwm1Regs.ETSEL.bit.SOCASEL = 1;       // Select SOC from from TBCTR = 0;
   EPwm1Regs.ETPS.bit.SOCAPRD = 1;        // Generate pulse on 1st event

   // Setup shadow register load on ZERO
   EPwm1Regs.CMPCTL.bit.SHDWAMODE = 0x0;
   EPwm1Regs.CMPCTL.bit.SHDWBMODE = 0x0;
   EPwm1Regs.CMPCTL.bit.LOADAMODE = 0x0;
   EPwm1Regs.CMPCTL.bit.LOADBMODE = 0x0;
   EPwm1Regs.DBCTL.all=0xb;          // EPWMxB is inverted
   EPwm1Regs.DBRED=0;
   EPwm1Regs.DBFED=0;
   EPwm1Regs.CMPA.half.CMPA = m*2*EPWM1_TIMER_TBPRD;    // Set compare A value
   EPwm1Regs.CMPB = 0;           // Set Compare B value
   // St actions
   EPwm1Regs.AQCTLA.bit.ZRO = 0x2;          // Clear PWM1A on event A, up count
   EPwm1Regs.AQCTLA.bit.CAU = 0x1;
   //EPwm1Regs.AQCTLB.bit.ZRO = 0x2;          // Clear PWM1A on event A, up count
  // EPwm1Regs.AQCTLA.bit.CAU = 0x1;
  // EPwm1Regs.AQCTLB.bit.ZRO = 0x2;            // Set PWM1B on Zero
   EPwm1Regs.AQCTLB.all = 0;          // Clear PWM1B on event B, up count
   // Interrupt where we will change the Compare Values
   EPwm1Regs.ETSEL.bit.INTSEL = 0x2;     // Select INT on Zero event
   EPwm1Regs.ETSEL.bit.INTEN = 1;                // Enable INT
   EPwm1Regs.ETPS.bit.INTPRD = 0x1;           // Generate INT on 1rd event
}
void InitEPwm2Example()
{
   // Setup TBCLK
   EPwm2Regs.TBCTL.bit.CTRMODE = 0x2; //    ���¼���
   EPwm2Regs.TBPRD = EPWM1_TIMER_TBPRD;       // Set timer period  EPWM1_TIMER_TBPRD=6250
   EPwm2Regs.TBCTL.bit.PHSEN = 0x0;    // Disable phase loading
   EPwm2Regs.TBPHS.half.TBPHS = 0x0000;       // Phase is 0
   EPwm2Regs.TBCTR = 0x0000;                  // Clear counter
   EPwm2Regs.TBCTL.bit.HSPCLKDIV = 0;   // TBCLK= SYSCLKOUT
   EPwm2Regs.TBCTL.bit.CLKDIV = 0;
   // Setup shadow register load on ZERO
   EPwm2Regs.CMPCTL.bit.SHDWAMODE = 0x0;
   EPwm2Regs.CMPCTL.bit.SHDWBMODE = 0x0;
   EPwm2Regs.CMPCTL.bit.LOADAMODE = 0x0;
   EPwm2Regs.CMPCTL.bit.LOADBMODE = 0x0;
   EPwm2Regs.DBCTL.all=0xb;          // EPWMxB is inverted
   EPwm2Regs.DBRED=0;
   EPwm2Regs.DBFED=0;

   // Set actions
   EPwm2Regs.AQCTLA.bit.PRD = 0x2;          // Clear PWM1A on event A, up count
   EPwm2Regs.AQCTLA.bit.CAD = 0x1;

  // EPwm1Regs.AQCTLB.bit.ZRO = 0x2;            // Set PWM1B on Zero
   EPwm2Regs.AQCTLB.all = 0;          // Clear PWM1B on event B, up count

   // Interrupt where we will change the Compare Values
   EPwm2Regs.ETSEL.bit.INTSEL = 0x1;     // Select INT on Zero event
   EPwm2Regs.ETSEL.bit.INTEN = 1;                // Enable INT
   EPwm2Regs.ETPS.bit.INTPRD = 0x1;           // Generate INT on 1rd event

   EPwm2Regs.CMPA.half.CMPA = (1-m*2)*EPWM1_TIMER_TBPRD;    // Set compare A value
   EPwm2Regs.CMPB = 0;              // Set Compare B value
}
void configtestled(void)
{
   EALLOW;
   GpioCtrlRegs.GPAMUX2.bit.GPIO24 = 0; // GPIO0 = GPIO0
   GpioCtrlRegs.GPADIR.bit.GPIO24 = 1; 
   GpioCtrlRegs.GPAMUX2.bit.GPIO25 = 0; // GPIO1 = GPIO1
   GpioCtrlRegs.GPADIR.bit.GPIO25 = 1;
   GpioCtrlRegs.GPAMUX2.bit.GPIO27 = 0; // GPIO2 = GPIO2
   GpioCtrlRegs.GPADIR.bit.GPIO27 = 1;
   GpioCtrlRegs.GPBMUX2.bit.GPIO61 = 0; // GPIO3 = GPIO3
   GpioCtrlRegs.GPBDIR.bit.GPIO61 = 1;
   GpioCtrlRegs.GPAMUX2.bit.GPIO26 = 0; // GPIO4 = GPIO4
   GpioCtrlRegs.GPADIR.bit.GPIO26 = 0;
   GpioCtrlRegs.GPBMUX2.bit.GPIO60 = 0; // GPIO5 = GPIO5
   GpioCtrlRegs.GPBDIR.bit.GPIO60 = 0;
   GpioCtrlRegs.GPBMUX1.bit.GPIO32 = 0; // GPIO5 = GPIO5
   GpioCtrlRegs.GPBDIR.bit.GPIO32 = 0; 
   EDIS;
  AD7606_SCK_HIGH;
  AD7606_RST_HIGH;
  AD7606_CNVST_HIGH;
  AD7606_SCS_HIGH;
}
