#ifndef _PID_H_
#define _PID_H_
#include "stm32f10x.h"
void PID_init(void);
float PID_Ui(float  Acyual,float Outage); 
float PID_U0(float  Acyual,float Outage);
float PID_I1(float Acyual,float Outage);

void UIF_Get(void);
void UIF_Act(void);
#endif
