//2019.4.26�������   ��ӱ

//ע�⣡��
//ѧ��ʵ��ֻ������ P ��һ������

#include "DSP2833x_Project.h"
#include "math.h"
#include "DSP2833x_Device.h"   
#include "DSP2833x_Examples.h"  

#define P                 1  //Pȡֵ��Χ1~5
                                //P = 1ʱ f = 50Hz Uab = 24VΪ���ѹ

#define	EPWM_TBPRD		   6250/2*P//Ƶ�ʲ����������ѹƵ�� = 150*10^6/EPWM_TBPRD/480
#define m                  0.8*8/9/P  //��ѹֵ���������ѹ��ֵ = ֱ��ĸ�ߵ�ѹ*m/2
                                 
#define shuzu              480                                 
void InitEPwm1Example(void);
void InitEPwm2Example(void);
void InitEPwm3Example(void);

interrupt void epwm1_timer_isr(void);
interrupt void epwm2_timer_isr(void);
interrupt void epwm3_timer_isr(void);

Uint32 k=0;
Uint32 k1=0;
Uint32 k2=0;
Uint32 k3=0;


int32 TonC[shuzu]={      
                0,3,6,9,12,15,18,21,25,28,31,34,37,40,43,46,
49,52,56,59,62,65,68,71,74,77,80,83,86,88,91,94,
97,100,103,106,108,111,114,117,119,122,125,128,130,133,135,138,
141,143,146,148,151,153,155,158,160,162,165,167,169,171,174,176,
178,180,182,184,186,188,190,192,194,195,197,199,201,202,204,206,
207,209,210,212,213,215,216,217,219,220,221,222,224,225,226,227,
228,229,230,230,231,232,233,234,234,235,235,236,237,237,237,238,
238,238,239,239,239,239,239,239,240,239,239,239,239,239,239,238,
238,238,237,237,237,236,235,235,234,234,233,232,231,230,230,229,
228,227,226,225,224,222,221,220,219,217,216,215,213,212,210,209,
207,206,204,202,201,199,197,195,194,192,190,188,186,184,182,180,
178,176,174,171,169,167,165,162,160,158,155,153,151,148,146,143,
141,138,135,133,130,128,125,122,119,117,114,111,108,106,103,100,
97,94,91,88,86,83,80,77,74,71,68,65,62,59,56,52,
49,46,43,40,37,34,31,28,25,21,18,15,12,9,6,3,
0,-3,-6,-9,-12,-15,-18,-21,-25,-28,-31,-34,-37,-40,-43,-46,
-49,-52,-56,-59,-62,-65,-68,-71,-74,-77,-80,-83,-86,-88,-91,-94,
-97,-100,-103,-106,-108,-111,-114,-117,-119,-122,-125,-128,-130,-133,-135,-138,
-141,-143,-146,-148,-151,-153,-155,-158,-160,-162,-165,-167,-169,-171,-174,-176,
-178,-180,-182,-184,-186,-188,-190,-192,-194,-195,-197,-199,-201,-202,-204,-206,
-207,-209,-210,-212,-213,-215,-216,-217,-219,-220,-221,-222,-224,-225,-226,-227,
-228,-229,-230,-230,-231,-232,-233,-234,-234,-235,-235,-236,-237,-237,-237,-238,
-238,-238,-239,-239,-239,-239,-239,-239,-240,-239,-239,-239,-239,-239,-239,-238,
-238,-238,-237,-237,-237,-236,-235,-235,-234,-234,-233,-232,-231,-230,-230,-229,
-228,-227,-226,-225,-224,-222,-221,-220,-219,-217,-216,-215,-213,-212,-210,-209,
-207,-206,-204,-202,-201,-199,-197,-195,-194,-192,-190,-188,-186,-184,-182,-180,
-178,-176,-174,-171,-169,-167,-165,-162,-160,-158,-155,-153,-151,-148,-146,-143,
-141,-138,-135,-133,-130,-128,-125,-122,-119,-117,-114,-111,-108,-106,-103,-100,
-97,-94,-91,-88,-86,-83,-80,-77,-74,-71,-68,-65,-62,-59,-56,-52,
-49,-46,-43,-40,-37,-34,-31,-28,-25,-21,-18,-15,-12,-9,-6,-3
                 };
void main(void)
{
   // Step 1. Initialize System Control:
// PLL, WatchDog, enable Peripheral Clocks
// This example function is found in the DSP2833x_SysCtrl.c file.
   InitSysCtrl();
// Step 2. Initalize GPIO:
// This example function is found in the DSP2833x_Gpio.c file and
// illustrates how to set the GPIO to it's default state.
// InitGpio();  // Skipped for this example
// For this case just init GPIO pins for ePWM1, ePWM2, ePWM3
// These functions are in the DSP2833x_EPwm.c file
   InitEPwm1Gpio();    // ����gpio
   InitEPwm2Gpio();
   InitEPwm3Gpio();
// Step 3. Clear all interrupts and initialize PIE vector table:
// Disable CPU interrupts
   DINT;
// Initialize the PIE control registers to their default state.
// The default state is all PIE interrupts disabled and flags
// are cleared.
// This function is found in the DSP2833x_PieCtrl.c file.
   InitPieCtrl();
// Disable CPU interrupts and clear all CPU interrupt flags:
   IER = 0x0000;
   IFR = 0x0000;
// Initialize the PIE vector table with pointers to the shell Interrupt
// Service Routines (ISR).
// This will populate the entire table, even if the interrupt
// is not used in this example.  This is useful for debug purposes.
// The shell ISR routines are found in DSP2833x_DefaultIsr.c.
// This function is found in DSP2833x_PieVect.c.
   InitPieVectTable();
// Interrupts that are used in this example are re-mapped to
// ISR functions found within this file.
   EALLOW;  // This is needed to write to EALLOW protected registers
   PieVectTable.EPWM1_INT = &epwm1_timer_isr;
   //PieVectTable.EPWM2_INT = &epwm2_timer_isr;
  // PieVectTable.EPWM3_INT = &epwm3_timer_isr;
   EDIS;    // This is needed to disable write to EALLOW protected registers
// Step 4. Initialize all the Device Peripherals:
// This function is found in DSP2833x_InitPeripherals.c
// InitPeripherals();  // Not required for this example
// For this example, only initialize the ePWM
   EALLOW;
   SysCtrlRegs.PCLKCR0.bit.TBCLKSYNC = 0;
   EDIS;
   
   InitEPwm1Example();  
   InitEPwm2Example();
   InitEPwm3Example();

   EALLOW;
   SysCtrlRegs.PCLKCR0.bit.TBCLKSYNC = 1;
   EDIS;
// Step 5. User specific code, enable interrupts:
// Enable CPU INT3 which is connected to EPWM1-3 INT:
   IER |= M_INT3;
// Enable EPWM INTn in the PIE: Group 3 interrupt 1-3
   PieCtrlRegs.PIEIER3.bit.INTx1 = 1;
  // PieCtrlRegs.PIEIER3.bit.INTx2 = 1;
   //PieCtrlRegs.PIEIER3.bit.INTx3 = 1;
// Enable global Interrupts and higher priority real-time debug events:
   EINT;   // Enable Global interrupt INTM
   ERTM;   // Enable Global realtime interrupt DBGM
// Step 6. IDLE loop. Just sit and loop forever (optional):
   for(;;)
   {
       asm("          NOP");
   }
}

void InitEPwm1Example()
{
    // Setup TBCLK
   EPwm1Regs.TBCTL.bit.CTRMODE = 0x2; //    ���¼���  
   EPwm1Regs.TBPRD = EPWM_TBPRD;       // Set timer period  EPWM1_TIMER_TBPRD=6250
   EPwm1Regs.TBCTL.bit.PHSEN = 0x0;    // Disable phase loading
   EPwm1Regs.TBPHS.half.TBPHS = 0x0000;       // Phase is 0
   EPwm1Regs.TBCTR = 0x0000;                  // Clear counter
   EPwm1Regs.TBCTL.bit.HSPCLKDIV = 0;   // TBCLK= SYSCLKOUT
   EPwm1Regs.TBCTL.bit.CLKDIV = 0;
   // Setup shadow register load on ZERO
   EPwm1Regs.CMPCTL.bit.SHDWAMODE = 0x0;
   EPwm1Regs.CMPCTL.bit.SHDWBMODE = 0x0;
   EPwm1Regs.CMPCTL.bit.LOADAMODE = 0x0;
   EPwm1Regs.CMPCTL.bit.LOADBMODE = 0x0;
   EPwm1Regs.DBCTL.all=0xb;          // EPWMxB is inverted
   EPwm1Regs.DBRED=0;
   EPwm1Regs.DBFED=0;
   
   EPwm1Regs.CMPA.half.CMPA = 0.5*EPWM_TBPRD;    // Set compare A value
   EPwm1Regs.CMPB = 0;              // Set Compare B value
   // Set actions
   EPwm1Regs.AQCTLA.bit.CAU = 0x1;          // Clear PWM1A on event A, up count
   EPwm1Regs.AQCTLA.bit.CAD = 0x2; 
  // EPwm1Regs.AQCTLB.bit.ZRO = 0x2;            // Set PWM1B on Zero
   EPwm1Regs.AQCTLB.all = 0;          // Clear PWM1B on event B, up count
   // Interrupt where we will change the Compare Values
   EPwm1Regs.ETSEL.bit.INTSEL = 0x1;     // Select INT on Zero event
   EPwm1Regs.ETSEL.bit.INTEN = 1;                // Enable INT
   EPwm1Regs.ETPS.bit.INTPRD = 0x1;           // Generate INT on 1rd event
}
void InitEPwm2Example()
{
   // Setup TBCLK
   EPwm2Regs.TBCTL.bit.CTRMODE = 0x2; //    ���¼���  
   EPwm2Regs.TBPRD = EPWM_TBPRD;       // Set timer period  EPWM1_TIMER_TBPRD=6250
   EPwm2Regs.TBCTL.bit.PHSEN = 0x0;    // Disable phase loading
   EPwm2Regs.TBPHS.half.TBPHS = 0x0000;       // Phase is 0
   EPwm2Regs.TBCTR = 0x0000;                  // Clear counter
   EPwm2Regs.TBCTL.bit.HSPCLKDIV = 0;   // TBCLK= SYSCLKOUT
   EPwm2Regs.TBCTL.bit.CLKDIV = 0;
   // Setup shadow register load on ZERO
   EPwm2Regs.CMPCTL.bit.SHDWAMODE = 0x0;
   EPwm2Regs.CMPCTL.bit.SHDWBMODE = 0x0;
   EPwm2Regs.CMPCTL.bit.LOADAMODE = 0x0;
   EPwm2Regs.CMPCTL.bit.LOADBMODE = 0x0;
   EPwm2Regs.DBCTL.all=0xb;          // EPWMxB is inverted
   EPwm2Regs.DBRED=0;
   EPwm2Regs.DBFED=0;
   
   // Set actions
   EPwm2Regs.AQCTLA.bit.CAU = 0x1;          // Clear PWM1A on event A, up count
   EPwm2Regs.AQCTLA.bit.CAD = 0x2; 

  // EPwm1Regs.AQCTLB.bit.ZRO = 0x2;            // Set PWM1B on Zero
   EPwm2Regs.AQCTLB.all = 0;          // Clear PWM1B on event B, up count

   // Interrupt where we will change the Compare Values
   EPwm2Regs.ETSEL.bit.INTSEL = 0x1;     // Select INT on Zero event
   EPwm2Regs.ETSEL.bit.INTEN = 1;                // Enable INT
   EPwm2Regs.ETPS.bit.INTPRD = 0x1;           // Generate INT on 1rd event
   
   EPwm2Regs.CMPA.half.CMPA = 0.5*EPWM_TBPRD;    // Set compare A value
   EPwm2Regs.CMPB = 0;              // Set Compare B value
}
void InitEPwm3Example()
{
   // Setup TBCLK
   EPwm3Regs.TBCTL.bit.CTRMODE = 0x2; //    ���¼���  
   EPwm3Regs.TBPRD = EPWM_TBPRD;       // Set timer period  EPWM1_TIMER_TBPRD=6250
   EPwm3Regs.TBCTL.bit.PHSEN = 0x0;    // Disable phase loading
   EPwm3Regs.TBPHS.half.TBPHS = 0x0000;       // Phase is 0
   EPwm3Regs.TBCTR = 0x0000;                  // Clear counter
   EPwm3Regs.TBCTL.bit.HSPCLKDIV = 0;   // TBCLK= SYSCLKOUT
   EPwm3Regs.TBCTL.bit.CLKDIV = 0;
   // Setup shadow register load on ZERO
   EPwm3Regs.CMPCTL.bit.SHDWAMODE = 0x0;
   EPwm3Regs.CMPCTL.bit.SHDWBMODE = 0x0;
   EPwm3Regs.CMPCTL.bit.LOADAMODE = 0x0;
   EPwm3Regs.CMPCTL.bit.LOADBMODE = 0x0;
   EPwm3Regs.DBCTL.all=0xb;          // EPWMxB is inverted
   EPwm3Regs.DBRED=0;
   EPwm3Regs.DBFED=0;
   // Set actions
   EPwm3Regs.AQCTLA.bit.CAU = 0x1;          // Clear PWM1A on event A, up count
   EPwm3Regs.AQCTLA.bit.CAD = 0x2; 
  // EPwm1Regs.AQCTLB.bit.ZRO = 0x2;            // Set PWM1B on Zero
   EPwm3Regs.AQCTLB.all = 0;          // Clear PWM1B on event B, up count

   // Interrupt where we will change the Compare Values
   EPwm3Regs.ETSEL.bit.INTSEL = 0x1;     // Select INT on Zero event
   EPwm3Regs.ETSEL.bit.INTEN = 1;                // Enable INT
   EPwm3Regs.ETPS.bit.INTPRD = 0x1;           // Generate INT on 1rd event
   EPwm3Regs.CMPA.half.CMPA = 0.5*EPWM_TBPRD;    // Set compare A value
   EPwm3Regs.CMPB = 0;              // Set Compare B value
}
interrupt void epwm1_timer_isr(void)
{
   if(k >= shuzu)
   { 
   	  k = 0;
   }
   
   k1=k;
   if(k1>=shuzu)
   {
   	k1=k1-shuzu;
   }
   EPwm1Regs.CMPA.half.CMPA = EPWM_TBPRD*((1.0+m*TonC[k1]/240)/2);
   
   k2=k+shuzu/3;
   if(k2>=shuzu)
   {
   	  k2=k2-shuzu;
   }
   EPwm2Regs.CMPA.half.CMPA = EPWM_TBPRD*((1.0+m*TonC[k2]/240)/2);
   
   k3=k+2*shuzu/3;
   if(k3>=shuzu)
   {
   	  k3=k3-shuzu;
   }
   EPwm3Regs.CMPA.half.CMPA = EPWM_TBPRD*((1.0+m*TonC[k3]/240)/2);
   
   
   k++;
   
   EPwm1Regs.ETCLR.bit.INT = 1;
   PieCtrlRegs.PIEACK.all = PIEACK_GROUP3;
}

