
#include "DSP2833x_Project.h"
#include "math.h"
#include "DSP2833x_Device.h"   
#include "DSP2833x_Examples.h"  

#define	EPWM1_TIMER_TBPRD		6250		//50HZ
#define M                       0.6978
#define set_Kp                 0.5
#define set_Ki                 1.01
#define set_Kd                  1
#define set_speed               25	//�趨ֵ

float m = 0;

#define AD7606_SCK_LOW				    GpioDataRegs.GPACLEAR.bit.GPIO25=1;
#define AD7606_SCK_HIGH					GpioDataRegs.GPASET.bit.GPIO25=1;												

#define AD7606_RST_LOW				    GpioDataRegs.GPACLEAR.bit.GPIO27=1;
#define AD7606_RST_HIGH					GpioDataRegs.GPASET.bit.GPIO27=1;												

#define AD7606_CNVST_LOW				GpioDataRegs.GPACLEAR.bit.GPIO24=1;
#define AD7606_CNVST_HIGH				GpioDataRegs.GPASET.bit.GPIO24=1;												

#define AD7606_SCS_LOW				    GpioDataRegs.GPBCLEAR.bit.GPIO61=1;
#define AD7606_SCS_HIGH					GpioDataRegs.GPBSET.bit.GPIO61=1;												

#define AD7606_BUSY_READ                GpioDataRegs.GPADAT.bit.GPIO26
#define AD7606_DOUTA_READ               GpioDataRegs.GPBDAT.bit.GPIO60
#define AD7606_DOUTB_READ               GpioDataRegs.GPBDAT.bit.GPIO32 

struct _pid_parameters
{
	double setspeed;          //�����趨ֵ
	double actualspeed;       //����ʵ��ֵ
	double err;               //����ƫ��ֵ
	double err_next;          //������һ��ƫ��ֵ
	double err_last;          //��������ǰ��ƫ��ֵ
	float Kp,Ki,Kd;          //������������֡�΢��ϵ��
	double incermentspeed;
	
}pid;

void PID_init(void);
void PID_realize(void);
void configtestled(void);
int DOUT[8]; 
float AdcSample[8];

float CH1_Sample[240];
float CH2_Sample[240];
/*float CH3_Sample[240];
float CH4_Sample[240];
float CH5_Sample[240];
float CH6_Sample[240];
float CH7_Sample[240];
float CH8_Sample[240]; */
Uint16 adc_cnt=0;
int conv_flg=0;
float CH1  = 0;
float CH = 0;
float AC_rms;
float AC_rms_feedback = 0;

void InitEPwm1Example(void);

interrupt void epwm1_timer_isr(void);



extern Uint32 k=0;
extern Uint32 k1=0;
extern int32 TonC[240]={      
                    0,6,12,18,25,31,37,43,49,56,62,68,74,80,86,91,
97,103,108,114,119,125,130,135,141,146,151,155,160,165,169,174,
178,182,186,190,194,197,201,204,207,210,213,216,219,221,224,226,
228,230,231,233,234,235,237,237,238,239,239,239,240,239,239,239,
238,237,237,235,234,233,231,230,228,226,224,221,219,216,213,210,
207,204,201,197,194,190,186,182,178,174,169,165,160,155,151,146,
141,135,130,125,119,114,108,103,97,91,86,80,74,68,62,56,
49,43,37,31,25,18,12,6,0,-6,-12,-18,-25,-31,-37,-43,
-49,-56,-62,-68,-74,-80,-86,-91,-97,-103,-108,-114,-119,-125,-130,-135,
-141,-146,-151,-155,-160,-165,-169,-174,-178,-182,-186,-190,-194,-197,-201,-204,
-207,-210,-213,-216,-219,-221,-224,-226,-228,-230,-231,-233,-234,-235,-237,-237,
-238,-239,-239,-239,-240,-239,-239,-239,-238,-237,-237,-235,-234,-233,-231,-230,
-228,-226,-224,-221,-219,-216,-213,-210,-207,-204,-201,-197,-194,-190,-186,-182,
-178,-174,-169,-165,-160,-155,-151,-146,-141,-135,-130,-125,-119,-114,-108,-103,
-97,-91,-86,-80,-74,-68,-62,-56,-49,-43,-37,-31,-25,-18,-12,-6
                       };

void AD7606ReadOneSample(int * buf)
{
	unsigned char j, k;
	unsigned short int TempA, TempB;
	AD7606_CNVST_LOW;
	DELAY_US(10);
	AD7606_CNVST_HIGH;
	DELAY_US(1);
	while(AD7606_BUSY_READ==1)
	{
	}
	AD7606_SCS_LOW;
	for(j=0; j<4; j++)
	{
		TempA=0;
		TempB=0;

		for(k=0; k<16; k++)
		{
			AD7606_SCK_LOW;

			TempA=(TempA<<1) + AD7606_DOUTA_READ;
			//TempB=(TempB<<1) + AD7606_DOUTB_READ;

			AD7606_SCK_HIGH;
		}
		
		buf[j]=(int)TempA;
		buf[4+j]=(int)TempB;

	} 
	AD7606_SCS_HIGH;
	conv_flg=1;
} 


void AD7606Reset(void)
{
	AD7606_RST_HIGH;
	DELAY_US(1000);
	AD7606_RST_LOW;
	DELAY_US(1000);
}

void main(void)
{
   int i;
   // Step 1. Initialize System Control:
// PLL, WatchDog, enable Peripheral Clocks
// This example function is found in the DSP2833x_SysCtrl.c file.
   InitSysCtrl();
   InitXintf();
   
   EALLOW;
 //  SysCtrlRegs.HISPCP.all = ADC_MODCLK;	// HSPCLK = SYSCLKOUT/ADC_MODCLK
   EDIS;

   InitEPwm1Gpio();    // ����gpio
   //InitEPwm2Gpio();
  // InitEPwm3Gpio();

  InitXintf16Gpio();	//zq
// Step 3. Clear all interrupts and initialize PIE vector table:
// Disable CPU interrupts
   DINT;
   InitPieCtrl();

// Disable CPU interrupts and clear all CPU interrupt flags:
   IER = 0x0000;
   IFR = 0x0000;
   InitPieVectTable();

// Interrupts that are used in this example are re-mapped to
// ISR functions found within this file.
   EALLOW;  // This is needed to write to EALLOW protected registers
   PieVectTable.EPWM1_INT = &epwm1_timer_isr;
   //PieVectTable.EPWM2_INT = &epwm2_timer_isr;
   //PieVectTable.EPWM3_INT = &epwm3_timer_isr;
   EDIS;    // This is needed to disable write to EALLOW protected registers
   EALLOW;
   SysCtrlRegs.PCLKCR0.bit.TBCLKSYNC = 0;
   EDIS;

   PID_init();
   InitEPwm1Example();  
  // InitEPwm2Example();
  // InitEPwm3Example();
 // m = M;

   EALLOW;
   SysCtrlRegs.PCLKCR0.bit.TBCLKSYNC = 1;
   EDIS;
// Enable CPU INT3 which is connected to EPWM1-3 INT:
   IER |= M_INT3;
// Enable EPWM INTn in the PIE: Group 3 interrupt 1-3
   PieCtrlRegs.PIEIER3.bit.INTx1 = 1;
   //PieCtrlRegs.PIEIER3.bit.INTx2 = 1;
  // PieCtrlRegs.PIEIER3.bit.INTx3 = 1;
   configtestled();
   AD7606Reset();
// Enable global Interrupts and higher priority real-time debug events:
   EINT;   // Enable Global interrupt INTM
   ERTM;   // Enable Global realtime interrupt DBGM

// Step 6. IDLE loop. Just sit and loop forever (optional):
    for(;;)
   {
       if(conv_flg==1)
	   {  
	      for(i=0;i<8;i++)
	         AdcSample[i] = (20.0/65536.0)* DOUT[i];//������ת��Ϊģ����,���뷶Χ������10V,����Ϊ16λ
			                                //�൱�ڽ�20V�ֳ���65536��,��ʽΪA=(20.0/65536.0)*D;AΪģ����ֵ��DΪ������ֵ;
			                                //������뷶Χ������5V��ʽΪA=(10.0/65536.0)*D
		  conv_flg=0; 

		  CH1_Sample[k] = AdcSample[0];  //���ÿ��ͨ������ʷ��ֵ
		  CH2_Sample[k] = AdcSample[1];
		  //CH3_Sample[adc_cnt] = AdcSample[2];
		  //CH4_Sample[adc_cnt] = AdcSample[3];
		  //CH5_Sample[adc_cnt] = AdcSample[4];
		  //CH6_Sample[adc_cnt] = AdcSample[5];
		 // CH7_Sample[adc_cnt] = AdcSample[6];
		  //CH8_Sample[adc_cnt] = AdcSample[7];	   
		  CH1 = CH1+CH1_Sample[k];  
		  adc_cnt++;
		  /*if(adc_cnt > 2) 
		     {
		     	adc_cnt = 0;
		     	CH =1.0/3.0*CH1;
		     	CH1 = 0;
		     	AC_rms_feedback = CH*10;
		     	PID_realize();
		     }	*/
	   }  
   }
}

void PID_init()
{
	pid.setspeed = 0.0;
	pid.actualspeed = 0.0;
	pid.err = 0.0;
	pid.err_last = 0.0;
	pid.err_next = 0.0;
	pid.Kp = set_Kp;
	pid.Ki = set_Ki;
	pid.Kd = set_Kd;
}
void PID_realize()
{
	pid.actualspeed = AC_rms_feedback;
	pid.setspeed = set_speed;
	pid.err = pid.setspeed-pid.actualspeed;
	pid.incermentspeed = pid.Kp*(pid.err-pid.err_next)+pid.Ki*pid.err+pid.Kd*(pid.err-2*pid.err_next+pid.err_last);
	pid.actualspeed = pid.actualspeed+pid.incermentspeed;
	pid.err_last = pid.err_next;
	pid.err_next = pid.err;
	AC_rms = pid.actualspeed;
	if(AC_rms<=0)
	AC_rms = 0; 
}
void InitEPwm1Example()
{
    // Setup TBCLK
   EPwm1Regs.TBCTL.bit.CTRMODE = 0x2; //    ���¼���  
   EPwm1Regs.TBPRD = EPWM1_TIMER_TBPRD;       // Set timer period  EPWM1_TIMER_TBPRD=6250
   EPwm1Regs.TBCTL.bit.PHSEN = 0x0;    // Disable phase loading
   EPwm1Regs.TBPHS.half.TBPHS = 0x0000;       // Phase is 0
   EPwm1Regs.TBCTR = 0x0000;                  // Clear counter
   EPwm1Regs.TBCTL.bit.HSPCLKDIV = 0;   // TBCLK= SYSCLKOUT
   EPwm1Regs.TBCTL.bit.CLKDIV = 0;
   
   EPwm1Regs.ETSEL.bit.SOCAEN = 1;        // Enable SOC on A group
   EPwm1Regs.ETSEL.bit.SOCASEL = 1;       // Select SOC from from TBCTR = 0;
   EPwm1Regs.ETPS.bit.SOCAPRD = 1;        // Generate pulse on 1st event

   // Setup shadow register load on ZERO
   EPwm1Regs.CMPCTL.bit.SHDWAMODE = 0x0;
   EPwm1Regs.CMPCTL.bit.SHDWBMODE = 0x0;
   EPwm1Regs.CMPCTL.bit.LOADAMODE = 0x0;
   EPwm1Regs.CMPCTL.bit.LOADBMODE = 0x0;
   EPwm1Regs.DBCTL.all=0xb;          // EPWMxB is inverted
   EPwm1Regs.DBRED=0;
   EPwm1Regs.DBFED=0;
   EPwm1Regs.CMPA.half.CMPA = 0.7*EPWM1_TIMER_TBPRD;    // Set compare A value
   EPwm1Regs.CMPB = 0;              // Set Compare B value
   // Set actions
   EPwm1Regs.AQCTLA.bit.CAU = 0x1;          // Clear PWM1A on event A, up count
   EPwm1Regs.AQCTLA.bit.CAD = 0x2; 
  // EPwm1Regs.AQCTLB.bit.ZRO = 0x2;            // Set PWM1B on Zero
   EPwm1Regs.AQCTLB.all = 0;          // Clear PWM1B on event B, up count
   // Interrupt where we will change the Compare Values
   EPwm1Regs.ETSEL.bit.INTSEL = 0x2;     // Select INT on Zero event
   EPwm1Regs.ETSEL.bit.INTEN = 1;                // Enable INT
   EPwm1Regs.ETPS.bit.INTPRD = 0x1;           // Generate INT on 1rd event
}

interrupt void epwm1_timer_isr(void)
{
   if(k >= 240)
   {  k = 0;   
            	CH =1.0/240*CH1;
		     	CH1 = 0;
		     	AC_rms_feedback = CH*10;
		     	PID_realize();
   	 
   }
   m = AC_rms*1.4142135624/38.2;//55.6,����Ϊ����·�������ѹ
   if(m<0)
   m = 0;
   if(m>0.8)
   m = 0.8;
   EPwm1Regs.CMPA.half.CMPA = EPWM1_TIMER_TBPRD*((1.0+m*TonC[k]/240)/2);
   k++;
   EPwm1Regs.ETCLR.bit.INT = 1;
   PieCtrlRegs.PIEACK.all = PIEACK_GROUP3;
   AD7606ReadOneSample(DOUT);
}

void configtestled(void)
{
   EALLOW;
   GpioCtrlRegs.GPAMUX2.bit.GPIO24 = 0; // GPIO0 = GPIO0
   GpioCtrlRegs.GPADIR.bit.GPIO24 = 1; 
   GpioCtrlRegs.GPAMUX2.bit.GPIO25 = 0; // GPIO1 = GPIO1
   GpioCtrlRegs.GPADIR.bit.GPIO25 = 1;
   GpioCtrlRegs.GPAMUX2.bit.GPIO27 = 0; // GPIO2 = GPIO2
   GpioCtrlRegs.GPADIR.bit.GPIO27 = 1;
   GpioCtrlRegs.GPBMUX2.bit.GPIO61 = 0; // GPIO3 = GPIO3
   GpioCtrlRegs.GPBDIR.bit.GPIO61 = 1;
   GpioCtrlRegs.GPAMUX2.bit.GPIO26 = 0; // GPIO4 = GPIO4
   GpioCtrlRegs.GPADIR.bit.GPIO26 = 0;
   GpioCtrlRegs.GPBMUX2.bit.GPIO60 = 0; // GPIO5 = GPIO5
   GpioCtrlRegs.GPBDIR.bit.GPIO60 = 0;
   GpioCtrlRegs.GPBMUX1.bit.GPIO32 = 0; // GPIO5 = GPIO5
   GpioCtrlRegs.GPBDIR.bit.GPIO32 = 0; 
   EDIS;
  AD7606_SCK_HIGH;
  AD7606_RST_HIGH;
  AD7606_CNVST_HIGH;
  AD7606_SCS_HIGH;
}

