//########################################################
//
// FILE:   pfc100a_main.h
//
// TITLE:  pfc100a_main variables definitions.
//
//########################################################
// Running on TMS320LF280xA   PFC part h741Au1(1.00)
// External clock is 20MHz, PLL * 10/2 , CPU-Clock 100 MHz	                	
// Date: from May 23, 2005 to Oct 30, 2006  , (C) www & mhp & lsy & lyg    	
// Version:1.00     Change Date: May 23, 2005 , 					  	
//########################################################

//==========================================================================================

#ifndef main_h		// Header file guard
#define main_h		//�����ظ����ô�ͷ�ļ��ı�׼����czk060707


//==========================================================================================




/*------------�ṹ����-------------------------*/
#include "IQmathLib.h"
typedef	union 
{
	unsigned int id1 ;
	struct   packed_data1
	{
		 unsigned highchar1 : 8;
		 unsigned lowchar1  : 8;
	}bitdata1;                                                                                                    
}ubitint1 ;

typedef	union 
{
	unsigned int id ;
	struct   packed_data
	{
		 unsigned highchar : 8;
		 unsigned lowchar  : 8;
	}bitdata;                                                                                                    
}ubitint ;

typedef	union 
{
	float fd ;
	ubitint intdata[2]; 
	long	lData;  
}ubitfloat ;

struct DEF32_BITS
{         
       Uint16 B0:1;             // 0      BIT0   
       Uint16 B1:1;             // 1      BIT1 
       Uint16 B2:1;             // 2      BIT2 
       Uint16 B3:1;             // 3      BIT3    
       Uint16 B4:1;             // 4      BIT4 
       Uint16 B5:1;             // 5      BIT5 
       Uint16 B6:1;             // 6      BIT6    
       Uint16 B7:1;             // 7      BIT7 
       Uint16 B8:1;             // 8      BIT8 
       Uint16 B9:1;             // 9      BIT9    
       Uint16 B10:1;           // 10     BIT10 
       Uint16 B11:1;           // 11     BIT11       
       Uint16 B12:1;           // 12     BIT12 
       Uint16 B13:1;           // 13     BIT13 
       Uint16 B14:1;           // 14     BIT14 
       Uint16 B15:1;           // 15     BIT15 
       Uint16 B16:1;           // 16     BIT16   
       Uint16 B17:1;           // 17     BIT17 
       Uint16 B18:1;           // 18     BIT18 
       Uint16 B19:1;           // 19     BIT19   
       Uint16 B20:1;           // 20     BIT20
       Uint16 B21:1;           // 21     BIT21 
       Uint16 B22:1;           // 22     BIT22    
       Uint16 B23:1;           // 23     BIT23
       Uint16 B24:1;           // 24     BIT24 
       Uint16 B25:1;           // 25     BIT25    
       Uint16 B26:1;           // 26     BIT26 
       Uint16 B27:1;           // 27     BIT27       
       Uint16 B28:1;           // 28     BIT28 
       Uint16 B29:1;           // 29     BIT29 
       Uint16 B30:1;           // 30     BIT30 
       Uint16 B31:1;           // 31     BIT31  
};
struct PfcStatus 
{   	
       Uint16  uiPfcStatusl;     	  // 15:0   PfcStatus low 
       Uint16  uiPfcStatush;           // 31:16  PfcStatus high
};
typedef union 
{
	Uint32				all;
	struct PfcStatus	half;
	struct DEF32_BITS	bit;   
}ulPfcStatus_BITS;

ulPfcStatus_BITS   ulIoPfcStatus[2];
ulPfcStatus_BITS   ulPfcStatus;

/*------------��������-------------------------*/
#define RECOK		0xf0		/* communication normal */ 		
#define CRCCOM		0xf1 		/* CRC check fail */
#define XORCOM		0xf1 		/* XOR check fail */
#define NOVCOM		0xf2		/* invalid command  */
#define NULLCOM		0xf3		/* other fault  */
#define ADREF		3
//*-------�������ֱ���ϵ������--------*
#define	dk_Vac	6.6492//13.298	//0.00974*4096/3/2
//#define	dk_Vpfc	18.2 	//0.01095*4096/3   1V=9.1CNT
#define	dk_Vpfc	16.7625 	//0.01095*4096/3   1V=9.1CNT
//define variables
extern Uint16 RamfuncsLoadStart;
extern Uint16 RamfuncsLoadEnd;
extern Uint16 RamfuncsRunStart;

// sci  variable
Uint16 uiScisendData;
Uint16 uiReceivedChar;
Uint16 uiTranslate_length;
Uint16 uiTr_point;
Uint16 uiRe_point;
Uint16 uiSendCid;
unsigned char ucSendCheckChar;
Uint16 uiReceiveCheckChar;
unsigned char ucCom_Txbuffer[100] ;
unsigned char ucCom_Rxbuffer[100] ;
unsigned char ucReceive_ok;
unsigned char ucTest_ok ;
unsigned char ucScisendFlag;
Uint16  uiSciComFailTime;
int        iSciComFailCount;
Uint16  uiSciComFail;

Uint16 uiActionReady;
Uint32 ulAdcData[11][41];
Uint32 ulAdSum[11];
ubitfloat tagMdlTemp;
ubitfloat tagMdlTemp1;
ubitfloat tagMdlTemp0;
ubitfloat tagMdlTempUp;
ubitfloat tagAcVoltab;
ubitfloat tagAcVoltbc;
ubitfloat tagAcVoltca;
ubitfloat tagAcVoltmax;
ubitfloat tagAcVoltmin;
ubitfloat tagPfcVoltp;
ubitfloat tagPfcVoltn;
ubitfloat tagPfcVolt;

ubitfloat tagPfcVoltp1;		//czk061020 for save backup
ubitfloat tagPfcVoltn1;		//czk061020 for save backup 

Uint16 uiAdAcMaxa;
Uint16 uiAdAcMaxb;
Uint16 uiAdAcMaxc;
//Uint16 uiVabtemp1,uiVabtemp2,uiVabtemp3,uiVabtemp4;	//czk061020
//Uint16 uiVbctemp1,uiVbctemp2,uiVbctemp3,uiVbctemp4;	//czk061020
//Uint16 uiVcatemp1,uiVcatemp2,uiVcatemp3,uiVcatemp4;	//czk061020
Uint16 uiVabtemp1,uiVabtemp2;
Uint16 uiVbctemp1,uiVbctemp2;
Uint16 uiVcatemp1,uiVcatemp2;
Uint16 uiVacline;
unsigned char ucfacflag;

//pfc  varible
Uint16 uiVoltAcab;
Uint16 uiVoltAcbc;
Uint16 uiVoltAcca;

//Uint16 uiPfcStatus;
Uint16 uiPfcVset;
Uint16 uiPfcVsetuse;
Uint16 uiPfcVctrl;
Uint16 uiPfcVctrlBackup;
Uint16 uiTempDcdc0;
Uint16 uiTempDcdc1;
signed int iTempDcdc0;
signed int iTempDcdc1;
Uint16 uiDcCurr;

Uint16 uiDcCurrMax;
Uint16 uiDcCurrDiff;
Uint16 uiDcCurrHyst;
Uint16 uiDynamicFlag;

Uint16 uiHighAcVoltFlag;

Uint16 uiDcVolt;
Uint16 uiDcPower;
Uint16 uiVoltPfcAll;
Uint16 uiVoltPfcUp;
Uint16 uiVoltPfcDn;
signed int  iTempPfc;
Uint16 uiMemAddr0Value;
Uint16 uiMemAddr1Value;


Uint16 uiSysaTemp;		//czk060906
signed int   iSysbTemp;	//czk60906

/*///czk060906
Uint16 uiVacaSampSysa;
signed int   iVacaSampSysb;

Uint16 uiVacbSampSysa;  
signed int   iVacbSampSysb;

Uint16 uiVaccSampSysa;
signed int   iVaccSampSysb;*/

Uint16 uiVpfcAllSampSys;
Uint16 uiVpfcUpSampSys;
Uint16 uiVpfcDnSampSys;
Uint16 uiVpfcAllCtrlSys;
Uint16 uiVpfcUpCtrlSys;
Uint16 uiVpfcDnCtrlSys;

float fVacaSampSysa;
float fVacaSampSysb;
float fVacbSampSysa;
float fVacbSampSysb;
float fVaccSampSysa;
float fVaccSampSysb;
float fVpfcAllSampSys;
float fVpfcUpSampSys;
float fVpfcDnSampSys;
float fVpfcAllCtrlSys;
float fVpfcUpCtrlSys;
float fVpfcDnCtrlSys;

Uint16 uiMemWrAddr;
Uint16 uiMemWrValue;
Uint16 uiMemRdAddr0;
Uint16 uiMemRdAddr1;
Uint16 uiEpromWrAddr;
Uint16 uiEpromWrValue; 
//////////////czk/////////////
Uint16	uiVacUpLimit;
Uint16	uiVacDnLimit;
Uint16	uiVacUpHyst;
Uint16	uiVacDnHyst;
Uint16	uiVpfcAllUpLimit;
Uint16	uiVpfcAllDnLimit;
Uint16	uiVpfcAllUpHyst;
Uint16	uiVpfcAllDnHyst;
Uint16	uiVpfcUpLimit;
Uint16	uiVpfcDnLimit;
Uint16	uiVpfcUpHyst;
Uint16	uiVpfcDnHyst;
Uint16	uiVacUnbalance;
Uint16	uiVpfcSoftstartLimit;
//////////////czk/////////////
long  uiRYSumACa;
long  uiRYSumACb;
long  uiRYSumACc;  
signed    int  uiACYYa;
signed    int  uiACYYb;
signed    int  uiACYYc;

//Io varible
unsigned char ucIoSamConFlag;
unsigned char ucCircuitConFlag;
//unsigned char ucIoSamOVFlag;
unsigned char ucAdcSampFlag;
unsigned char ucDogFlag;
unsigned char ucFanFault; 
unsigned char ucTempDeviceBak;
unsigned char ucTempAlarm;
unsigned char ucOverTempBak;
unsigned char ucDCFAIL;
unsigned char ucUnderVacBak;
unsigned char ucUVacCount;
unsigned char ucOverVacBak;  
unsigned char ucOVacCount;
unsigned char ucPowerderateFlag;
unsigned char ucMdlOpenBak;
unsigned char ucMdlSciOpenBak;

unsigned char ucDcdcClose;
//unsigned char ucPermitOverAc;
//unsigned char ucFanFullspeed;
unsigned char ucAcLackPhase;
unsigned char ucOverVpflag;
unsigned char ucOverVnflag;
unsigned char ucPfcUnflag;
//unsigned char ucLackPhaseLoadflag;
unsigned char ucOvPfc_flag;
unsigned char ucFanEnable;		//czk060906
unsigned char ucHighPFCVoltFlag; 
unsigned char ucHighAcTifFlag;
Uint16 uiFanCmprNew;		//czk060906
Uint16 uiFanCmprOld;		//czk060906
Uint16 uiOvrAcVolt;
Uint16 uiLowAcVolt;
Uint16 uiOpenTime;
Uint16 uiCloseTime;

//sofestart
float	fVpfcSstartSet;		/* pfc_volt_set_soft */
float	fVpfcSstartSet1;	/* pfc_volt_set_soft */
float	fPfcConSys;
Uint16 	uiPFCPwmPermit;
//Uint16 	uiMdlStatus;	//czk061020
Uint16 	uiBaseTimer;		//main Timer  czk061020	
Uint16 	uiBaseTimer0;		//soft start czk061020
//Uint16 	uiBaseTimer1;
Uint16 	uiBaseTimer2;		//fan fault check czk601020
//Uint16 	uiBaseTimer3;
Uint16 	uiBaseTimer4;		//if ac jump, chang ac vol display czk061020
Uint16 	uiBaseTimer5;		//relay action control czk601020
Uint16 uiBaseTimer6;		//av over voltage start timer 
Uint16 uiBaseTimer7;		//if pfc vol reset ok,Լ2s��ָ�Pfcisr.ui_Pfc_Vpi
Uint16 uiBaseTimer8;		//if dcdc jump  chang loop pi, delay 2s reset czk061020
Uint16 uiBaseTimer9; 
Uint16 uiDelayTime;			//after pfc i/o singal sent to dcdc 500ms shut down pfc 
Uint16 uiDelayTime1;		//pfc reset delay 200ms
//Uint16 uiPermitAcPfc;
//Uint16 uiPermitOverAc;  

float fVpfcSstartp;
float fVpfcSstartp1;
float fVpfcSstartstep;
float fVpfcSstartstep1;

//Eeprom define
unsigned char ucEepromErr;
unsigned char ucReadEepromOk;
unsigned char ucWriteNumber;
Uint16            uiVersionNoSw;
Uint16            uiEepromFlag;
ubitfloat	fRdTemp;
unsigned int	uiRdMsgBuffer[4];

unsigned int uitestflag;
unsigned int  *  ui_p_Read;

unsigned int uiEpromRdAddr;
unsigned int uiEpromRdValue;
//--------------------------------------------------------------------
//isr defined
//---------------------------------------------------------------------
//#define  Pfc_Vrmsuplimit  2507
#define  Pfc_Vrmsuplimit  3000
//#define  Pfc_Vrmsdnlimit  697	//czk601020 0V display 201V
#define  Pfc_Vrmsdnlimit  100	//czk601020 0V display 0V

//int    Atable[1198];
void pfc_init(void);

/* Prototype statements for functions found within this file*/
//void vDataInit(void);
interrupt void pfc_isr(void);
void	vMtimerTreat(void);				/* ��ʱ���������� */


void	vOverAcVoltCtl(void);
void	vWorldFanCtrl(void);		   	/* ���ȵ��ٴ��� */
void	vFanControl(void);		   	/* ���ȵ��ٴ��� */
void	vLimitInit(void);				/* EEPROM���ݶ��� */
void	vCanInit(void);					/* can ��ʼ�� */
void	vCircuitCal(void);				/* �޹��ʼ���·�������� */ 
void	uSecond(unsigned int uS);
float	fReadFloatDataThree(unsigned int uAddress);/* ��eepromĳ��ַ�еĸ�����,ͬʱ����У��*/
unsigned char ucWriteFloatDataThree(unsigned int uAddress, ubitfloat fTemp);
unsigned int    uiI2caWriteData(unsigned int uAddress, ubitfloat fTemp);
unsigned int    uiI2caReadData(unsigned int uAddress);
void    vWriteE2PROMSIG(void);
void    WriteE2PROMSIG(unsigned int uAddress, unsigned char ucInChar);
void    vWriteFloatDataSig(unsigned int uAddress, float fTemp);
void  vSendSciData(void);	
void  vGetSciData(void);
unsigned char asc_hex(unsigned char ascl, unsigned char	asch);
unsigned int hex_asc( unsigned char hex	);
void txd_asc(unsigned int len);	

//==========================================================================================
#endif								// End of header guard: #ifndef main_h

//==========================================================================================




