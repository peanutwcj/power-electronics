//########################################################
//
// FILE:   pfc100a_isr.h
//
// TITLE:  pfc100a_isr variables definitions.
//
//########################################################
#ifndef PFCisr_H
#define PFCisr_H

#ifdef __cplusplus
extern "C" {
#endif
        /***************************************************************************
        *            Constant Definition
        ***************************************************************************/
#define         PFC_IPFC_MAX            0xF00           //Q12
#define         PFC_PWMMAX                      475*64         //TBD
#define         PFC_VZEROHYS            25
#define         PFC_VINCOMP_MAX         200
#define         PFC_VINCOMP_MIN         -200
#define         Pfc_Vrmsuplimit         3000
#define         Pfc_Vrmsdnlimit         100

        /***************************************************************************
        *            Variables Definition
        ***************************************************************************/
        struct pfc_100a_isr
        {
                unsigned        int     ui_Pfc_Ref_Volt;        //8e00
                signed          int     i_Pfc_Ref_Curra;        //8e01
                signed          int     i_Pfc_Ref_Currb;        //8e02
                signed          int     i_Pfc_Ref_Currc;        //8e03
                unsigned        int     ui_Pfc_Adc_Va;          //8e04
                unsigned        int     ui_Pfc_Adc_Vb;          //8e05
                unsigned        int     ui_Pfc_Adc_Vc;          //8e06
                int                             i_Pfc_Adc_Ia;           //8e07
                int                             i_Pfc_Adc_Ib;           //8e08
                int                             i_Pfc_Adc_Ic;           //8e09
                int                             i_Pfc_Adc_Ia_1;         //8e07
                int                             i_Pfc_Adc_Ib_1;         //8e08
                int                             i_Pfc_Adc_Ic_1;         //8e09
                int                             i_Pfc_Adc_Ia_av;                //8e07
                int                             i_Pfc_Adc_Ib_av;                //8e08
                int                             i_Pfc_Adc_Ic_av;                //8e09

                unsigned        int     ui_Pfc_Adc_Vp;          //8e0a
                unsigned        int     ui_Pfc_Adc_Vn;          //8e0b

                unsigned        int     ui_Pfc_Volt_Filti1;     //8e0c
                unsigned        int     ui_Pfc_Volt_Filto1;     //8e0d

                signed          int     i_Pfc_Vpi_Err0;         //8e0e
                signed          int     i_Pfc_Vpi_Err1;         //8e0f

//////////////////////////////////////////////////////////
                signed          int     i_Pfc_Vpi_Err2;         //8e10

                unsigned        int     ui_Pfc_FiltK1;          //8e11
                unsigned        int     ui_Pfc_FiltK2;          //8e12

                unsigned        int     ui_Pfc_Vpi_K3;          //8e13
                unsigned        int     ui_Pfc_Vpi_K4;          //8e14

                signed          int     i_Pfc_Iapi_Err0;        //8e15
                signed          int     i_Pfc_Iapi_Err1;        //8e16
                signed          int     i_Pfc_Iapi_Err2;        //8e17
                unsigned        int     ui_Pfc_Iapi_Output0;    //8e18
                unsigned        int     ui_Pfc_Iapi_Output1;    //8e19
                unsigned        int     ui_Pfc_Iapi_Output2;    //8e1a
                unsigned        int     ui_Pfc_Ipi_K1;          //8e1b
                unsigned        int     ui_Pfc_Ipi_K2;          //8e1c
                unsigned        int     ui_Pfc_Ipi_K3;          //8e1d
                unsigned        int     ui_Pfc_Ipi_K4;          //8e1e
                unsigned        int     ui_Pfc_Ipi_K5;          //8e1f
///////////////////////////////////////////////////////
                signed          int     i_Pfc_Ibpi_Err0;        //8e20
                signed          int     i_Pfc_Ibpi_Err1;        //8e21
                signed          int     i_Pfc_Ibpi_Err2;        //8e22
                unsigned        int     ui_Pfc_Ibpi_Output0;//8e23
                unsigned        int     ui_Pfc_Ibpi_Output1;//8e24
                unsigned        int     ui_Pfc_Ibpi_Output2;//8e25

                signed          int     i_Pfc_Icpi_Err0;        //8e26
                signed          int     i_Pfc_Icpi_Err1;        //8e27
                signed          int     i_Pfc_Icpi_Err2;        //8e28
                unsigned        int     ui_Pfc_Icpi_Output0;//8e29
                unsigned        int     ui_Pfc_Icpi_Output1;//8e2a
                unsigned        int     ui_Pfc_Icpi_Output2;//8e2b

                unsigned        int     ui_Pfc_MainTimer;       //8e2c
                unsigned        int     ui_Pfc_VaSamUse;        //8e2d
                unsigned        int     ui_Pfc_VbSamUse;        //8e2e
                unsigned        int     ui_Pfc_VcSamUse;        //8e2f
/////////////////////////////////////////////////////////////////
                unsigned        int     ui_Pfc_VabSamUse;       //8e30
                unsigned        int     ui_Pfc_VbcSamUse;       //8e31
                unsigned        int     ui_Pfc_VcaSamUse;       //8e32
                unsigned        int     ui_Pfc_VabSamUse1;      //8e33
                unsigned        int     ui_Pfc_VbcSamUse1;      //8e34
                unsigned        int     ui_Pfc_VcaSamUse1;      //8e35

                unsigned        int     ui_Pfc_VabRmsUse;       //8e36
                unsigned        int     ui_Pfc_VbcRmsUse;       //8e37
                unsigned        int     ui_Pfc_VcaRmsUse;       //8e38
                unsigned        int     ui_Pfc_VabRmsUse1;      //8e39
                unsigned        int     ui_Pfc_VbcRmsUse1;      //8e3a
                unsigned        int     ui_Pfc_VcaRmsUse1;      //8e3b

                unsigned        int     ui_Pfc_VabSamtmpUse1;   //8e3c
                unsigned        int     ui_Pfc_VbcSamtmpUse1;   //8e3d
                unsigned        int     ui_Pfc_VcaSamtmpUse1;   //8e3e
                unsigned        int     ui_Pfc_VabRmstmpUse;    //8e3f
///////////////////////////////////////////////////////////////////////////
                unsigned        int     ui_Pfc_VbcRmstmpUse;    //8e40
                unsigned        int     ui_Pfc_VcaRmstmpUse;    //8e41
                unsigned        int     ui_Pfc_VabRmstmpUse1;   //8e42
                unsigned        int     ui_Pfc_VbcRmstmpUse1;   //8e43
                unsigned        int     ui_Pfc_VcaRmstmpUse1;   //8e44

                unsigned        int     ui_Pfc_VrmsK1;          //8e45
                unsigned        int     ui_Pfc_VrmsK2;          //8e46

                int                             i_Pfc_VSumSample;       //8e47
                unsigned        int     ui_Pfc_VpfcSamUse;      //8e48

                unsigned        int     ui_Pfc_VaSqrInv;        //8e49
                unsigned        int     ui_Pfc_VbSqrInv;        //8e4a
                unsigned        int     ui_Pfc_VcSqrInv;        //8e4b

                signed          int     i_Pfc_Iin_Offset;       //8e4c
                unsigned        int     ui_Pfc_Vin_Offset;      //8e4d

                signed          int     i_Pfc_Vin_Compen;       //8e4e
                unsigned        int     ui_Pfc_Vin_CompRatio;   //8e4f
                signed      int i_Pfc_Vin_Compen_err;
/////////////////////////////////////////////////////////
                unsigned        int     ui_Pfc_Ipfcmean_Max;    //8e50
                unsigned        int     ui_Pfc_VPITmp;          //8e51

                unsigned        int     k;                                      //8e52
                signed          int     l;                                      //8e53
                signed          int     m;                                      //8e54

                unsigned        int     ui_Pfc_Isample_offset;  //8e55
                signed          int     iIaSampSysA;            //8e56
                signed          int     iIaSampSysB;            //8e57

                signed          int     iIbSampSysA;            //8e58
                signed          int     iIbSampSysB;            //8e59

                signed          int     iIcSampSysA;            //8e5a
                signed          int     iIcSampSysB;            //8e5b
                unsigned        int     ui_Pfc_Ilimitflag;      //8e5c
                signed          int     i_Pfc_Adc_deltaV;       //8e5d
                unsigned        int     ui_Pfc_FanTimer;        //8e5e
                unsigned        int     ui_Pfc_FanPwm;          //8e5f
////////////////////////////////////////////////////////////////////////////
                unsigned        int     ui_Pfc_Vpi_para;        //8e60
                unsigned        int     ui_Pfc_MainTimer1;      //8e61
                unsigned        int     ui_Pfc_Readflag;        //8e62
                unsigned        int     ui_Read_Num;            //8e63
                long                    l_Pfc_Vpi_Output0;      //8e64
                signed          int     i_Pfc_Ipfcmean_Min;     //8e66

                unsigned        int     Ia_TimeTrip;            //8e67
                unsigned        int     Ia_Time;                        //8e68
                unsigned        int     Ia_Trip;                        //8e69//Ia>11A czk060906

                unsigned        int     Ib_TimeTrip;            //8e6a
                unsigned        int     Ib_Time;                        //8e6b
                unsigned        int     Ib_Trip;                        //8e6c//Ia>11A czk060906

                unsigned        int     Ic_TimeTrip;            //8e6d
                unsigned        int     Ic_Time;                        //8e6e
                unsigned        int     Ic_Trip;                        //8e6f//Ia>11A czk060906

                //unsigned int  Pfc_uiPfcStatus;        //
                unsigned        int     i_Pfc_Adc_Tzflag;       //8e70

                unsigned        int     ui_Pfc_OvpTime;         //8e71
                unsigned        int     ui_Pfc_OvpFlag;         //8e72
                unsigned        int     ui_Pfc_OvnTime;         //8e73
                unsigned        int     ui_Pfc_OvnFlag;         //8e74
                unsigned        int     ui_PfcVersion;          //8e75
                unsigned        int     ui_Pfc_Vversion;        //8e76
                unsigned        int     ui_Pfc_Dversion;        //8e77
                unsigned        int     ui_Pfc_Tversion;        //8e78

                unsigned        int ui_Pfc_Adc_VaMax;   //8e79
                unsigned        int ui_Pfc_Adc_VbMax;   //8e7A
                unsigned        int ui_Pfc_Adc_VcMax;   //8e7B
                unsigned        int ui_Pfc_Vpi_K;               //8e7C

                //long                  ltemptest;                      //8e70
                signed        int     i_Pfc_VaSamUseOLD[100];
                signed        int     i_Pfc_VbSamUseOLD[100];
               // signed        int     i_Pfc_VcSamUseOLD[100];
        };

        extern volatile struct pfc_100a_isr Pfcisr;
        interrupt void Identification_Isr(void);
        interrupt void boostMode_Isr(void);
        void boost_init(void);

#ifdef __cplusplus
}
#endif /* extern "C" */

#endif


