#include "DSP280x_Device.h"     // DSP280x Headerfile Include File


#define ADC_usDELAY  5000L
//#define ADC_MODCLK 0x4   // HSPCLK = SYSCLKOUT/2*ADC_MODCLK2 = 100/(2*4) = 12.5 MHz
#define ADC_CKPS   0x0  // ADC module clock = HSPCLK/8      = 12.5MHz/(8)   = 1.56 MHz
#define ADC_SHCLK  0x2   // S/H width in ADC module periods                  = 2 ADC cycle

//  LXK 2017/07/04
// ADCװ����ɴ���SEQ1�ж�
void InitAdc(void)
{
    extern void DSP28x_usDelay(Uint32 Count);

    // To powerup the ADC the ADCENCLK bit should be set first to enable
    // clocks, followed by powering up the bandgap, reference circuitry, and ADC core.
    // Before the first conversion is performed a 5ms delay must be observed 
	// after power up to give all analog circuits time to power up and settle

    // Please note that for the delay function below to operate correctly the 
	// CPU_CLOCK_SPEED define statement in the DSP280x_Examples.h file must 
	// contain the correct CPU clock period in nanoseconds. 

    //AdcRegs.ADCREFSEL.bit.REF_SEL = 01;    //shielding it means using inside AD reference

	AdcRegs.ADCTRL3.all = 0x00E0;  // Power up bandgap/reference/ADC circuits
	DELAY_US(ADC_usDELAY);			// Delay before converting ADC channels
    AdcRegs.ADCREFSEL.all=0x0000;  //interal power selected
    AdcRegs.ADCTRL1.bit.ACQ_PS = ADC_SHCLK;  	
    					
    					// Sequential mode: Sample rate   = 1/[(2+ACQ_PS)*ADC clock in ns]
					    //                     = 1/(3*80ns) =4.17MHz
					    // If Simultaneous mode enabled: Sample rate = 1/[(3+ACQ_PS)*ADC clock in ns]
   	AdcRegs.ADCTRL1.bit.CPS=0;		
   	AdcRegs.ADCTRL3.bit.ADCCLKPS = ADC_CKPS;		
   	AdcRegs.ADCTRL1.bit.SEQ_CASC = 1;    
   	AdcRegs.ADCCHSELSEQ1.bit.CONV00 = 0x0;	//TI ADC bug???
  	AdcRegs.ADCTRL1.bit.CONT_RUN = 0;       // Setup continuous run ADC mode

   	AdcRegs.ADCTRL1.bit.SEQ_OVRD = 0;       // Enable Sequencer override feature
   	AdcRegs.ADCTRL2.bit.EPWM_SOCA_SEQ1 = 1;	// Enable SOCA from ePWM to start SEQ1 

   	AdcRegs.ADCTRL2.bit.INT_ENA_SEQ1 = 1;
   	AdcRegs.ADCTRL2.bit.INT_MOD_SEQ1 = 0;
   	 
   	AdcRegs.ADCCHSELSEQ1.all = 0x3210; // A0-va;A1-vb;A2-vc;A3-ia;
   	AdcRegs.ADCCHSELSEQ2.all = 0x7654; // A4-ib;A5-ic;A6-vp;A7-vn;
   	AdcRegs.ADCCHSELSEQ3.all = 0xba98; // B0-VaRms;B1-VbRms;B-VcRms;B-TEMPPFC;
   	AdcRegs.ADCCHSELSEQ4.all = 0x2002; // Setup conv from ADCINA1 & ADCINB1
   	AdcRegs.ADCMAXCONV.bit.MAX_CONV1 = 0xB;  // convert and store in 9 results registers   
   //AdcRegs.ADCMAXCONV.bit.MAX_CONV2 = 0x0; 
}	

//===========================================================================
// End of file.
//===========================================================================
