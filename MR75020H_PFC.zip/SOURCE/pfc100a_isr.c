//#########################################################
//    FILE:     pfc100a_isr.c

//    TITLE:    DSP280x pfc100a isr Functions.
//#########################################################
// Running on TMS320LF280xA   PFC part   h741Au1(1.00)
// External clock is 20MHz, PLL * 10/2 , CPU-Clock 100 MHz
// Date: from May 23, 2005 to Oct 30, 2006  , (C) www & mhp & lsy & lyg &mj
// Version:1.00     Change Date: May 24, 2005 , (C) www & mhp & lsy & lyg &mj
// Version:1.01     Change Date: Sep 06, 2006 , (C) czk
// Version:1.02     Change Date: Dec 31, 2006 , (C) czk
//#########################################################

#include "IQmathLib.h"
#include "DSP280x_Device.h"


extern Uint16 uiBaseTimer7;
extern    Uint16      uiPFCPwmPermit;
extern unsigned int  *  ui_p_Read;
extern Uint32 uFant;
//hsr/20120817 add begin
unsigned    int ui_Pfc_Adc_VaBak_0;
unsigned    int ui_Pfc_Adc_VbBak_0;
unsigned    int ui_Pfc_Adc_VcBak_0;
//hsr/20120817 add end
//signed    int data_save1[50],data_save2[50];
unsigned int save_index=0,save_count=0;
extern    void          pfc_init();
extern long  uiRYSumACa;
extern long  uiRYSumACb;
extern long  uiRYSumACc;
extern signed    int  uiACYYa;
extern signed    int  uiACYYb;
extern signed    int  uiACYYc;
signed    int uiPfc_Vepi_K3;
signed    int uiPfc_Vepi_K4;
signed    int i_Pfc_Vin_Compen_err1=0;
extern unsigned char uiNeedFanFlag;
extern Uint32 FanCnt;
void tempdata_save();
/***************************************************************************
*    Function Name:     pfc_init  all values TBD
***************************************************************************/
void pfc_init()
{
        unsigned int i;
        //sc=2*pi*200/(s + 2*pi*200),tustin, time=8/90k   q15
        Pfcisr.ui_Pfc_FiltK1=29301; //uVpfcK1
        Pfcisr.ui_Pfc_FiltK2=1733;   //uVpfcK2

        //sc=1.5*(s+2*pi*4)/s, tustin,time=8/90k   q12
        //sc=6.6*(s+2*pi*10)/s, tustin,time=8/90k   q12
        Pfcisr.ui_Pfc_Vpi_K3=6161;  //uVpfcK3 //MXH  2011/2/15
        Pfcisr.ui_Pfc_Vpi_K4=6127;  //uVpfcK4 //MXH  2011/2/15

        //sc=1.7*(s+2*pi*500)/s, tustin,time=8/45k   q12
        uiPfc_Vepi_K3=8314;  //uVpfcK3 //MXH  2011/2/15
        uiPfc_Vepi_K4=6276;  //uVpfcK4 //MXH  2011/2/15

        //  sc=6.66*(s+2*pi*1280)*(s+2*pi*1320)/[s*(s+2*pi*1700)],tustin, time=1/90k
        Pfcisr.ui_Pfc_Ipi_K1=1933;  //Kv1_dzsp_shift
        Pfcisr.ui_Pfc_Ipi_K2=909;   //Kv2_dzsp_shift
        Pfcisr.ui_Pfc_Ipi_K3=7035;      //Kv3_dzsp_shift
        Pfcisr.ui_Pfc_Ipi_K4=12849; //Kv4_dzsp_shift
        Pfcisr.ui_Pfc_Ipi_K5=5867;  //Kv5_dzsp_shift


        //sc=2*pi*7/(s + 2*pi*7),tustin, time=8/90k   q16
        Pfcisr.ui_Pfc_VrmsK1 = 65273;
        Pfcisr.ui_Pfc_VrmsK2 =131;

        Pfcisr.ui_Pfc_Vin_Offset = 0x0800;//������·��1.5V��ƫ
        Pfcisr.ui_Pfc_Vin_CompRatio =50;
        Pfcisr.ui_Pfc_Vpi_K=6;

        Pfcisr.ui_Pfc_VaSqrInv = 5074; //hsr/20120814 add  268435456/230^2=2444
        Pfcisr.ui_Pfc_VbSqrInv = 5074; //hsr/20120814 add  268435456/230^2=2444
        Pfcisr.ui_Pfc_VcSqrInv = 5074; //hsr/20120814 add  268435456/230^2=2444

        //////////////////////////////////////////////////////////
        Pfcisr.ui_Pfc_Ipfcmean_Max = 0x7FF0; /////32480
        Pfcisr.ui_Pfc_Isample_offset=0x70;  //0x48      //mxh 20121121test
        Pfcisr.ui_Pfc_FanPwm=1;

        Pfcisr.ui_PfcVersion=0x0612;            //date version
        Pfcisr.ui_Pfc_Vversion = 103;                   //poilt version
        Pfcisr.ui_Pfc_Dversion = 0;                     // based on 0726
        Pfcisr.ui_Pfc_Tversion = 0x0000;                // optimize noise(zym:0926) deve version(temp version)
        // optimize TR presented by LYW, (except while)

        Pfcisr.i_Pfc_Ipfcmean_Min = -0x0FF0;
        for(i = 0; i<100; i++)
                Pfcisr.i_Pfc_VaSamUseOLD[i] = 0;
        for(i = 0; i<100; i++)
                Pfcisr.i_Pfc_VbSamUseOLD[i] = 0;
        //for(i = 0; i<100; i++)
        //     Pfcisr.i_Pfc_VcSamUseOLD[i] = 0;
}
void boost_init(void)
{
	Pfcisr.ui_Pfc_MainTimer = 0;
	Pfcisr.ui_Pfc_MainTimer1 = 0;
	Pfcisr.ui_Pfc_Adc_Vp = 0;
	Pfcisr.ui_Pfc_Adc_Vn = 0;

	Pfcisr.ui_Pfc_Ref_Volt = 0;
	Pfcisr.ui_Pfc_VpfcSamUse = 0;
	Pfcisr.i_Pfc_Vpi_Err0 = 0;
	Pfcisr.i_Pfc_Vpi_Err1 = 0;

	Pfcisr.l_Pfc_Vpi_Output0 = 0;
	Pfcisr.ui_Pfc_VPITmp = 0;

	Pfcisr.ui_Pfc_Adc_Va = 0;
	Pfcisr.ui_Pfc_Adc_Vb = 0;
	Pfcisr.ui_Pfc_Adc_Vc = 0;
    Pfcisr.ui_Pfc_VabRmstmpUse = 0;
    Pfcisr.ui_Pfc_VbcRmstmpUse = 0;
    Pfcisr.ui_Pfc_VcaRmsUse = 0;

	Pfcisr.iIaSampSysB = 20;
	Pfcisr.iIbSampSysB = 20;
	Pfcisr.iIcSampSysB = 20;

	Pfcisr.i_Pfc_Adc_Ia = 0;
	Pfcisr.i_Pfc_Adc_Ib = 0;
	Pfcisr.i_Pfc_Adc_Ic = 0;
	Pfcisr.i_Pfc_Adc_Ib_av = 0;
	Pfcisr.i_Pfc_Adc_Ib_1 = 0;

	Pfcisr.i_Pfc_Ref_Currb = 0;
	Pfcisr.i_Pfc_Ibpi_Err0 = 0;
	Pfcisr.i_Pfc_Ibpi_Err1 = 0;
	Pfcisr.ui_Pfc_Ibpi_Output1 = 0;
	Pfcisr.ui_Pfc_Ibpi_Output0 = 0;

	uiPFCPwmPermit = 0;
}
interrupt void Identification_Isr(void)
{
    Pfcisr.ui_Pfc_Adc_Va = AdcMirror.ADCRESULT0;
    Pfcisr.ui_Pfc_Adc_Vb = AdcMirror.ADCRESULT1;
    Pfcisr.ui_Pfc_Adc_Vc = AdcMirror.ADCRESULT2;
	AdcRegs.ADCTRL2.bit.RST_SEQ1 = 1;
	AdcRegs.ADCST.bit.INT_SEQ1_CLR = 1;
	PieCtrlRegs.PIEACK.all = PIEACK_GROUP1;
}
//ADC�ж�
extern Uint16 uiActionReady;
extern unsigned long InputCurMax;
extern unsigned char bRelayFlag ;
interrupt void boostMode_Isr(void)
{
	static signed long CurLoopOut = 0;
	unsigned int temp = 0;
	signed long Vtemp = 0,Itemp = 0;
	Pfcisr.ui_Pfc_MainTimer++;
	Pfcisr.ui_Pfc_MainTimer = Pfcisr.ui_Pfc_MainTimer & 0x0003;
	switch(Pfcisr.ui_Pfc_MainTimer)
	{
	case 0://��ѹ��
		Pfcisr.ui_Pfc_Adc_Vp = AdcMirror.ADCRESULT6;
		Pfcisr.ui_Pfc_Adc_Vn = AdcMirror.ADCRESULT7;
        Pfcisr.ui_Pfc_VpfcSamUse = Pfcisr.ui_Pfc_Adc_Vp+ Pfcisr.ui_Pfc_Adc_Vn;
        Pfcisr.i_Pfc_Vpi_Err0 =(signed int)Pfcisr.ui_Pfc_Ref_Volt - (signed int)(Pfcisr.ui_Pfc_VpfcSamUse);
        if(uiActionReady >= 3)
        {
        	Pfcisr.l_Pfc_Vpi_Output0 += Pfcisr.i_Pfc_Vpi_Err0 * 28;
            if(Pfcisr.l_Pfc_Vpi_Output0 >= (signed long)6845105)//30A*2^24/73.5294 =6845105.2232168357146937143509943
            	Pfcisr.l_Pfc_Vpi_Output0 = (signed long)6845105;
            else if(Pfcisr.l_Pfc_Vpi_Output0 <= (signed long)-6845105)
            	Pfcisr.l_Pfc_Vpi_Output0 = (signed long)-6845105;
            Vtemp = Pfcisr.l_Pfc_Vpi_Output0 + (signed long)Pfcisr.i_Pfc_Vpi_Err0 * 5188;
            if(Vtemp < 0)
            {
    			EPwm1Regs.AQCSFRC.all = 0x05;    //PWM1A,PWM1B force low
    			EPwm2Regs.AQCSFRC.all = 0x05;    //PWM2A,PWM2B force low
            }
            else
            {
            	EPwm1Regs.AQCSFRC.bit.CSFB = 0;
            	EPwm2Regs.AQCSFRC.all = 0x00;
            }
            if(Vtemp < 0)
            {
                Pfcisr.ui_Pfc_VPITmp = 0;
            }
            else if(Vtemp >= InputCurMax)
            {
            	Pfcisr.ui_Pfc_VPITmp = (unsigned int)(InputCurMax>>12); //1671
            }
            else Pfcisr.ui_Pfc_VPITmp = (unsigned int)(Vtemp>>12);
        }
        else
        {
        	Pfcisr.ui_Pfc_VPITmp = 0;
        	Pfcisr.l_Pfc_Vpi_Output0 = 0;
        }
		break;
	case 1:
		Pfcisr.ui_Pfc_MainTimer1++;
		break;
	case 2:
        Pfcisr.ui_Pfc_Adc_Va = AdcMirror.ADCRESULT0;
        Pfcisr.ui_Pfc_Adc_Vb = AdcMirror.ADCRESULT1;
        Pfcisr.ui_Pfc_Adc_Vc = AdcMirror.ADCRESULT2;
        Pfcisr.ui_Pfc_VabRmsUse = 0;
        Pfcisr.ui_Pfc_VbcRmsUse = (Pfcisr.ui_Pfc_Adc_Vc - Pfcisr.ui_Pfc_Adc_Vb);
        Pfcisr.ui_Pfc_VcaRmsUse = 0;
		break;
	case 3:
		//OVP_Vp ��ѹ���
		if(((unsigned int)AdcMirror.ADCRESULT8)> 4050)
		{
			Pfcisr.ui_Pfc_OvpTime =Pfcisr.ui_Pfc_OvpTime+1;
		}
		else if((((unsigned int)AdcMirror.ADCRESULT8)> 4000)&&(Pfcisr.ui_Pfc_OvpFlag))
		{
			Pfcisr.ui_Pfc_OvpTime =Pfcisr.ui_Pfc_OvpTime+1;
		}
		else
		{
			Pfcisr.ui_Pfc_OvpTime =0;
			Pfcisr.ui_Pfc_OvpFlag =0;
		}
	    if(Pfcisr.ui_Pfc_OvpTime>=100)
	    {
	    	Pfcisr.ui_Pfc_OvpFlag =1;
	    	Pfcisr.ui_Pfc_OvpTime=100;
	    }
	    //OVP_Vn��ѹ���
	    if(((unsigned int)AdcMirror.ADCRESULT9)> 4050)
	    {
	    	Pfcisr.ui_Pfc_OvnTime =Pfcisr.ui_Pfc_OvnTime+1;
	    }
	    else if((((unsigned int)AdcMirror.ADCRESULT9)> 4000)&&(Pfcisr.ui_Pfc_OvnFlag))
	    {
	    	Pfcisr.ui_Pfc_OvnTime =Pfcisr.ui_Pfc_OvnTime+1;
	    }
	    else
	    {
	    	Pfcisr.ui_Pfc_OvnTime =0;
	    	Pfcisr.ui_Pfc_OvnFlag =0;
	    }
	    if(Pfcisr.ui_Pfc_OvnTime>=100)
	    {
	    	Pfcisr.ui_Pfc_OvnFlag =1;
	    	Pfcisr.ui_Pfc_OvnTime=100;
	    }
		break;
	default:
		break;
	}

	Pfcisr.i_Pfc_Adc_Ia = (signed int)(AdcMirror.ADCRESULT3 - Pfcisr.iIaSampSysB) < 0 ? 0: (AdcMirror.ADCRESULT3 - Pfcisr.iIaSampSysB);
	Pfcisr.i_Pfc_Adc_Ib = (signed int)(AdcMirror.ADCRESULT4 - Pfcisr.iIbSampSysB) < 0 ? 0: (AdcMirror.ADCRESULT4 - Pfcisr.iIbSampSysB);
	Pfcisr.i_Pfc_Adc_Ic = (signed int)(AdcMirror.ADCRESULT5 - Pfcisr.iIcSampSysB) < 0 ? 0: (AdcMirror.ADCRESULT5 - Pfcisr.iIcSampSysB);

	Pfcisr.i_Pfc_Adc_Ib_av  = (Pfcisr.i_Pfc_Adc_Ib + Pfcisr.i_Pfc_Adc_Ic)>>1;
	Pfcisr.i_Pfc_Adc_Ib_av  = (Pfcisr.i_Pfc_Adc_Ib_av + Pfcisr.i_Pfc_Adc_Ib_1)>>1;
	Pfcisr.i_Pfc_Adc_Ib_1 = Pfcisr.i_Pfc_Adc_Ib_av;

	Pfcisr.i_Pfc_Ref_Currb = Pfcisr.ui_Pfc_VPITmp;
	Pfcisr.i_Pfc_Ibpi_Err1 = Pfcisr.i_Pfc_Ibpi_Err0;
	Pfcisr.i_Pfc_Ibpi_Err0 = (signed int)(Pfcisr.i_Pfc_Ref_Currb - Pfcisr.i_Pfc_Adc_Ib_av);
    if(uiActionReady >= 3)
	{
		//���ֻ�·
		CurLoopOut = CurLoopOut + (signed long)Pfcisr.i_Pfc_Ibpi_Err0*18;
		if(CurLoopOut >= (signed long)13421772)//0.8*2^24 = 13421772.8
			CurLoopOut = (signed long)13421772;
		else if(CurLoopOut <= (signed long)-13421772)
			CurLoopOut = (signed long)-13421772;
		Itemp = CurLoopOut + (unsigned long)Pfcisr.i_Pfc_Ibpi_Err0*142;
		if(Itemp < 0 )
			Pfcisr.ui_Pfc_Ibpi_Output0 = 16;
		else if(Itemp >= ((signed long)uiPFCPwmPermit<<12)) //0.9*2^24 = 15099494.4
			Pfcisr.ui_Pfc_Ibpi_Output0 =  uiPFCPwmPermit;
		else Pfcisr.ui_Pfc_Ibpi_Output0 = (unsigned int)(Itemp >> 12);
	}
	else
	{
		CurLoopOut = 0;
		Pfcisr.ui_Pfc_Ibpi_Output0 = 16;  //0.4%*4096
	}
	temp = (unsigned int)((unsigned long)Pfcisr.ui_Pfc_Ibpi_Output0*1112 >> 12);
	if(temp >= 945)   temp = 945; //65% * 1112 = 723
	else if(temp <= 2) temp = 2;
	EPwm1Regs.CMPB = temp;
	EPwm2Regs.CMPA.half.CMPA = temp;

    Pfcisr.ui_Pfc_FanTimer++;
    Pfcisr.ui_Pfc_FanTimer %= 100;
    if((Pfcisr.ui_Pfc_FanTimer == 0)&&(bRelayFlag == 1))
        GpioDataRegs.GPASET.bit.GPIO4 = 1; //����ת
    if((uiNeedFanFlag == 1) || (uFant <= 12000))
    {

        if(Pfcisr.ui_Pfc_FanTimer > Pfcisr.ui_Pfc_FanPwm)
        {
            GpioDataRegs.GPACLEAR.bit.GPIO4 = 1;
        }
    }
    else
        GpioDataRegs.GPACLEAR.bit.GPIO4 = 1;
	AdcRegs.ADCTRL2.bit.RST_SEQ1 = 1;
	AdcRegs.ADCST.bit.INT_SEQ1_CLR = 1;
	PieCtrlRegs.PIEACK.all = PIEACK_GROUP1;
}
/***************************************************************************
*    Function Name:     pfc_isr
***************************************************************************/
#pragma CODE_SECTION(pfc_isr, "ramfuncs");
interrupt void pfc_isr() //epwm3-zero 5.56us*2=11.12us once
{
        signed long        Pfc_TmpLong;
        unsigned int       Pfc_uTmp;
        static signed long lVacATempSum = 0;
        static  signed long lVacBTempSum = 0;
        //   static  signed long lVacCTempSum = 0;
        static unsigned int wCnt = 0;
        static unsigned int K =0;
        static unsigned int J = 0;		

        Pfcisr.ui_Pfc_MainTimer++;
        Pfcisr.ui_Pfc_MainTimer=Pfcisr.ui_Pfc_MainTimer&0x0007;

        if(Pfcisr.ui_Pfc_MainTimer ==0)//  1/8
        {
              

		 Pfcisr.ui_Pfc_Adc_Vp= AdcMirror.ADCRESULT6;
                Pfcisr.ui_Pfc_Adc_Vn= AdcMirror.ADCRESULT7;
                Pfcisr.ui_Pfc_VpfcSamUse = Pfcisr.ui_Pfc_Adc_Vp+ Pfcisr.ui_Pfc_Adc_Vn;

                //K1+2*K2=32768   //��ĸ�ߵ�ѹ����200hz�ĵ�ͨ�˲�
                Pfc_TmpLong=(long)Pfcisr.ui_Pfc_FiltK1*(long)Pfcisr.ui_Pfc_Volt_Filto1+(long)(Pfcisr.ui_Pfc_VpfcSamUse+Pfcisr.ui_Pfc_Volt_Filti1)*(long)Pfcisr.ui_Pfc_FiltK2;
                Pfcisr.ui_Pfc_Volt_Filti1=Pfcisr.ui_Pfc_VpfcSamUse;
                Pfcisr.ui_Pfc_Volt_Filto1=(unsigned int)(Pfc_TmpLong>>15);
                Pfcisr.i_Pfc_Vpi_Err1 =  Pfcisr.i_Pfc_Vpi_Err0;


                Pfcisr.i_Pfc_Vpi_Err0 =(signed int)Pfcisr.ui_Pfc_Ref_Volt - (signed int)(Pfc_TmpLong>>15) ;
                Pfcisr.l_Pfc_Vpi_Output0 = Pfcisr.l_Pfc_Vpi_Output0 + (long)((long)Pfcisr.i_Pfc_Vpi_Err0 * Pfcisr.ui_Pfc_Vpi_K3*4 - (long)Pfcisr.i_Pfc_Vpi_Err1 * Pfcisr.ui_Pfc_Vpi_K4*4)* Pfcisr.ui_Pfc_Vpi_K;


                ///////////zyming 060829        ////////////////////////

                //Q12
                if(Pfcisr.l_Pfc_Vpi_Output0 >= (signed long)Pfcisr.ui_Pfc_Ipfcmean_Max * 4096)  ///////Pfcisr.ui_Pfc_Ipfcmean_Max = 32752
                {
                        Pfcisr.l_Pfc_Vpi_Output0 = (signed long)Pfcisr.ui_Pfc_Ipfcmean_Max *4096;
                }
                else if(Pfcisr.l_Pfc_Vpi_Output0 <= (signed long)Pfcisr.i_Pfc_Ipfcmean_Min *4096)   ///// = 3Pfcisr.i_Pfc_Ipfcmean_Min  = -32752
                {
                        Pfcisr.l_Pfc_Vpi_Output0 = (signed long)Pfcisr.i_Pfc_Ipfcmean_Min *4096;
                }

                if(Pfcisr.l_Pfc_Vpi_Output0 <= 0)
                        Pfcisr.ui_Pfc_VPITmp = 0;
                else
                        Pfcisr.ui_Pfc_VPITmp = (unsigned int)(Pfcisr.l_Pfc_Vpi_Output0 >> 12);  //Q0
        }

        //Pfcisr.ui_Pfc_VPITmp������BUS��ѹ�Ĳ����ȣ�9.1


        if(Pfcisr.ui_Pfc_MainTimer ==4)//����BUS��ƽ�����
        {
		i_Pfc_Vin_Compen_err1=Pfcisr.i_Pfc_Vin_Compen_err;
                Pfcisr.i_Pfc_Vin_Compen_err=(signed int)((signed int)Pfcisr.ui_Pfc_Adc_Vn -(signed int)Pfcisr.ui_Pfc_Adc_Vp);
                Pfcisr.i_Pfc_Vin_Compen =Pfcisr.i_Pfc_Vin_Compen+(signed int)(((long)Pfcisr.i_Pfc_Vin_Compen_err * uiPfc_Vepi_K3-(long)i_Pfc_Vin_Compen_err1 * uiPfc_Vepi_K4)>>12);
                //�Լ�����Pfcisr.i_Pfc_Vin_Compen �޷� czk060825
                if(Pfcisr.i_Pfc_Vin_Compen >= PFC_VINCOMP_MAX)//200
                {
                        Pfcisr.i_Pfc_Vin_Compen = PFC_VINCOMP_MAX;
                }
                else if(Pfcisr.i_Pfc_Vin_Compen <= PFC_VINCOMP_MIN)//-200
                {
                        Pfcisr.i_Pfc_Vin_Compen = PFC_VINCOMP_MIN;
                }


                Pfcisr.ui_Pfc_MainTimer1++;     //11.12us*8
        }

//=============================================================//
//==========================================================//

        Pfcisr.ui_Pfc_Adc_Va = AdcMirror.ADCRESULT0;
        Pfcisr.ui_Pfc_Adc_Vb = AdcMirror.ADCRESULT1;
        Pfcisr.ui_Pfc_Adc_Vc = AdcMirror.ADCRESULT2;

        if(wCnt < 4)
        {
//                 GpioDataRegs.GPASET.bit.GPIO4 = 1;

				wCnt++;

                if(Pfcisr.ui_Pfc_VPITmp > 6000)/////////��֪����ѹ���������ʾ����
                {
                        lVacATempSum += ((signed int)Pfcisr.ui_Pfc_Adc_Va - (signed int)Pfcisr.ui_Pfc_Vin_Offset);
                        lVacBTempSum += ((signed int)Pfcisr.ui_Pfc_Adc_Vb - (signed int)Pfcisr.ui_Pfc_Vin_Offset);
                        // lVacCTempSum += ((signed int)Pfcisr.ui_Pfc_Adc_Vc - (signed int)Pfcisr.ui_Pfc_Vin_Offset);
                }
                else
                {
                        lVacATempSum += 0;
                        lVacBTempSum += 0;
                        // lVacCTempSum += 0;
                }

//				GpioDataRegs.GPACLEAR.bit.GPIO4 = 1;
        }
        if(wCnt >= 4)
        {
                lVacATempSum >>=6;//  >>2  /4
                lVacBTempSum >>=6;
                // lVacCTempSum >>=6;


                Pfcisr.i_Pfc_VaSamUseOLD[K] = (signed int)lVacATempSum;

                Pfcisr.i_Pfc_VbSamUseOLD[K] = (signed int)lVacBTempSum;

                //  Pfcisr.i_Pfc_VcSamUseOLD[K] = (signed int)lVacCTempSum;


                K++;
                if(K>=100)
                        K = 0;

                wCnt = 0;
                lVacATempSum =0;
                lVacBTempSum =0;
                // lVacCTempSum =0;
        }
        //hsr/20120817 add begin
        //Pfcisr.ui_Pfc_Adc_Va = (Pfcisr.ui_Pfc_Adc_Va + ui_Pfc_Adc_VaBak_0)>>1;    //***���β���ȡƽ��ֵ***//
//      Pfcisr.ui_Pfc_Adc_Vb = (Pfcisr.ui_Pfc_Adc_Vb + ui_Pfc_Adc_VbBak_0)>>1;
//      Pfcisr.ui_Pfc_Adc_Vc = (Pfcisr.ui_Pfc_Adc_Vc + ui_Pfc_Adc_VcBak_0)>>1;

        //  ui_Pfc_Adc_VaBak_0 = Pfcisr.ui_Pfc_Adc_Va;                 //*****�������ֵ���´�ʹ��*********//
//      ui_Pfc_Adc_VbBak_0 = Pfcisr.ui_Pfc_Adc_Vb;
//      ui_Pfc_Adc_VcBak_0 = Pfcisr.ui_Pfc_Adc_Vc;
        //hsr/20120817 add end

//////////////�������������� begin /////////////////////////////////////////////
        J = K+1;
        if(J >=100)
                J = 0;
        //�����������
        Pfcisr.i_Pfc_VSumSample=((signed int)Pfcisr.ui_Pfc_Adc_Va- (signed int)Pfcisr.ui_Pfc_Vin_Offset)+((signed int)Pfcisr.ui_Pfc_Adc_Vb- (signed int)Pfcisr.ui_Pfc_Vin_Offset)+((signed int)Pfcisr.ui_Pfc_Adc_Vc- (signed int)Pfcisr.ui_Pfc_Vin_Offset);
//      Pfcisr.i_Pfc_VSumSample=(Pfcisr.ui_Pfc_Adc_Va- Pfcisr.ui_Pfc_Vin_Offset)+(Pfcisr.ui_Pfc_Adc_Vb- Pfcisr.ui_Pfc_Vin_Offset)+(Pfcisr.ui_Pfc_Adc_Vc- Pfcisr.ui_Pfc_Vin_Offset);

        //��̬�� Pfcisr.i_Pfc_VSumSample=Pfcisr.i_Pfc_Vin_Compen=0
//      Pfcisr.ui_Pfc_VaSamUse=abs(3*(Pfcisr.ui_Pfc_Adc_Va- Pfcisr.ui_Pfc_Vin_Offset)-Pfcisr.i_Pfc_VSumSample- Pfcisr.i_Pfc_Vin_Compen);
        Pfcisr.ui_Pfc_VaSamUse=(unsigned int)( abs(3*((signed int)Pfcisr.ui_Pfc_Adc_Va- (signed int)Pfcisr.ui_Pfc_Vin_Offset +Pfcisr.i_Pfc_VaSamUseOLD[J])-Pfcisr.i_Pfc_VSumSample- Pfcisr.i_Pfc_Vin_Compen));


        //Pfcisr.ui_Pfc_VaSqrInv=8390; //hsr/20120814 delete  �����е��ѹ����
        Pfc_uTmp = (unsigned int)(((unsigned long)Pfcisr.ui_Pfc_VPITmp * Pfcisr.ui_Pfc_VaSqrInv) >> 16);
        Pfc_uTmp = (unsigned int)((unsigned long)Pfc_uTmp * Pfcisr.ui_Pfc_VaSamUse >> 11);
        // Pfc_uTmp = (unsigned int)((unsigned long)Pfc_uTmp * Pfcisr.ui_Pfc_VaSamUse>> 11 -(unsigned int)((unsigned long)Pfc_uTmp*(unsigned long)Pfcisr.i_Pfc_VaSamUseOLD[J]*(unsigned long)100>>21));//ֱ��*�벨����==����������


        //�Ե��������������� �޷� czk060825
        if(Pfc_uTmp >= PFC_IPFC_MAX)
        {
                Pfc_uTmp = PFC_IPFC_MAX;
        }
        else if(Pfc_uTmp <= 0)//�����е��ѹ����֮�����Ϊ0����Ϊ�е���㴦
        {
                Pfcisr.i_Pfc_Iin_Offset = -128;//-128   ����������·�����˱���
                Pfc_uTmp = 0;
        }

        Pfcisr.i_Pfc_Ref_Curra = Pfc_uTmp;

        //Pfcisr.ui_Pfc_VbSamUse=abs(3*(Pfcisr.ui_Pfc_Adc_Vb- Pfcisr.ui_Pfc_Vin_Offset)-Pfcisr.i_Pfc_VSumSample- Pfcisr.i_Pfc_Vin_Compen);
        Pfcisr.ui_Pfc_VbSamUse=(unsigned int)( abs(3*((signed int)Pfcisr.ui_Pfc_Adc_Vb- (signed int)Pfcisr.ui_Pfc_Vin_Offset +Pfcisr.i_Pfc_VbSamUseOLD[J])-Pfcisr.i_Pfc_VSumSample- Pfcisr.i_Pfc_Vin_Compen));



        //Pfcisr.ui_Pfc_VbSqrInv=8390; //hsr/20120814 delete  ,267V30A, PF=0.982,0.985,0.983, THDI=3.5%,4.0%,4.0%

        Pfc_uTmp = (unsigned int)((unsigned long)Pfcisr.ui_Pfc_VPITmp * Pfcisr.ui_Pfc_VbSqrInv >> 16);
        Pfc_uTmp = (unsigned int)((unsigned long)Pfc_uTmp * Pfcisr.ui_Pfc_VbSamUse >> 11);

        // Pfc_uTmp = (unsigned int)((unsigned long)Pfc_uTmp * Pfcisr.ui_Pfc_VbSamUse>> 11 -(unsigned int)((unsigned long)Pfc_uTmp*(unsigned long)Pfcisr.i_Pfc_VbSamUseOLD[J]*(unsigned long)100>>21));//ֱ��*�벨����==����������


        if(Pfc_uTmp >= PFC_IPFC_MAX)
        {
                Pfc_uTmp = PFC_IPFC_MAX;
        }
        else if(Pfc_uTmp <= 0)
        {
                Pfcisr.i_Pfc_Iin_Offset = -128;  //-128
                Pfc_uTmp = 0;
        }

        Pfcisr.i_Pfc_Ref_Currb = Pfc_uTmp;
        //Pfcisr.ui_Pfc_VcSamUse=abs(3*(Pfcisr.ui_Pfc_Adc_Vc- Pfcisr.ui_Pfc_Vin_Offset)-Pfcisr.i_Pfc_VSumSample- Pfcisr.i_Pfc_Vin_Compen);
        Pfcisr.ui_Pfc_VcSamUse=(unsigned int)( abs(3*((signed int)Pfcisr.ui_Pfc_Adc_Vc- (signed int)Pfcisr.ui_Pfc_Vin_Offset - Pfcisr.i_Pfc_VaSamUseOLD[J] -Pfcisr.i_Pfc_VbSamUseOLD[J] /*+Pfcisr.i_Pfc_VcSamUseOLD[J]*/)-Pfcisr.i_Pfc_VSumSample- Pfcisr.i_Pfc_Vin_Compen)); 



        //Pfcisr.ui_Pfc_VcSqrInv=8390; //hsr/20120814 delete

        Pfc_uTmp = (unsigned int)((unsigned long)Pfcisr.ui_Pfc_VPITmp * Pfcisr.ui_Pfc_VcSqrInv >> 16);
        Pfc_uTmp = (unsigned int)((unsigned long)Pfc_uTmp * Pfcisr.ui_Pfc_VcSamUse >> 11);
        // Pfc_uTmp = (unsigned int)((unsigned long)Pfc_uTmp * Pfcisr.ui_Pfc_VcSamUse>> 11 -(unsigned int)((unsigned long)Pfc_uTmp*(unsigned long)Pfcisr.i_Pfc_VcSamUseOLD[J]*(unsigned long)100>>21));//ֱ��*�벨����==����������

        if(Pfc_uTmp >= PFC_IPFC_MAX)
        {
                Pfc_uTmp = PFC_IPFC_MAX;
        }
        else if(Pfc_uTmp <= 0)
        {
                Pfcisr.i_Pfc_Iin_Offset = -128;  //-128
                Pfc_uTmp = 0;
        }

        Pfcisr.i_Pfc_Ref_Currc = Pfc_uTmp;

//////////////�������������� end/////////////////////////////////////////////


//////////////���������Ƽ��� Begin/////////////////////////////////////////////

        Pfcisr.i_Pfc_Adc_Ia = (int)AdcMirror.ADCRESULT3; //1A=5mV*8*5.1k/3k/3*4096=92.843cnt

        if(Pfcisr.ui_Pfc_Adc_Va > Pfcisr.ui_Pfc_Vin_Offset) //0x0800 ������
                Pfcisr.i_Pfc_Adc_Ia = (signed int)(((long)(Pfcisr.i_Pfc_Adc_Ia-Pfcisr.iIaSampSysB)*(signed long)Pfcisr.iIaSampSysA)>>14)-(int)Pfcisr.ui_Pfc_Isample_offset;
        else
                Pfcisr.i_Pfc_Adc_Ia = (signed int)(((long)(Pfcisr.i_Pfc_Adc_Ia+Pfcisr.iIaSampSysB)*(signed long)Pfcisr.iIaSampSysA)>>14)-(int)Pfcisr.ui_Pfc_Isample_offset;


        if(Pfcisr.i_Pfc_Adc_Ia<=0)
        {
                Pfcisr.i_Pfc_Adc_Ia=0;
        }
        ///////////czk061010/////////
        if(Pfcisr.i_Pfc_Adc_Ia>=4000)//������ٰ��ࣿ  1A=5mv*8��*1.7/3*4096=92.8cnt   4000=43A*92.8
        {
                Pfcisr.i_Pfc_Adc_Tzflag=1; //����
        }
        Pfcisr.i_Pfc_Adc_Ia_av=(Pfcisr.i_Pfc_Adc_Ia+Pfcisr.i_Pfc_Adc_Ia_1)>>1;
        Pfcisr.i_Pfc_Adc_Ia_1=Pfcisr.i_Pfc_Adc_Ia;
        ///////////czk061010/////////
        Pfcisr.i_Pfc_Iapi_Err2 = Pfcisr.i_Pfc_Iapi_Err1;
        Pfcisr.i_Pfc_Iapi_Err1 = Pfcisr.i_Pfc_Iapi_Err0;
        Pfcisr.i_Pfc_Iapi_Err0 = Pfcisr.i_Pfc_Ref_Curra + Pfcisr.i_Pfc_Iin_Offset - Pfcisr.i_Pfc_Adc_Ia_av;

        Pfcisr.ui_Pfc_Iapi_Output2 = Pfcisr.ui_Pfc_Iapi_Output1;
        Pfcisr.ui_Pfc_Iapi_Output1 = Pfcisr.ui_Pfc_Iapi_Output0;

        //  Y/X=(K3*Z^2 - K4*Z + K5)/(Z^2 - K1*Z + K2)   q10
        Pfc_TmpLong = (long)((long)Pfcisr.ui_Pfc_Iapi_Output1* Pfcisr.ui_Pfc_Ipi_K1  - (long)Pfcisr.ui_Pfc_Iapi_Output2* Pfcisr.ui_Pfc_Ipi_K2 + (long)Pfcisr.i_Pfc_Iapi_Err0 * Pfcisr.ui_Pfc_Ipi_K3
                             - (long)Pfcisr.i_Pfc_Iapi_Err1 * Pfcisr.ui_Pfc_Ipi_K4 + (long)Pfcisr.i_Pfc_Iapi_Err2 * Pfcisr.ui_Pfc_Ipi_K5 );



        if(Pfc_TmpLong >= (signed long)uiPFCPwmPermit*1024)
        {
                Pfcisr.ui_Pfc_Iapi_Output0 = uiPFCPwmPermit;
        }
        else if(Pfc_TmpLong <= 65536)
        {
                Pfcisr.ui_Pfc_Iapi_Output0 = 64;// �Ŵ���64����ʵ��Ϊ1
        }
        else
        {
                Pfcisr.ui_Pfc_Iapi_Output0 = (unsigned int)(Pfc_TmpLong >> 10);
        }


        Pfcisr.i_Pfc_Adc_Ib = (int)AdcMirror.ADCRESULT4;/////  //1A=5mV*8*5.1k/3k/3*4096=92.843cnt

        if(Pfcisr.ui_Pfc_Adc_Vb > Pfcisr.ui_Pfc_Vin_Offset)
                Pfcisr.i_Pfc_Adc_Ib = (signed int)(((long)(Pfcisr.i_Pfc_Adc_Ib-Pfcisr.iIbSampSysB)*(signed long)Pfcisr.iIbSampSysA)>>14)-(int)Pfcisr.ui_Pfc_Isample_offset;
        else
                Pfcisr.i_Pfc_Adc_Ib = (signed int)(((long)(Pfcisr.i_Pfc_Adc_Ib+Pfcisr.iIbSampSysB)*(signed long)Pfcisr.iIbSampSysA)>>14)-(int)Pfcisr.ui_Pfc_Isample_offset;


        if(Pfcisr.i_Pfc_Adc_Ib<=0)
        {
                Pfcisr.i_Pfc_Adc_Ib=0;
        }
        ///////////czk061010/////////
        if(Pfcisr.i_Pfc_Adc_Ib>=4000)
        {
                Pfcisr.i_Pfc_Adc_Tzflag=1;
        }
        Pfcisr.i_Pfc_Adc_Ib_av=(Pfcisr.i_Pfc_Adc_Ib+Pfcisr.i_Pfc_Adc_Ib_1)>>1;
        Pfcisr.i_Pfc_Adc_Ib_1=Pfcisr.i_Pfc_Adc_Ib;
        ///////////czk061010/////////
        Pfcisr.i_Pfc_Ibpi_Err2 = Pfcisr.i_Pfc_Ibpi_Err1;
        Pfcisr.i_Pfc_Ibpi_Err1 = Pfcisr.i_Pfc_Ibpi_Err0;
        Pfcisr.i_Pfc_Ibpi_Err0 = Pfcisr.i_Pfc_Ref_Currb + Pfcisr.i_Pfc_Iin_Offset - Pfcisr.i_Pfc_Adc_Ib_av;
        Pfcisr.ui_Pfc_Ibpi_Output2 = Pfcisr.ui_Pfc_Ibpi_Output1;
        Pfcisr.ui_Pfc_Ibpi_Output1 = Pfcisr.ui_Pfc_Ibpi_Output0;

//     Pfc_TmpLong = (long)((long)Pfcisr.ui_Pfc_Ibpi_Output1* Pfcisr.ui_Pfc_Ipi_K1 + (long)Pfcisr.i_Pfc_Ibpi_Err0 * Pfcisr.ui_Pfc_Ipi_K3
//                                       - (long)Pfcisr.i_Pfc_Ibpi_Err1 * Pfcisr.ui_Pfc_Ipi_K4 );

        Pfc_TmpLong = (long)((long)Pfcisr.ui_Pfc_Ibpi_Output1* Pfcisr.ui_Pfc_Ipi_K1  - (long)Pfcisr.ui_Pfc_Ibpi_Output2* Pfcisr.ui_Pfc_Ipi_K2 + (long)Pfcisr.i_Pfc_Ibpi_Err0 * Pfcisr.ui_Pfc_Ipi_K3
                             - (long)Pfcisr.i_Pfc_Ibpi_Err1 * Pfcisr.ui_Pfc_Ipi_K4 + (long)Pfcisr.i_Pfc_Ibpi_Err2 * Pfcisr.ui_Pfc_Ipi_K5 );
        if(Pfc_TmpLong >= (signed long)uiPFCPwmPermit*1024)
        {
                Pfcisr.ui_Pfc_Ibpi_Output0 = uiPFCPwmPermit;
        }
        else if(Pfc_TmpLong <= 65536)
        {
                Pfcisr.ui_Pfc_Ibpi_Output0 = 64;
        }
        else
        {
                Pfcisr.ui_Pfc_Ibpi_Output0 = (unsigned int)(Pfc_TmpLong >> 10);
        }


        Pfcisr.i_Pfc_Adc_Ic = (int)AdcMirror.ADCRESULT5;////  //1A=5mV*8*5.1k/3k/3*4096=92.843cnt

        if(Pfcisr.ui_Pfc_Adc_Vc > Pfcisr.ui_Pfc_Vin_Offset)
                Pfcisr.i_Pfc_Adc_Ic = (signed int)(((long)(Pfcisr.i_Pfc_Adc_Ic-Pfcisr.iIcSampSysB)*(signed long)Pfcisr.iIcSampSysA)>>14) - (int)Pfcisr.ui_Pfc_Isample_offset;
        else
                Pfcisr.i_Pfc_Adc_Ic = (signed int)(((long)(Pfcisr.i_Pfc_Adc_Ic+Pfcisr.iIcSampSysB)*(signed long)Pfcisr.iIcSampSysA)>>14) - (int)Pfcisr.ui_Pfc_Isample_offset;


        if(Pfcisr.i_Pfc_Adc_Ic<=0)
        {
                Pfcisr.i_Pfc_Adc_Ic=0;
        }

        if(Pfcisr.i_Pfc_Adc_Ic>=4000)
        {
                Pfcisr.i_Pfc_Adc_Tzflag=1;
        }
        Pfcisr.i_Pfc_Adc_Ic_av=(Pfcisr.i_Pfc_Adc_Ic+Pfcisr.i_Pfc_Adc_Ic_1)>>1;
        Pfcisr.i_Pfc_Adc_Ic_1=Pfcisr.i_Pfc_Adc_Ic;
        ///////////czk061010/////////
        Pfcisr.i_Pfc_Icpi_Err2 = Pfcisr.i_Pfc_Icpi_Err1;
        Pfcisr.i_Pfc_Icpi_Err1 = Pfcisr.i_Pfc_Icpi_Err0;
        Pfcisr.i_Pfc_Icpi_Err0 = Pfcisr.i_Pfc_Ref_Currc + Pfcisr.i_Pfc_Iin_Offset - Pfcisr.i_Pfc_Adc_Ic_av;
        Pfcisr.i_Pfc_Iin_Offset=0;
		
        Pfcisr.ui_Pfc_Icpi_Output2 = Pfcisr.ui_Pfc_Icpi_Output1;
        Pfcisr.ui_Pfc_Icpi_Output1 = Pfcisr.ui_Pfc_Icpi_Output0;

//      Pfc_TmpLong = (long)((long)Pfcisr.ui_Pfc_Icpi_Output1* Pfcisr.ui_Pfc_Ipi_K1 +  (long)Pfcisr.i_Pfc_Icpi_Err0 * Pfcisr.ui_Pfc_Ipi_K3
//                                         - (long)Pfcisr.i_Pfc_Icpi_Err1 * Pfcisr.ui_Pfc_Ipi_K4 );
        Pfc_TmpLong = (long)((long)Pfcisr.ui_Pfc_Icpi_Output1* Pfcisr.ui_Pfc_Ipi_K1  - (long)Pfcisr.ui_Pfc_Icpi_Output2*Pfcisr.ui_Pfc_Ipi_K2 + (long)Pfcisr.i_Pfc_Icpi_Err0 * Pfcisr.ui_Pfc_Ipi_K3
                             - (long)Pfcisr.i_Pfc_Icpi_Err1 * Pfcisr.ui_Pfc_Ipi_K4 + (long)Pfcisr.i_Pfc_Icpi_Err2 * Pfcisr.ui_Pfc_Ipi_K5 );

        if(Pfc_TmpLong >= (signed long)uiPFCPwmPermit*1024)
        {
                Pfcisr.ui_Pfc_Icpi_Output0 = uiPFCPwmPermit;
        }
        else if(Pfc_TmpLong <= 65536)
        {
                Pfcisr.ui_Pfc_Icpi_Output0 = 64;
        }
        else
        {
                Pfcisr.ui_Pfc_Icpi_Output0 = (unsigned int)(Pfc_TmpLong >> 10);
        }

//////////////�����Ƽ��� END/////////////////////////////////////////////
        if(EPwm1Regs.TZFLG.bit.CBC)
        {
                GpioDataRegs.GPATOGGLE.bit.GPIO3 = 1;
        }

        if(EPwm1Regs.TZFLG.bit.CBC||EPwm2Regs.TZFLG.bit.CBC||Pfcisr.i_Pfc_Adc_Tzflag)
        {
                uiPFCPwmPermit = 32000;
                Pfcisr.ui_Pfc_Ilimitflag=1;
                Pfcisr.i_Pfc_Adc_Tzflag=0;
                EALLOW;
                EPwm1Regs.TZCLR.bit.CBC=1;
                EPwm2Regs.TZCLR.bit.CBC=1;
                EDIS;
        }
        else if(Pfcisr.ui_Pfc_Ilimitflag==1)
        {
                if(Pfcisr.ui_Pfc_MainTimer ==6)
                {
                        uiPFCPwmPermit =uiPFCPwmPermit+2;
                        if(uiPFCPwmPermit >= ((unsigned int)EPWM1_MAX_CMPA*64))
                        {
                                Pfcisr.ui_Pfc_Ilimitflag=0;
                                uiPFCPwmPermit = (unsigned int)EPWM1_MAX_CMPA*64;
                        }
                }
        }


        // EPwm1Regs.CMPA.half.CMPA = Pfcisr.ui_Pfc_Iapi_Output0>>6;
        // EPwm1Regs.CMPB =Pfcisr.ui_Pfc_Ibpi_Output0>>6;
        // EPwm2Regs.CMPA.half.CMPA = Pfcisr.ui_Pfc_Icpi_Output0>>6;

        //�������С����������ʽ��ͬ
        Pfcisr.Ia_Trip = 0;
        if(Pfcisr.Ia_Trip==1)
        {
                EPwm1Regs.AQCTLA.bit.CAU = AQ_CLEAR;
                EPwm1Regs.AQCTLA.bit.CAD = AQ_SET;
                EPwm1Regs.CMPA.half.CMPA = Pfcisr.ui_Pfc_Iapi_Output0>>6;
        }
        else //С����
        {
                if(Pfcisr.ui_Pfc_Adc_Va > (Pfcisr.ui_Pfc_Vin_Offset + PFC_VZEROHYS))
                {
                        EPwm1Regs.AQCTLA.bit.CAU = AQ_CLEAR;
                        EPwm1Regs.AQCTLA.bit.CAD = AQ_SET;
                        EPwm1Regs.CMPA.half.CMPA = Pfcisr.ui_Pfc_Iapi_Output0>>6;
                }
                else if(Pfcisr.ui_Pfc_Adc_Va < (Pfcisr.ui_Pfc_Vin_Offset - PFC_VZEROHYS))//С��������ʹBUS����ڷ��࣬Ӱ��Ҳ����
                {
                        EPwm1Regs.AQCTLA.bit.CAU = AQ_SET;
                        EPwm1Regs.AQCTLA.bit.CAD = AQ_CLEAR;
                        EPwm1Regs.CMPA.half.CMPA = EPWM1_TIMER_1 - (Pfcisr.ui_Pfc_Iapi_Output0>>6);
                }
        }

        if(Pfcisr.Ia_Trip==1) //�����
        {
                EPwm1Regs.AQCTLB.bit.CBU = AQ_CLEAR;
                EPwm1Regs.AQCTLB.bit.CBD = AQ_SET;
                EPwm1Regs.CMPB =Pfcisr.ui_Pfc_Ibpi_Output0>>6;
        }
        else //С����
        {
                if(Pfcisr.ui_Pfc_Adc_Vb > (Pfcisr.ui_Pfc_Vin_Offset + PFC_VZEROHYS))
                {
                        EPwm1Regs.AQCTLB.bit.CBU = AQ_CLEAR;
                        EPwm1Regs.AQCTLB.bit.CBD = AQ_SET;
                        EPwm1Regs.CMPB =Pfcisr.ui_Pfc_Ibpi_Output0>>6;
                }
                else if(Pfcisr.ui_Pfc_Adc_Vb < (Pfcisr.ui_Pfc_Vin_Offset - PFC_VZEROHYS))
                {
                        EPwm1Regs.AQCTLB.bit.CBU = AQ_SET;
                        EPwm1Regs.AQCTLB.bit.CBD =AQ_CLEAR;
                        EPwm1Regs.CMPB = EPWM1_TIMER_1 - (Pfcisr.ui_Pfc_Ibpi_Output0>>6);
                }
        }

        //������ʽ�л�
        if(Pfcisr.Ia_Trip==1)//�����
        {
                EPwm2Regs.AQCTLA.bit.CAU = AQ_CLEAR;
                EPwm2Regs.AQCTLA.bit.CAD = AQ_SET;
                EPwm2Regs.CMPA.half.CMPA = Pfcisr.ui_Pfc_Icpi_Output0>>6;
        }
        else
        {
                if(Pfcisr.ui_Pfc_Adc_Vc > (Pfcisr.ui_Pfc_Vin_Offset + PFC_VZEROHYS))
                {
                        EPwm2Regs.AQCTLA.bit.CAU = AQ_CLEAR;
                        EPwm2Regs.AQCTLA.bit.CAD = AQ_SET;
                        EPwm2Regs.CMPA.half.CMPA = Pfcisr.ui_Pfc_Icpi_Output0>>6;
                }
                else if(Pfcisr.ui_Pfc_Adc_Vc < (Pfcisr.ui_Pfc_Vin_Offset - PFC_VZEROHYS))
                {
                        EPwm2Regs.AQCTLA.bit.CAU = AQ_SET;
                        EPwm2Regs.AQCTLA.bit.CAD = AQ_CLEAR;
                        EPwm2Regs.CMPA.half.CMPA = EPWM1_TIMER_1 - (Pfcisr.ui_Pfc_Icpi_Output0>>6);
                }
        }



        ///////////////////////////////////////////////////////////
        if(Pfcisr.ui_Pfc_MainTimer ==2)//����AB�ߵ�ѹ
        {
                Pfcisr.ui_Pfc_VabSamUse=abs(3*((int)Pfcisr.ui_Pfc_Adc_Va-(int)Pfcisr.ui_Pfc_Adc_Vb)); //����3���ٳ���3
                Pfcisr.ui_Pfc_VabRmstmpUse1=Pfcisr.ui_Pfc_VabRmstmpUse;
                //K1+2*K2==65535
                Pfc_TmpLong=(long)Pfcisr.ui_Pfc_VabRmstmpUse1*Pfcisr.ui_Pfc_VrmsK1+
                            (long)((Pfcisr.ui_Pfc_VabSamUse+Pfcisr.ui_Pfc_VabSamtmpUse1))*Pfcisr.ui_Pfc_VrmsK2;
                Pfcisr.ui_Pfc_VabRmstmpUse=Pfc_TmpLong>>16;
                Pfcisr.ui_Pfc_VabSamtmpUse1=Pfcisr.ui_Pfc_VabSamUse;

                //�����˲�
                Pfcisr.ui_Pfc_VabRmsUse1=Pfcisr.ui_Pfc_VabRmsUse;
                Pfc_TmpLong=(long)Pfcisr.ui_Pfc_VabRmsUse1*Pfcisr.ui_Pfc_VrmsK1+
                            (long)((Pfcisr.ui_Pfc_VabRmstmpUse+Pfcisr.ui_Pfc_VabSamUse1))*Pfcisr.ui_Pfc_VrmsK2;
                Pfcisr.ui_Pfc_VabRmsUse=Pfc_TmpLong>>16;
                Pfcisr.ui_Pfc_VabSamUse1=Pfcisr.ui_Pfc_VabRmstmpUse;


                if(Pfcisr.ui_Pfc_VabRmsUse>=3*Pfc_Vrmsuplimit)
                {
                        Pfcisr.ui_Pfc_VabRmsUse=3*Pfc_Vrmsuplimit;
                }
                else if(Pfcisr.ui_Pfc_VabRmsUse<=3*Pfc_Vrmsdnlimit)
                {
                        Pfcisr.ui_Pfc_VabRmsUse=3*Pfc_Vrmsdnlimit;
                }
                if(Pfcisr.ui_Pfc_Adc_Va>Pfcisr.ui_Pfc_Adc_VaMax)
                {
                        Pfcisr.ui_Pfc_Adc_VaMax=Pfcisr.ui_Pfc_Adc_Va;
                }
        }

        if(Pfcisr.ui_Pfc_MainTimer ==3)//����BC�ߵ�ѹ
        {
                Pfcisr.ui_Pfc_VbcSamUse=abs(3*((int)Pfcisr.ui_Pfc_Adc_Vb-(int)Pfcisr.ui_Pfc_Adc_Vc));
                Pfcisr.ui_Pfc_VbcRmstmpUse1=Pfcisr.ui_Pfc_VbcRmstmpUse;
                //K1+2*K2==65535
                Pfc_TmpLong=(long)Pfcisr.ui_Pfc_VbcRmstmpUse1*Pfcisr.ui_Pfc_VrmsK1+
                            (long)((Pfcisr.ui_Pfc_VbcSamUse+Pfcisr.ui_Pfc_VbcSamtmpUse1))*Pfcisr.ui_Pfc_VrmsK2;
                Pfcisr.ui_Pfc_VbcRmstmpUse=Pfc_TmpLong>>16;
                Pfcisr.ui_Pfc_VbcSamtmpUse1=Pfcisr.ui_Pfc_VbcSamUse;

                //�����˲�
                Pfcisr.ui_Pfc_VbcRmsUse1=Pfcisr.ui_Pfc_VbcRmsUse;
                Pfc_TmpLong=(long)Pfcisr.ui_Pfc_VbcRmsUse1*Pfcisr.ui_Pfc_VrmsK1+
                            (long)((Pfcisr.ui_Pfc_VbcRmstmpUse+Pfcisr.ui_Pfc_VbcSamUse1))*Pfcisr.ui_Pfc_VrmsK2;
                Pfcisr.ui_Pfc_VbcRmsUse=Pfc_TmpLong>>16;
                Pfcisr.ui_Pfc_VbcSamUse1=Pfcisr.ui_Pfc_VbcRmstmpUse;


                if(Pfcisr.ui_Pfc_VbcRmsUse>=3*Pfc_Vrmsuplimit)
                {
                        Pfcisr.ui_Pfc_VbcRmsUse=3*Pfc_Vrmsuplimit;
                }
                else if(Pfcisr.ui_Pfc_VbcRmsUse<=3*Pfc_Vrmsdnlimit)
                {
                        Pfcisr.ui_Pfc_VbcRmsUse=3*Pfc_Vrmsdnlimit;
                }
                if(Pfcisr.ui_Pfc_Adc_Vb>Pfcisr.ui_Pfc_Adc_VbMax)
                {
                        Pfcisr.ui_Pfc_Adc_VbMax=Pfcisr.ui_Pfc_Adc_Vb;
                }
        }
        if(Pfcisr.ui_Pfc_MainTimer ==5)//����CA�ߵ�ѹ
        {
                Pfcisr.ui_Pfc_VcaSamUse=abs(3*((int)Pfcisr.ui_Pfc_Adc_Vc-(int)Pfcisr.ui_Pfc_Adc_Va));
                Pfcisr.ui_Pfc_VcaRmstmpUse1=Pfcisr.ui_Pfc_VcaRmstmpUse;
                //K1+2*K2==65535
                Pfc_TmpLong=(long)Pfcisr.ui_Pfc_VcaRmstmpUse1*Pfcisr.ui_Pfc_VrmsK1+
                            (long)((Pfcisr.ui_Pfc_VcaSamUse+Pfcisr.ui_Pfc_VcaSamtmpUse1))*Pfcisr.ui_Pfc_VrmsK2;
                Pfcisr.ui_Pfc_VcaRmstmpUse=Pfc_TmpLong>>16;
                Pfcisr.ui_Pfc_VcaSamtmpUse1=Pfcisr.ui_Pfc_VcaSamUse;

                //�����˲�
                Pfcisr.ui_Pfc_VcaRmsUse1=Pfcisr.ui_Pfc_VcaRmsUse;
                Pfc_TmpLong=(long)Pfcisr.ui_Pfc_VcaRmsUse1*Pfcisr.ui_Pfc_VrmsK1+
                            (long)((Pfcisr.ui_Pfc_VcaRmstmpUse+Pfcisr.ui_Pfc_VcaSamUse1))*Pfcisr.ui_Pfc_VrmsK2;
                Pfcisr.ui_Pfc_VcaRmsUse=Pfc_TmpLong>>16;
                Pfcisr.ui_Pfc_VcaSamUse1=Pfcisr.ui_Pfc_VcaRmstmpUse;


                if(Pfcisr.ui_Pfc_VcaRmsUse>=3*Pfc_Vrmsuplimit)
                {
                        Pfcisr.ui_Pfc_VcaRmsUse=3*Pfc_Vrmsuplimit;
                }
                else if(Pfcisr.ui_Pfc_VcaRmsUse<=3*Pfc_Vrmsdnlimit)
                {
                        Pfcisr.ui_Pfc_VcaRmsUse=3*Pfc_Vrmsdnlimit;
                }
                if(Pfcisr.ui_Pfc_Adc_Vc>Pfcisr.ui_Pfc_Adc_VcMax)
                {
                        Pfcisr.ui_Pfc_Adc_VcMax=Pfcisr.ui_Pfc_Adc_Vc;
                }
        }

        if(Pfcisr.ui_Pfc_MainTimer ==7)//��ѹ���
        {
                if(((unsigned int)AdcMirror.ADCRESULT8)> 4050)
                {
                        Pfcisr.ui_Pfc_OvpTime =Pfcisr.ui_Pfc_OvpTime+1;
                }
                else if((((unsigned int)AdcMirror.ADCRESULT8)> 4000)&&(Pfcisr.ui_Pfc_OvpFlag))
                {
                        Pfcisr.ui_Pfc_OvpTime =Pfcisr.ui_Pfc_OvpTime+1;
                }
                else
                {
                        Pfcisr.ui_Pfc_OvpTime =0;
                        Pfcisr.ui_Pfc_OvpFlag =0;
                }

                if(Pfcisr.ui_Pfc_OvpTime>=100)
                {
                        Pfcisr.ui_Pfc_OvpFlag =1;
                        Pfcisr.ui_Pfc_OvpTime=100;
                }

                if(((unsigned int)AdcMirror.ADCRESULT9)> 4050)
                {
                        Pfcisr.ui_Pfc_OvnTime =Pfcisr.ui_Pfc_OvnTime+1;
                }
                else if((((unsigned int)AdcMirror.ADCRESULT9)> 4000)&&(Pfcisr.ui_Pfc_OvnFlag))
                {
                        Pfcisr.ui_Pfc_OvnTime =Pfcisr.ui_Pfc_OvnTime+1;
                }
                else
                {
                        Pfcisr.ui_Pfc_OvnTime =0;
                        Pfcisr.ui_Pfc_OvnFlag =0;
                }

                if(Pfcisr.ui_Pfc_OvnTime>=100)
                {
                        Pfcisr.ui_Pfc_OvnFlag =1;
                        Pfcisr.ui_Pfc_OvnTime=100;
                }

        }


        if((Pfcisr.i_Pfc_Adc_Ia>1600)||(Pfcisr.i_Pfc_Adc_Ib>1600)||(Pfcisr.i_Pfc_Adc_Ic>1600)||(Pfcisr.Ib_Trip==0))
        {
                Pfcisr.Ia_TimeTrip++;
                Pfcisr.Ia_Time=0;
                if(Pfcisr.Ia_TimeTrip)
                {
                        Pfcisr.Ia_Trip=0;
                        Pfcisr.Ia_TimeTrip=1;
                }
        }
        else if ((Pfcisr.i_Pfc_Adc_Ia<1100)&&(Pfcisr.i_Pfc_Adc_Ib<1100)&&(Pfcisr.i_Pfc_Adc_Ic<1100)&&(Pfcisr.Ib_Trip))
        {
                Pfcisr.Ia_Time++;
                Pfcisr.Ia_TimeTrip=0;
        }
        if(Pfcisr.Ia_Time>=45000)
        {
                Pfcisr.Ia_Time=45000;
                Pfcisr.Ia_Trip=1;
        }



        Pfcisr.ui_Pfc_FanTimer++;
        if(Pfcisr.ui_Pfc_FanTimer>=99)
        {
                Pfcisr.ui_Pfc_FanTimer=0;
        }

        if(Pfcisr.ui_Pfc_FanTimer==1)
        {
                GpioDataRegs.GPASET.bit.GPIO4 = 1; //����ת
        }
        //========cxk==============//
//        tempdata_save();
        if((uiNeedFanFlag == 1)||(FanCnt < 2400))
        {
//                if(Pfcisr.ui_Pfc_FanPwm > 95)
//                {
//                        Pfcisr.ui_Pfc_FanPwm= 95;
//                }
//
//                if(Pfcisr.ui_Pfc_FanPwm < 26)
//                {
//                        Pfcisr.ui_Pfc_FanPwm= 26;
//                }

                if(Pfcisr.ui_Pfc_FanTimer>=Pfcisr.ui_Pfc_FanPwm)
                {
                        GpioDataRegs.GPACLEAR.bit.GPIO4 = 1;
                }
        }
        else
        {
              GpioDataRegs.GPACLEAR.bit.GPIO4 = 1;
		}

        AdcRegs.ADCTRL2.bit.RST_SEQ1 = 1;
        EPwm3Regs.ETCLR.bit.INT = 1;
        PieCtrlRegs.PIEACK.all = PIEACK_GROUP3;
//===========================================================================
// No more.
//===========================================================================
}

//void tempdata_save()    //���ڱ������ݱ���CCS�ڲ�ʾ�����۲�
//{
//        save_count++;
//        if(save_count>=80)
//        {
//                save_count=0;
//                // data_save1[save_index]=(signed int) Pfcisr.ui_Pfc_Ibpi_Output0;
//                // data_save2[save_index]=(signed int) Pfcisr.i_Pfc_VSumSample;
//                uiRYSumACa +=abs(((long)Pfcisr.ui_Pfc_Adc_Va)-2048);
//                uiRYSumACb +=abs(((long)Pfcisr.ui_Pfc_Adc_Vb)-2048);
//                uiRYSumACc +=abs(((long)Pfcisr.ui_Pfc_Adc_Vc)-2048);
//                save_index++;
//                if(save_index>=45)
//                {
//                        save_index=0;
//                        uiACYYa=(signed int)(uiRYSumACa>>2);
//                        uiACYYb=(signed int)(uiRYSumACb>>2);
//                        uiACYYc=(signed int)(uiRYSumACc>>2);
//                        uiRYSumACa=0;
//                        uiRYSumACb=0;
//                        uiRYSumACc=0;
//                }
//        }
//}

