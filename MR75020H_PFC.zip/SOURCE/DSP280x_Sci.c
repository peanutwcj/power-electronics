//#########################################################
//
// FILE:	DSP280x_Sci.c
//
// TITLE:	DSP280x SCI Initialization & Support Functions.
//
//#########################################################
// Running on TMS320LF280xA   PFC part  h741Au1(1.00)
// External clock is 20MHz, PLL * 10/2 , CPU-Clock 100 MHz	      
// Date: from May 23, 2005 to Oct 30, 2006  , (C) www & mhp & lsy & lyg
// Version:1.00     Change Date: May 24, 2005 , 
//#########################################################

#include "DSP280x_Device.h"     // DSP280x Headerfile Include File

//---------------------------------------------------------------------------
// InitSci: 
//---------------------------------------------------------------------------
// This function initializes the SCI(s) to a known state.
//
void scia_fifo_init(void);
void scib_fifo_init(void);	
void InitSci(void)
{
	// Initialize SCI-A:

	InitSciGpio();
	
	SciaRegs.SCICCR.all = 0x0027;   // 1 stop bit, odd parity,8 char bits, async mode, idle-line
	//SciaRegs.SCICTL1.all = 0x0000;  // enable RX, reset SCI, disable RX ERR, SLEEP, TXWAKE
	SciaRegs.SCICTL1.all = 0x0003;  // bit0,enable RX, bit5,reset SCI, bit1,enable TX
	SciaRegs.SCICTL2.all = 0x0000; 
	SciaRegs.SCIHBAUD = 0x0000;  	// 9600*2=19200 baud @LSPCLK = 25MHz. 
	SciaRegs.SCILBAUD = 0x00A2;

//////////////////mhping060906//////////////
	SciaRegs.SCIRXST.all = 0x00;   //Read access only
	SciaRegs.SCIRXEMU    = 0x00;   //Read access only
	SciaRegs.SCIRXBUF.all= 0x00;
	//rsvd1;   
	SciaRegs.SCITXBUF    = 0x00;
	//SciaRegs.SCIFFTX.all =; 
	//SciaRegs.SCIFFRX.all =; 
	//SciaRegs.SCIFFCT.all =; 
	//rsvd2;   
	//rsvd3;   
	SciaRegs.SCIPRI.all  =0x10;  // 1 0 Complete current receive/transmit sequence before stopping 


///////////////mhping060906////////////////

	
	SciaRegs.SCICTL1.all = 0x0023;  // Relinquish SCI from Reset 

	/*               //czk060906
	// Initialize SCI-B:
       ScibRegs.SCICCR.all = 0x0027;   // 1 stop bit, odd parity,8 char bits, async mode, idle-line
	ScibRegs.SCICTL1.all = 0x0003;  // enable TX, reset SCI, disable RX ERR, SLEEP, TXWAKE
	ScibRegs.SCICTL2.all = 0x0000; 
	ScibRegs.SCIHBAUD = 0x0000;  	// 9600*2 baud @LSPCLK = 25MHz. 
	ScibRegs.SCILBAUD = 0x00A2;
	ScibRegs.SCICTL1.all = 0x0023;  // Relinquish SCI from Reset 
	//tbd...
	*/ 
       scia_fifo_init();
       //scib_fifo_init();	//czk060906
}	

//---------------------------------------------------------------------------
// Example: InitSciGpio: 
//---------------------------------------------------------------------------
// This function initializes GPIO pins to function as SCI pins
//
// Each GPIO pin can be configured as a GPIO pin or up to 3 different
// peripheral functional pins. By default all pins come up as GPIO
// inputs after reset.  
// 
// Caution: 
// Only one GPIO pin should be enabled for SCITXDA/B operation.
// Only one GPIO pin shoudl be enabled for SCIRXDA/B operation. 
// Comment out other unwanted lines.

void InitSciGpio()
{
   InitSciaGpio();   
   //InitScibGpio();   
}

void InitSciaGpio()
{
   EALLOW;

/* Enable internal pull-up for the selected pins */
// Pull-ups can be enabled or disabled disabled by the user.  
// This will enable the pullups for the specified pins.

	GpioCtrlRegs.GPAPUD.bit.GPIO28 = 0;    // Enable pull-up for GPIO28 (SCIRXDA)
	GpioCtrlRegs.GPAPUD.bit.GPIO29 = 0;	   // Enable pull-up for GPIO29 (SCITXDA)

/* Set qualification for selected pins to asynch only */
// Inputs are synchronized to SYSCLKOUT by default.  
// This will select asynch (no qualification) for the selected pins.

	GpioCtrlRegs.GPAQSEL2.bit.GPIO28 = 3;  // Asynch input GPIO28 (SCIRXDA)

/* Configure SCI-A pins using GPIO regs*/
// This specifies which of the possible GPIO pins will be SCI functional pins.

	GpioCtrlRegs.GPAMUX2.bit.GPIO28 = 1;   // Configure GPIO28 for SCIRXDA operation
	GpioCtrlRegs.GPAMUX2.bit.GPIO29 = 1;   // Configure GPIO29 for SCITXDA operation
	
    EDIS;
}
void scia_fifo_init()										
{
    SciaRegs.SCIFFTX.all=0xE040; //1110 0000 0100 0000B
    SciaRegs.SCIFFRX.all=0x204f; //0110 0000 0100 1111B
    SciaRegs.SCIFFCT.all=0x00;    //   C8=200
}  


void scib_fifo_init()										
{
    ScibRegs.SCIFFTX.all=0xE040; //1110 0000 0100 0000B
    ScibRegs.SCIFFRX.all=0x204f; //0110 0000 0100 1111B
    ScibRegs.SCIFFCT.all=0x0;    //
    
}  
	
//===========================================================================
// End of file.
//===========================================================================
