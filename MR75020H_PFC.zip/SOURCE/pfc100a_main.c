//#########################################################
//
// FILE:        pfc100a_main.c
//
// TITLE:       DSP280x pfc100a main Functions.
//
//#########################################################
// Running on TMS320LF280xA   PFC part   h741Au1(1.00)
// External clock is 20MHz, PLL * 10/2 , CPU-Clock 100 MHz
// Date: from May 23, 2005 to Oct 30, 2006  , (C) www & mhp & lsy & lyg
// Version:1.00     Change Date: May 24, 2005 , (C) www & mhp & lsy & lyg
// Version:1.00.01   Change Date: Aug 24, 2006 , (C) czk
// Version:1.00.02   Change Date: Dec 31, 2007 , (C) czk
//#########################################################

#include "DSP280x_Device.h"     // DSP280x Headerfile Include File
#include "pfc100a_main.h"

#define cPfcFirmwareVer  0x0304      //hsr/20120726 add  , PFC�̼��汾��  1.01

//hsr/20120628 add begin
unsigned int uiFanRatio;
float fFanRatio_Temp;
float fFanRatio_Curr;
//Uint16 LxkBoostState = 1;
//hsr/20120628 add end
Uint32 uFant = 0;
Uint16 uiVoltAcPhase = 0; //hsr/20120814
Uint32 udwTemp = 0;       //hsr/20120814
Uint16 ucFanFaultCount=0;
Uint16 ucFanFaultBackCount=0;
extern signed    int  uiACYYa;
extern signed    int  uiACYYb;
extern signed    int  uiACYYc;
unsigned char uiFlagLostAC=0;
unsigned char uiNeedFanFlag=0;
Uint32 FanCnt=2400;
unsigned char uiVoltUpOverCount=0;
unsigned char uiVoltDnOverCount=0;
unsigned char uiVoltBlaneOverCount=0;

void (*p_SoftStart)(void)  = 0;
void (*p_AdcTrement)(void) = 0;
void (*p_IoPortCtrl)(void) = 0;
//���� ģʽʶ������ݽṹ
struct IptModeIdentify_Stru
{
	//�������ZeroCrossingCounter
	unsigned int a_ZCC;
	unsigned int b_ZCC;
	unsigned int c_ZCC;
	unsigned int a_state;
	unsigned int b_state;
	unsigned int c_state;
	unsigned int  b_OVT;
	unsigned int  c_OVT;
	//ϵͳ����ģʽ 1=����ģʽ  2=ֱ��ģʽ
	unsigned int SysInputMode;
}IptModeIdentifyData;
//���ݳ�ʼ��
void Identification_Init();
//ģʽʶ��
void ModeIdentification();
void pfcDataInit(void);
void boostDataInit(void);
void pfcStartCtrl(void);
void boostStartCtrl(void);
void pfcIoPortCtrl(void);
void boostIoPortCtrl(void);
void pfcAdcTreatment(void);
void boostAdcTerment(void);
unsigned int VsetMin = 50;
unsigned long InputCurMax = 0;
unsigned int FanPwm = 0;
static const Uint16 aucCRCHi[] =
{
        0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41,
        0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40,
        0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41,
        0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,
        0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41,
        0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40,
        0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40,
        0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40,
        0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41,
        0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40,
        0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41,
        0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,
        0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41,
        0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,
        0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,
        0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,
        0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41,
        0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40,
        0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41,
        0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,
        0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41,
        0x00, 0xC1, 0x81, 0x40
};

static const unsigned char aucCRCLo[] =
{
        0x00, 0xC0, 0xC1, 0x01, 0xC3, 0x03, 0x02, 0xC2, 0xC6, 0x06, 0x07, 0xC7,
        0x05, 0xC5, 0xC4, 0x04, 0xCC, 0x0C, 0x0D, 0xCD, 0x0F, 0xCF, 0xCE, 0x0E,
        0x0A, 0xCA, 0xCB, 0x0B, 0xC9, 0x09, 0x08, 0xC8, 0xD8, 0x18, 0x19, 0xD9,
        0x1B, 0xDB, 0xDA, 0x1A, 0x1E, 0xDE, 0xDF, 0x1F, 0xDD, 0x1D, 0x1C, 0xDC,
        0x14, 0xD4, 0xD5, 0x15, 0xD7, 0x17, 0x16, 0xD6, 0xD2, 0x12, 0x13, 0xD3,
        0x11, 0xD1, 0xD0, 0x10, 0xF0, 0x30, 0x31, 0xF1, 0x33, 0xF3, 0xF2, 0x32,
        0x36, 0xF6, 0xF7, 0x37, 0xF5, 0x35, 0x34, 0xF4, 0x3C, 0xFC, 0xFD, 0x3D,
        0xFF, 0x3F, 0x3E, 0xFE, 0xFA, 0x3A, 0x3B, 0xFB, 0x39, 0xF9, 0xF8, 0x38,
        0x28, 0xE8, 0xE9, 0x29, 0xEB, 0x2B, 0x2A, 0xEA, 0xEE, 0x2E, 0x2F, 0xEF,
        0x2D, 0xED, 0xEC, 0x2C, 0xE4, 0x24, 0x25, 0xE5, 0x27, 0xE7, 0xE6, 0x26,
        0x22, 0xE2, 0xE3, 0x23, 0xE1, 0x21, 0x20, 0xE0, 0xA0, 0x60, 0x61, 0xA1,
        0x63, 0xA3, 0xA2, 0x62, 0x66, 0xA6, 0xA7, 0x67, 0xA5, 0x65, 0x64, 0xA4,
        0x6C, 0xAC, 0xAD, 0x6D, 0xAF, 0x6F, 0x6E, 0xAE, 0xAA, 0x6A, 0x6B, 0xAB,
        0x69, 0xA9, 0xA8, 0x68, 0x78, 0xB8, 0xB9, 0x79, 0xBB, 0x7B, 0x7A, 0xBA,
        0xBE, 0x7E, 0x7F, 0xBF, 0x7D, 0xBD, 0xBC, 0x7C, 0xB4, 0x74, 0x75, 0xB5,
        0x77, 0xB7, 0xB6, 0x76, 0x72, 0xB2, 0xB3, 0x73, 0xB1, 0x71, 0x70, 0xB0,
        0x50, 0x90, 0x91, 0x51, 0x93, 0x53, 0x52, 0x92, 0x96, 0x56, 0x57, 0x97,
        0x55, 0x95, 0x94, 0x54, 0x9C, 0x5C, 0x5D, 0x9D, 0x5F, 0x9F, 0x9E, 0x5E,
        0x5A, 0x9A, 0x9B, 0x5B, 0x99, 0x59, 0x58, 0x98, 0x88, 0x48, 0x49, 0x89,
        0x4B, 0x8B, 0x8A, 0x4A, 0x4E, 0x8E, 0x8F, 0x4F, 0x8D, 0x4D, 0x4C, 0x8C,
        0x44, 0x84, 0x85, 0x45, 0x87, 0x47, 0x46, 0x86, 0x82, 0x42, 0x43, 0x83,
        0x41, 0x81, 0x80, 0x40
};

Uint16 usMBCRC16( unsigned char * pucFrame, Uint16 usLen )
{
        Uint16           ucCRCHi = 0xFF;
        unsigned char           ucCRCLo = 0xFF;
        Uint16             iIndex;

        while( usLen-- )
        {
                iIndex = ucCRCLo ^ *( pucFrame++ );
                ucCRCLo = ( unsigned char )( ucCRCHi ^ aucCRCHi[iIndex] );
                ucCRCHi = aucCRCLo[iIndex];
                KickDog();
        }
        return ( Uint16 )( ucCRCHi << 8 | ucCRCLo );
}
void main(void)
{

        InitSysCtrl();
        MemCopy(&RamfuncsLoadStart, &RamfuncsLoadEnd, &RamfuncsRunStart);  //czk061020  Flash->RAM
        InitFlash();
        InitGpio();
        DINT;
        InitPieCtrl();
        IER = 0x0000;
        IFR = 0x0000;
        InitPieVectTable();
        EALLOW;
        PieVectTable.SEQ1INT = &Identification_Isr; //ADC �ж�
        EDIS;
        PieCtrlRegs.PIEIER1.bit.INTx1= 1;
        InitPeripherals();
    	EPwm1Regs.AQCSFRC.all = 0x05;    //PWM1A,PWM1B force low
    	EPwm2Regs.AQCSFRC.all = 0x05;    //PWM2A,PWM2B force low
     	GpioDataRegs.GPACLEAR.bit.GPIO6 = 1;
    	GpioDataRegs.GPACLEAR.bit.GPIO11 = 1;
        IER |= M_INT1;
        EINT;
        ERTM;
        //ģʽʶ�𲿷����ݳ�ʼ��
entry:  Identification_Init();
        ModeIdentification();
        DINT;
        IER = 0x0000;
        if(0x4F75 == IptModeIdentifyData.SysInputMode)
        {
        	GpioDataRegs.GPATOGGLE.bit.GPIO11 = 1;//ֱ��ָʾ��
        	boostDataInit();
            EALLOW;
            PieVectTable.SEQ1INT = &boostMode_Isr;
            EDIS;
            PieCtrlRegs.PIEIER3.bit.INTx3 = 0;              //czk060906
            PieCtrlRegs.PIEIER1.bit.INTx1 = 1;
            IER |= M_INT1;
        }
        else if(0x7D5C == IptModeIdentifyData.SysInputMode) //����ģʽ
//        else
        {
    		GpioDataRegs.GPASET.bit.GPIO6 = 1;   //����ָʾ��
    		pfcDataInit();
    		vLimitInit();
            EALLOW;
            PieVectTable.EPWM3_INT = &pfc_isr;
            EDIS;
            PieCtrlRegs.PIEIER3.bit.INTx3 = 1;              //czk060906
            PieCtrlRegs.PIEIER1.bit.INTx1 = 0;
            IER |= M_INT3;
        }
        else
        {
            IER |= M_INT1;
            EINT;
//            ERTM;
            goto entry;
        }

        EINT;
        for(;;)
        {
//                KickDog();
        	if(p_SoftStart  != 0) p_SoftStart();  /* ���������� */
        	if(p_IoPortCtrl != 0) p_IoPortCtrl(); /* IO���������� */
            vGetSciData();                  /* SciaGetͨ�����ݴ��� */
            vSendSciData();                 /* SciaSendͨ�����ݴ��� */
            if(p_AdcTrement != 0) p_AdcTrement(); /* AD�������� */
            vMtimerTreat();                 /* ����ʱ����ʱ���� */
            vCircuitCal();                  /* ��ѹ,����,�޹��ʼ��� */
        }
}
void Identification_Init()
{
    Uint16 i,j;
    Uint16 *addr;
    for(i=0x8700; i<0x9000; i++)//��DSP�ͺ����
    {
            addr = (unsigned int *)i;
            *addr=0;
    }
	for(j = 0;j < 11;j++)
	{
	    for(i = 0;i < 41;i++)
	    {
			ulAdcData[j][i] = 0;
	    }
		ulAdSum[j] = 0;
	}
    IptModeIdentifyData.SysInputMode = 0;
    IptModeIdentifyData.a_ZCC = 0;
    IptModeIdentifyData.a_state = 0;
    IptModeIdentifyData.b_OVT = 0;
    IptModeIdentifyData.b_ZCC = 0;
    IptModeIdentifyData.b_state = 0;
    IptModeIdentifyData.c_OVT = 0;
    IptModeIdentifyData.c_ZCC = 0;
    IptModeIdentifyData.c_state = 0;
    ucEepromErr = 0;
    uiActionReady = 0;
    ulIoPfcStatus[1].all = 0;
    ulIoPfcStatus[0].all = 0;
    ulPfcStatus.all = 0;
}
//#define WDOWCPR_MAX      (unsigned int)2625    //140V
//#define WDOWCPR_MIN      (unsigned int)1471	   //-140V
#define WDOWCPR_MAX      (unsigned int)2460    //100V
#define WDOWCPR_MIN      (unsigned int)1635	   //-100V
//����ģʽʶ��
void ModeIdentification()
{
	static unsigned int  bitFlag = 0;
	bitFlag = 0;
	uiBaseTimer5 = 0;
	while(uiBaseTimer5 <= 40)//ͳ��200ms�ڵĹ������
	{
		if(Pfcisr.ui_Pfc_Adc_Va > WDOWCPR_MAX)
		{
			if(IptModeIdentifyData.a_state == 2)
				IptModeIdentifyData.a_ZCC++;
			IptModeIdentifyData.a_state = 1;
		}
		else if(Pfcisr.ui_Pfc_Adc_Va < WDOWCPR_MIN)
		{
			if(IptModeIdentifyData.a_state == 1)
				IptModeIdentifyData.a_ZCC++;
			IptModeIdentifyData.a_state = 2;
		}
		if(Pfcisr.ui_Pfc_Adc_Vb > WDOWCPR_MAX)
		{
			if(IptModeIdentifyData.b_state == 2)
				IptModeIdentifyData.b_ZCC++;
			IptModeIdentifyData.b_state = 1;
			IptModeIdentifyData.b_OVT = 0;
		}
		else if(Pfcisr.ui_Pfc_Adc_Vb < WDOWCPR_MIN)
		{
			if(IptModeIdentifyData.b_state == 1)
				IptModeIdentifyData.b_ZCC++;
			IptModeIdentifyData.b_state = 2;
		}
		if(Pfcisr.ui_Pfc_Adc_Vc > WDOWCPR_MAX)
		{
			if(IptModeIdentifyData.c_state == 2)
				IptModeIdentifyData.c_ZCC++;
			IptModeIdentifyData.c_state = 1;
		}
		else if(Pfcisr.ui_Pfc_Adc_Vc < WDOWCPR_MIN)
		{
			if(IptModeIdentifyData.c_state == 1)
				IptModeIdentifyData.c_ZCC++;
			IptModeIdentifyData.c_state = 2;
			IptModeIdentifyData.c_OVT = 0;
		}
		if (CpuTimer0Regs.TCR.bit.TIF)  //5ms
		{
			CpuTimer0Regs.TCR.bit.TIF = 1;
			uiBaseTimer5++;
			if((uiBaseTimer5 % 10) == 0)
	            GpioDataRegs.GPATOGGLE.bit.GPIO6 = 1;    //��������ָʾ��
			if(IptModeIdentifyData.b_state == 2) IptModeIdentifyData.b_OVT++;
			else 	IptModeIdentifyData.b_OVT = 0;

			if(IptModeIdentifyData.c_state == 1) IptModeIdentifyData.c_OVT++;
			else 	IptModeIdentifyData.c_OVT = 0;
		}
	}
	if((IptModeIdentifyData.c_ZCC >= 13) && (IptModeIdentifyData.c_ZCC <= 30)) bitFlag |= 0x01;
	else bitFlag &= 0xFE;

	if((IptModeIdentifyData.b_ZCC >= 13) && (IptModeIdentifyData.b_ZCC <= 30)) bitFlag |= 0x02;
	else bitFlag &= 0xFD;

	if((IptModeIdentifyData.a_ZCC >= 13) && (IptModeIdentifyData.a_ZCC <= 30)) bitFlag |= 0x04;
	else bitFlag &= 0xFB;
	if(bitFlag == 0x07)
		IptModeIdentifyData.SysInputMode = 0x7D5C;//����ģʽ
	else if((IptModeIdentifyData.b_OVT >= 37)&&(IptModeIdentifyData.c_OVT >= 37))
		IptModeIdentifyData.SysInputMode = 0x4F75;//ֱ��ģʽ
	else IptModeIdentifyData.SysInputMode = 0;//ģʽʶ�����
}
#undef WDOWCPR_MAX
#undef WDOWCPR_MIN
const _iq24 Reciprolcal_ICutmax = 228170;   // 0.0408/3
void boostDataInit(void)
{
	boost_init();
	uiActionReady = 0;
	uiVoltPfcUp = 0;
	uiVoltPfcDn = 0;
    uiSendCid = 0;
    ucScisendFlag = 0;
    uiActionReady = 0;
    uiPfcVsetuse = 400;//400
    uiPfcVset = 400;
//    InputCurMax = (unsigned long)Reciprolcal_ICutmax*34;
    InputCurMax = (unsigned long)Reciprolcal_ICutmax*22; //228170*20 =
	EPwm2Regs.TBPHS.half.TBPHS = EPWM1_TIMER_TBPRD;
	EPwm3Regs.TBPRD = EPWM1_TIMER_TBPRD;
	p_SoftStart  = &boostStartCtrl;
	p_IoPortCtrl = &boostIoPortCtrl;
	p_AdcTrement = &boostAdcTerment;
}
void pfcDataInit(void)
{
        //hsr/20120628 add begin
        fFanRatio_Temp = 2;//3.0;
        fFanRatio_Curr = 0.25;   //0.15--->0.25  mxh 2012/12/05 change
        //hsr/20120628 add end

        uiVacline=300;
        uiPfcVset=400;
        uiPfcVsetuse=400;
        uiDcCurr=120;
        uiActionReady=0;
        /////////////mhping060826////////
        uiDcCurrDiff = 20;
        uiDcCurrHyst = 10;
        /////////////mhping060826////////

        uiVpfcAllSampSys = 1;
        uiVpfcUpSampSys = 1;
        uiVpfcDnSampSys = 1;

        uiVpfcAllCtrlSys = 1;
        uiVpfcUpCtrlSys = 1;
        uiVpfcDnCtrlSys = 1;

        fVacaSampSysa=1.0;
        fVacaSampSysb=0;
        fVacbSampSysa=1.0;
        fVacbSampSysb=0;
        fVaccSampSysa=1.0;
        fVaccSampSysb=0;

        fVpfcAllSampSys=1.0;
        fVpfcUpSampSys=1.0;
        fVpfcDnSampSys=1.0;
        fVpfcAllCtrlSys=1.0;
        fVpfcUpCtrlSys=1.0;
        fVpfcDnCtrlSys=1.0;

        uiFanCmprOld=26;                //czk060906


        fPfcConSys=1.0;

//        if(1)
        {
                uiVacUpLimit = 456;//480; //hsr/20120725 modify
                uiVacDnLimit = 308;//298;
                uiVacUpHyst = 11;
                uiVacDnHyst = 11;
                uiVpfcUpLimit = 450;
                uiVpfcDnLimit = 330;
                uiVpfcSoftstartLimit=150;
        }
//        else
//        {
//                uiVacUpLimit = 250;//480; //hsr/20120725 modify
//                uiVacDnLimit = 188;//298;
//                uiVacUpHyst = 5;
//                uiVacDnHyst = 5;
//                uiVpfcUpLimit = 450;
//                uiVpfcDnLimit = 110;
//                uiVpfcSoftstartLimit=100;
//        }

        uiVpfcAllUpLimit = 900;
        uiVpfcAllDnLimit = 660;
        uiVpfcAllUpHyst = 20;
        uiVpfcAllDnHyst = 30;

        uiVpfcUpHyst = 30;
        uiVpfcDnHyst = 30;
        uiVacUnbalance = 100;

        fVpfcSstartp=64;
        fVpfcSstartp1=2912;
        fVpfcSstartstep=0.59724234*20;
        fVpfcSstartstep1=0.04*20;
        ulIoPfcStatus[1].bit.B4 = 0;
        ucFanFault =0x0000;
        uiACYYa=0;
        uiACYYb=0;
        uiACYYc=0;
        uiRYSumACa=0;
        uiRYSumACb=0;
        uiRYSumACc=0;
        uiFlagLostAC=0;
        uiNeedFanFlag=0;
        pfc_init();
        ui_p_Read=(unsigned int *)0x0400;
        if(0x7D5C == IptModeIdentifyData.SysInputMode)
        {
            p_SoftStart = &pfcStartCtrl;
        }
        p_IoPortCtrl = &pfcIoPortCtrl;
        p_AdcTrement = &pfcAdcTreatment;
}
unsigned char bRelayFlag = 0;
unsigned long VpfcSstartSet = 0,VpfcSstartSet1 = 0;
//2*6.2/3/1010->Q24
#define  Reciprolcal_Vpmax2   (unsigned long)68659
void boostStartCtrl(void)
{
	unsigned int temp = 0;
	switch(uiActionReady)
	{
	case 0:
		EPwm1Regs.AQCSFRC.all = 0x05;           //PWM1A,PWM1B force low
		EPwm2Regs.AQCSFRC.all = 0x05;           //PWM2A,PWM2B force low
        GpioDataRegs.GPACLEAR.bit.GPIO14 = 1;
        EPwm1Regs.CMPA.half.CMPA = EPWM1_MIN_CMPA;
        EPwm1Regs.CMPB = EPWM1_MIN_CMPA;
        EPwm2Regs.CMPA.half.CMPA = EPWM1_MIN_CMPA;
        if((uiVoltPfcUp >= 140 )&&(uiVoltPfcDn >= 140)&&(bRelayFlag == 0 )) //280
        {
        	temp  = abs(uiVoltAcbc - uiVoltPfcAll);//Q0
        	Pfcisr.ui_Pfc_MainTimer1 = 0;
        	uiBaseTimer5 = 0;
        	while( (temp  <= 20) && (uiBaseTimer5  <= 20))
        	{
        		if(Pfcisr.ui_Pfc_MainTimer1 >= 125)
        		{
        			Pfcisr.ui_Pfc_MainTimer1 = 0;
        			uiBaseTimer5++;
        		}
            	temp  = abs(uiVoltAcbc - uiVoltPfcAll);
        	}
            if(uiBaseTimer5 >= 20)
            {
            	GpioDataRegs.GPASET.bit.GPIO31 = 1; //close relayb ���Ͽ���������
            	GpioDataRegs.GPASET.bit.GPIO27 = 1; //close relaya  ���Ͽ���������
            	bRelayFlag = 1;
//            	uiActionReady = 1; 				   //��ʱ1.5s���2
            }
        }
        else if((bRelayFlag == 1)&&((uiPfcVctrl & 0x01) == 0))
            uiActionReady = 1;                 //��ʱ1.5s���2
        break;
	case 2:
		uiBaseTimer5 = 0;
		Pfcisr.ui_Pfc_MainTimer1 = 0;
		while((uiVoltPfcUp >= 145) && (uiVoltPfcDn >= 145) && (uiBaseTimer5 <= 20))
		{
			if(Pfcisr.ui_Pfc_MainTimer1 >125)
			{
				Pfcisr.ui_Pfc_MainTimer1 = 0;
				uiBaseTimer5++;
			}
		}
		uiBaseTimer5 = 0;
		Pfcisr.ui_Pfc_MainTimer1 = 0;
		//�廷·����
		Pfcisr.ui_Pfc_Ref_Volt = 0;
		Pfcisr.ui_Pfc_VpfcSamUse = 0;
		Pfcisr.i_Pfc_Vpi_Err0 = 0;
		Pfcisr.i_Pfc_Vpi_Err1 = 0;
		Pfcisr.l_Pfc_Vpi_Output0 = 0;
		Pfcisr.ui_Pfc_VPITmp = 0;

		Pfcisr.i_Pfc_Ref_Currb = 0;
		Pfcisr.i_Pfc_Ibpi_Err0 = 0;
		Pfcisr.i_Pfc_Ibpi_Err1 = 0;
		Pfcisr.ui_Pfc_Ibpi_Output1 = 0;
		Pfcisr.ui_Pfc_Ibpi_Output0 = 0;
		uiPFCPwmPermit = 0;
		VpfcSstartSet = 0;
        VpfcSstartSet1 = Pfcisr.ui_Pfc_VpfcSamUse; //2912*2^10
//        GpioDataRegs.GPADAT.bit.GPIO4 = 1;
        uiNeedFanFlag = 1;
		uiActionReady = 3;
//		SystemStatus  = 1;
		break;
	case 3:
        VpfcSstartSet =  VpfcSstartSet + 5;  //ռ�ձ������޷���������
        VpfcSstartSet1 = VpfcSstartSet1 + 2; //�ο���ѹ��������
        if (VpfcSstartSet > 3686) VpfcSstartSet = 3686;//3686.4  90%
        uiPFCPwmPermit = VpfcSstartSet;
        temp = (unsigned int)((unsigned long)uiPfcVsetuse*Reciprolcal_Vpmax2>>12); //16.7625*2^8=4291.2
        if(((unsigned int)VpfcSstartSet1) >= temp) //800*6.2/1010*4096/3 = 6705
        {
        	Pfcisr.ui_Pfc_Ref_Volt= temp;
        	uiPFCPwmPermit = (unsigned int)3686;//EPWM1_MAX_CMPA*64;
        	uiActionReady = 4;
        }
        else Pfcisr.ui_Pfc_Ref_Volt = (unsigned int)(VpfcSstartSet1);
		break;
	case 4://֪ͨDC_DC����
        if(((uiVoltPfcUp>=380)&&(uiVoltPfcDn>=380))||( (uiVoltPfcUp>=336) &&(uiVoltPfcDn>=336)&&(uiPfcVsetuse<=380)))
        {
            uiBaseTimer5=0;
            while(uiBaseTimer5<=15)//11.12us*8*125*25=278ms��
            {
                if(Pfcisr.ui_Pfc_MainTimer1>=125)
                {
                    Pfcisr.ui_Pfc_MainTimer1=0;
                    uiBaseTimer5++;
                }
//                KickDog();
            }
            ulPfcStatus.bit.B0 = 1;
            GpioDataRegs.GPASET.bit.GPIO14 = 1; //֪ͨDCDC��PFC�ѿ���
            ucFanEnable = 1;
            uiSendCid = 1;
            ucScisendFlag = 1;
            uiActionReady = 5;
        }
		break;
	default:
		break;
	}
}


void pfcStartCtrl(void)
{
        if (uiActionReady == 0)
        {
                uiBaseTimer0=0;
                ucFanEnable=0;
                if(Pfcisr.ui_Pfc_FanPwm < 26)
                        Pfcisr.ui_Pfc_FanPwm=26;
                EPwm1Regs.AQCSFRC.all = 0x05;           //PWM1A,PWM1B force low
                EPwm2Regs.AQCSFRC.all = 0x05;           //PWM2A,PWM2B force low

                GpioDataRegs.GPACLEAR.bit.GPIO14 = 1;
                // GpioDataRegs.GPACLEAR.bit.GPIO27 = 1;        /*�Ͽ����̵���K1��K2 */
                //  GpioDataRegs.GPACLEAR.bit.GPIO31 = 1;

                EPwm1Regs.CMPA.half.CMPA = EPWM1_MIN_CMPA;
                EPwm1Regs.CMPB = EPWM1_MIN_CMPA;
                EPwm2Regs.CMPA.half.CMPA = EPWM1_MIN_CMPA;
                if((uiVoltPfcUp>uiVpfcSoftstartLimit)&&(uiVoltPfcDn>uiVpfcSoftstartLimit)&&(bRelayFlag == 0))
                {
                        uiBaseTimer5=0;
                        uiBaseTimer6=0;
                        Pfcisr.ui_Pfc_MainTimer1=0;

                        while((Pfcisr.ui_Pfc_VabSamUse>=45)&&(uiBaseTimer5<=20))//11.12us*8*125*25=278ms
                        {
                                asm (" NOP ");
                                if(Pfcisr.ui_Pfc_MainTimer1>=125)
                                {
                                        Pfcisr.ui_Pfc_MainTimer1=0;
                                        uiBaseTimer5++;
                                }
                                KickDog();
                        }
                        while(Pfcisr.ui_Pfc_Adc_Vc<(Pfcisr.ui_Pfc_Vin_Offset - 64)||Pfcisr.ui_Pfc_Adc_Vc>(Pfcisr.ui_Pfc_Vin_Offset+64))//
                        {
                                asm (" NOP ");
                                asm (" NOP ");     
                                KickDog();
                        }
                        GpioDataRegs.GPASET.bit.GPIO31 = 1; //close relayb ���Ͽ���������
                        uiBaseTimer5=0;
                        Pfcisr.ui_Pfc_MainTimer1=0;

                        while((Pfcisr.ui_Pfc_VbcSamUse>=45)&&(uiBaseTimer5<=20))//relayb�ȱպ�11.12us*8*125*25=278ms���ٱպ�relaya
                        {
                                asm (" NOP ");
                                if(Pfcisr.ui_Pfc_MainTimer1>=125)
                                {
                                        Pfcisr.ui_Pfc_MainTimer1=0;
                                        uiBaseTimer5++;
                                }
                                KickDog();
                        }
                        while(Pfcisr.ui_Pfc_Adc_Va<(Pfcisr.ui_Pfc_Vin_Offset - 64)||Pfcisr.ui_Pfc_Adc_Va>(Pfcisr.ui_Pfc_Vin_Offset+64))//
                        {
                                asm (" NOP ");
                                asm (" NOP ");
                                KickDog();
                        }
                        GpioDataRegs.GPASET.bit.GPIO27 = 1; //close relaya  ���Ͽ���������
                        bRelayFlag = 1;

                }
                if(bRelayFlag == 1)
                        uiActionReady = 1; //��ʱ2.5s��Ϊ2
        }

        else if (uiActionReady == 2)
        {
                uiNeedFanFlag=1;
                if((uiVoltPfcUp>uiVpfcSoftstartLimit)&&(uiVoltPfcDn>uiVpfcSoftstartLimit)
                   &&((uiVoltAcab>uiVacDnLimit)&&(uiVoltAcbc>uiVacDnLimit)&&(uiVoltAcca>uiVacDnLimit))
                   &&((uiVoltAcab<uiVacUpLimit)&&(uiVoltAcbc<uiVacUpLimit)&&(uiVoltAcca<uiVacUpLimit)))
                {
                        ///////czk061020////////////
                        Pfcisr.i_Pfc_Iin_Offset = -128;  //-128
                        Pfcisr.ui_Pfc_Vin_Offset = 0x0800;      //������·��1.5V��ƫ
                        Pfcisr.ui_Pfc_Ipfcmean_Max = 0x7FF0;   /////32752
                        Pfcisr.ui_Pfc_VPITmp = 0;
                        ///////czk061020////////////
                        Pfcisr.ui_Pfc_Vin_CompRatio = 50;

                        //voltage loop init
                        Pfcisr.i_Pfc_Vpi_Err0=0;
                        Pfcisr.i_Pfc_Vpi_Err1=0;
                        Pfcisr.i_Pfc_Vpi_Err2=0;
                        Pfcisr.l_Pfc_Vpi_Output0=0;
                        Pfcisr.ui_Pfc_VPITmp = 0;
                        //currenta  loop init
                        Pfcisr.i_Pfc_Iapi_Err0=0;
                        Pfcisr.i_Pfc_Iapi_Err1=0;
                        Pfcisr.i_Pfc_Iapi_Err2=0;
                        Pfcisr.ui_Pfc_Iapi_Output0=64;
                        Pfcisr.ui_Pfc_Iapi_Output1=64;
                        Pfcisr.ui_Pfc_Iapi_Output2=64;
                        Pfcisr.i_Pfc_Adc_Ia_1=0;
                        //currentb  loop init
                        Pfcisr.i_Pfc_Ibpi_Err0=0;
                        Pfcisr.i_Pfc_Ibpi_Err1=0;
                        Pfcisr.i_Pfc_Ibpi_Err2=0;
                        Pfcisr.ui_Pfc_Ibpi_Output0=64;
                        Pfcisr.ui_Pfc_Ibpi_Output1=64;
                        Pfcisr.ui_Pfc_Ibpi_Output2=64;
                        Pfcisr.i_Pfc_Adc_Ib_1=0;
                        //currentc  loop init
                        Pfcisr.i_Pfc_Icpi_Err0=0;
                        Pfcisr.i_Pfc_Icpi_Err1=0;
                        Pfcisr.i_Pfc_Icpi_Err2=0;
                        Pfcisr.ui_Pfc_Icpi_Output0=64;
                        Pfcisr.ui_Pfc_Icpi_Output1=64;
                        Pfcisr.ui_Pfc_Icpi_Output2=64;
                        Pfcisr.i_Pfc_Adc_Ic_1=0;
                        /* �� pfc ��· �м�ֵ */
                        Pfcisr.ui_Pfc_Ref_Volt=0;
                        Pfcisr.i_Pfc_Ref_Curra=0;
                        Pfcisr.i_Pfc_Ref_Currb=0;
                        Pfcisr.i_Pfc_Ref_Currc=0;

                        EPwm1Regs.AQCSFRC.all = 0x00;
                        EPwm2Regs.AQCSFRC.all = 0x00;

                        uiPFCPwmPermit=64;
                        fVpfcSstartSet = 64;
                        fVpfcSstartSet1 = 2912;

                        uiActionReady = 3;

                }
        }
        else if (uiActionReady == 3)//��PWM
                /*��ʼPFC������*/
        {
                fVpfcSstartSet = fVpfcSstartSet +  fVpfcSstartstep;             //dutyÿ������0.59*20/64
                fVpfcSstartSet1 = fVpfcSstartSet1 + fVpfcSstartstep1;

                if (fVpfcSstartSet > (float)((float)EPWM1_MAX_CMPA*64)) //1022/1112=92%
                {
                        fVpfcSstartSet = (unsigned int)((float)EPWM1_MAX_CMPA*64);
                }

                uiPFCPwmPermit = (unsigned int)fVpfcSstartSet;
                Pfcisr.ui_Pfc_Ref_Volt = (unsigned int)fVpfcSstartSet1;

                if (Pfcisr.ui_Pfc_Ref_Volt >= (unsigned int)(dk_Vpfc*(float)uiPfcVsetuse))
                {
                        Pfcisr.ui_Pfc_Ref_Volt= (unsigned int)(dk_Vpfc*(float)uiPfcVsetuse*fPfcConSys);
                        uiPFCPwmPermit = (unsigned int)EPWM1_MAX_CMPA*64;
                        uiActionReady = 4;

                }
        }

        else if (uiActionReady == 4)
        {
                //      if(((uiVoltPfcUp>=380)&&(uiVoltPfcDn>=380))||( (uiVoltPfcUp>=340) &&(uiVoltPfcDn>=340)&&(uiPfcVsetuse<=370) ))
                if(((uiVoltPfcUp>=380)&&(uiVoltPfcDn>=380))||( (uiVoltPfcUp>=336) &&(uiVoltPfcDn>=336)&&(uiPfcVsetuse<=380) ))
                {
                        uiBaseTimer5=0;
                        while(uiBaseTimer5<=15)//11.12us*8*125*25=278ms��
                        {
                                asm (" NOP ");
                                if(Pfcisr.ui_Pfc_MainTimer1>=125)
                                {
                                        Pfcisr.ui_Pfc_MainTimer1=0;
                                        uiBaseTimer5++;
                                }
                                KickDog();
                        }

                        ulPfcStatus.bit.B0 = 1;
                        GpioDataRegs.GPASET.bit.GPIO14 = 1; //֪ͨDCDC��PFC�ѿ���
                        uiSendCid = 1;
                        ucScisendFlag = 1;
                        uiActionReady = 5;
                }
        }
}

void boostIoPortCtrl(void)
{
    if(ucIoSamConFlag)//75ms
	{
		ucIoSamConFlag=0;
		if (ucDogFlag)
		{
			GpioDataRegs.GPATOGGLE.bit.GPIO6 = 1;    //��������ָʾ��
		}
		ucDogFlag ^= 0x01;
			/*PFC�����ж�*/

		ulIoPfcStatus[0].half.uiPfcStatusl = ulIoPfcStatus[1].half.uiPfcStatusl;
		ulIoPfcStatus[1].half.uiPfcStatusl &= 0x0010;
		if(GpioDataRegs.GPADAT.bit.GPIO30 == 0 && (uiActionReady >= 5))
		{
			if(ucFanFaultCount++>40)
			{
				ucFanFaultCount=0;
				ulIoPfcStatus[1].half.uiPfcStatusl |= 0x0010;
				ulPfcStatus.half.uiPfcStatusl |= 0x0010;
			}
		}
		if(GpioDataRegs.GPADAT.bit.GPIO30 == 1)  ucFanFaultCount=0;
		//Pfc ������ж�
		if(iTempPfc >=85)    ulIoPfcStatus[1].half.uiPfcStatusl |= 0x0200;
		else if((iTempPfc >=75)&&(ulPfcStatus.half.uiPfcStatusl & 0x0200))
			ulIoPfcStatus[1].half.uiPfcStatusl |= 0x0200;
		else ulIoPfcStatus[1].half.uiPfcStatusl &= 0xFDFF;

			//Pfc EEPROM error
		if(ucEepromErr) ulIoPfcStatus[1].half.uiPfcStatusl = (ulIoPfcStatus[1].half.uiPfcStatusl & 0xFFDF) | 0x0020;
		else            ulIoPfcStatus[1].half.uiPfcStatusl &= 0xFFDF;

		//vp ��ѹ��Ƿѹ�ж�
		if ((uiVoltPfcUp> 440)||(Pfcisr.ui_Pfc_OvpFlag))
		{
			if(uiVoltUpOverCount++>5)
			{
				uiVoltUpOverCount=10;
				ulIoPfcStatus[1].half.uiPfcStatusl = (ulIoPfcStatus[1].half.uiPfcStatusl & 0xE7FF) | 0x1000;
			}
		}
		else if((uiVoltPfcUp> 420) && ((ulPfcStatus.half.uiPfcStatusl & 0xE7FF) == 0x1000))
			ulIoPfcStatus[1].half.uiPfcStatusl = (ulIoPfcStatus[1].half.uiPfcStatusl & 0xE7FF) | 0x1000;
//		else if((uiVoltPfcUp< 330)&&(uiActionReady ==5)&&(Pfcisr.ui_Pfc_Ilimitflag==0))
		else if((uiVoltPfcUp< 330)&&(uiActionReady ==5))
		{
			if(ulPfcStatus.half.uiPfcStatusl & 0x0001)
				ulIoPfcStatus[1].half.uiPfcStatusl = (ulIoPfcStatus[1].half.uiPfcStatusl & 0xE7FF) | 0x0800;
		}
		else if((uiVoltPfcUp < 340)&& ((ulPfcStatus.half.uiPfcStatusl & 0xE7FF) == 0x0800)&&(uiActionReady ==5))
		{
			if(ulPfcStatus.half.uiPfcStatusl & 0x0001)
				ulIoPfcStatus[1].half.uiPfcStatusl = (ulIoPfcStatus[1].half.uiPfcStatusl & 0xE7FF) | 0x0800;
		}
		else
		{
			ulIoPfcStatus[1].half.uiPfcStatusl &= 0xE7FF;
			uiVoltUpOverCount=0;
		}
		//vn ��ѹ��Ƿѹ�ж�
		if ((uiVoltPfcDn > 440)||(Pfcisr.ui_Pfc_OvnFlag))
		{
			if(uiVoltDnOverCount++ > 5)
			{
				uiVoltDnOverCount = 10;
				ulIoPfcStatus[1].half.uiPfcStatusl = (ulIoPfcStatus[1].half.uiPfcStatusl & 0x9FFF)| 0x4000;  //��ѹ
			}
		}
		else if((uiVoltPfcDn> 420)&& ((ulPfcStatus.half.uiPfcStatusl & 0x9FFF) == 0x4000))
			ulIoPfcStatus[1].half.uiPfcStatusl = (ulIoPfcStatus[1].half.uiPfcStatusl & 0x9FFF)| 0x4000;     //��ѹ
		else if((uiVoltPfcDn< 330)&&(uiActionReady ==5))
		{
			if(ulPfcStatus.half.uiPfcStatusl & 0x0001)
				ulIoPfcStatus[1].half.uiPfcStatusl = (ulIoPfcStatus[1].half.uiPfcStatusl & 0x9FFF)| 0x2000; //Ƿѹ
		}
		else if((uiVoltPfcDn< 340)&& ((ulPfcStatus.half.uiPfcStatusl & 0x9FFF) == 0x2000)&&(uiActionReady ==5))
		{
			if(ulPfcStatus.half.uiPfcStatusl & 0x0001)
				ulIoPfcStatus[1].half.uiPfcStatusl = (ulIoPfcStatus[1].half.uiPfcStatusl & 0x9FFF)| 0x2000; //Ƿѹ
		}
		else
		{
			ulIoPfcStatus[1].half.uiPfcStatusl = ulIoPfcStatus[1].half.uiPfcStatusl & 0x9FFF;
		}
		//pfc ����ĸ�ߵ�ѹ��ƽ��bit30
		//pfc ����ĸ�ߵ�ѹ��ƽ��bit30
		if(abs(uiVoltPfcUp-uiVoltPfcDn)>=50)
		{
			if(uiVoltBlaneOverCount++ > 5)
			{
				uiVoltBlaneOverCount=10;
				ulIoPfcStatus[1].half.uiPfcStatusl |= 0x8000;
			}
		}
		else if((abs(uiVoltPfcUp-uiVoltPfcDn) >=25)&&(ulPfcStatus.half.uiPfcStatusl & 0x8000))
			ulIoPfcStatus[1].half.uiPfcStatusl |= 0x8000;
		else
		{
			ulIoPfcStatus[1].half.uiPfcStatusl &= 0x7FFF;
			uiVoltBlaneOverCount=0;
		}

		//	//2017��7��31�� ���������Ƿѹ���������쳣�����Ӹöδ���
		//    //AC��ѹ ,������κ�һ���ѹ
	    if((uiVoltAcab >= 770)||(uiVoltAcbc >= 770 )||(uiVoltAcca >= 770))
	    	ulIoPfcStatus[1].half.uiPfcStatusl = (ulIoPfcStatus[1].half.uiPfcStatusl & 0xFE3F) | 0x0140;
	    else if((uiVoltAcab >= 752)||(uiVoltAcbc >= 752 )||(uiVoltAcca >= 752 ))
	    {
	    	if((ulPfcStatus.half.uiPfcStatusl & 0xFE3F) == 0x0140)
	    		ulIoPfcStatus[1].half.uiPfcStatusl = (ulIoPfcStatus[1].half.uiPfcStatusl & 0xFE3F) | 0x0140;
	    }
	    //����Ƿѹ
	    if( uiVoltAcbc <= 280)
	    	ulIoPfcStatus[1].half.uiPfcStatusl = (ulIoPfcStatus[1].half.uiPfcStatusl & 0xFE3F) | 0x0100;
	    else if((uiVoltAcbc <= 295)&&((ulPfcStatus.half.uiPfcStatusl & 0xFE3F) == 0x0100))
	    	ulIoPfcStatus[1].half.uiPfcStatusl = (ulIoPfcStatus[1].half.uiPfcStatusl & 0xFE3F) | 0x0100;

		/*ģ��״̬/ �澯�˲�����ֵ*/
		if (ulIoPfcStatus[1].half.uiPfcStatusl == ulIoPfcStatus[0].half.uiPfcStatusl)
		{
			ulPfcStatus.half.uiPfcStatusl = (ulPfcStatus.half.uiPfcStatusl & 0x0001)|ulIoPfcStatus[1].half.uiPfcStatusl;
		}
	    if((ulPfcStatus.half.uiPfcStatusl&0xFFD0)||(uiPfcVctrl&0x01))
	    {
	        if(ulPfcStatus.bit.B0)
	        {
	            GpioDataRegs.GPACLEAR.bit.GPIO14 = 1;//pfc off
	            uiBaseTimer5=0;
	            Pfcisr.ui_Pfc_MainTimer1=0;
	            while(uiBaseTimer5 <= 25) //11.12us*8*125*25=278ms��
	            {
	                asm(" NOP");
	                if(Pfcisr.ui_Pfc_MainTimer1 >= 125)
	                {
	                    Pfcisr.ui_Pfc_MainTimer1=0;
	                    uiBaseTimer5++;
	                }
	    //          KickDog();
	            }
//	            LxkBoostState = 0;
	        }
	        EPwm1Regs.AQCSFRC.all = 0x05;               //PWM1A,PWM1B force low
	        EPwm2Regs.AQCSFRC.all = 0x05;
	        EPwm1Regs.CMPA.half.CMPA = EPWM1_MIN_CMPA;
	        EPwm1Regs.CMPB = EPWM1_MIN_CMPA;
	        EPwm2Regs.CMPA.half.CMPA = EPWM1_MIN_CMPA;
	        uiActionReady = 0;
	        ucFanEnable = 0;
	        ulPfcStatus.half.uiPfcStatusl &= 0xFFFE;
	    }
	    if(ucFanEnable == 0)
	    {
	        if((uiVoltPfcUp >= 250)&&(uiVoltPfcDn >= 250))
	            Pfcisr.ui_Pfc_FanPwm = 60; //ȫ��
	        else if((uiVoltPfcUp >= 200)&&(uiVoltPfcDn >= 200))
	            Pfcisr.ui_Pfc_FanPwm = 32; //ȫ��
	        else
	            Pfcisr.ui_Pfc_FanPwm = 1; //ͣת
	    }
	    else
	        Pfcisr.ui_Pfc_FanPwm = 120; //ȫ��

	}
}
void pfcIoPortCtrl(void)
{
//        if((uiACYYa<1800 && uiACYYb<1800 && uiACYYc<1800)||((ulPfcStatus.bit.B12||ulPfcStatus.bit.B14)!=0)||((ulPfcStatus.bit.B25||ulPfcStatus.bit.B23)!=0))//50V
//        {
//                //���磬����bus��ѹ
//                uiFlagLostAC=1;
//                GpioDataRegs.GPACLEAR.bit.GPIO14 = 1;//dcdc off
//                uiBaseTimer5=0;
//                Pfcisr.ui_Pfc_MainTimer1=0;
//                while(uiBaseTimer5<=10)//11.12us*8*125*10=110ms��
//                {
//                        asm (" NOP ");
//                        if(Pfcisr.ui_Pfc_MainTimer1>=125)
//                        {
//                                Pfcisr.ui_Pfc_MainTimer1=0;
//                                uiBaseTimer5++;
//                        }
//                        KickDog();
//                }
//
//                EPwm1Regs.AQCSFRC.all = 0x05;                //PWM1A,PWM1B force low
//                EPwm2Regs.AQCSFRC.all = 0x05;                //PWM2A,PWM2B force low
//                EPwm1Regs.CMPA.half.CMPA = EPWM1_MIN_CMPA;
//                EPwm1Regs.CMPB = EPWM1_MIN_CMPA;
//                EPwm2Regs.CMPA.half.CMPA = EPWM1_MIN_CMPA;
//                ulPfcStatus.bit.B0 =0;
//                uiActionReady = 0;
//                uiBaseTimer5=0;
//                Pfcisr.ui_Pfc_MainTimer1=0;
//                while(uiBaseTimer5<=4)//11.12us*8*125*4=40ms��
//                {
//                        asm (" NOP ");
//                        if(Pfcisr.ui_Pfc_MainTimer1>=125)
//                        {
//                                Pfcisr.ui_Pfc_MainTimer1=0;
//                                uiBaseTimer5++;
//                        }
//                        KickDog();
//                }
//                if((uiACYYa<1800 && uiACYYb<1800 && uiACYYc<1800))
//                {
//                        //  GpioDataRegs.GPACLEAR.bit.GPIO27 = 1;        /*�Ͽ����̵���K1��K2 */
//                        //    GpioDataRegs.GPACLEAR.bit.GPIO31 = 1;
//                }
//        }
//        if(uiACYYa>3600 && uiACYYb>3600 && uiACYYc>3600 && uiFlagLostAC==1)//90V
//        {
//                uiFlagLostAC=0;
//
//        }

        if(ucIoSamConFlag)//75ms
        {
                ucIoSamConFlag=0;
                /* MAX706��ι���ź�*/
                if (ucDogFlag)
                {
                        GpioDataRegs.GPACLEAR.bit.GPIO6 = 1;
                        ucDogFlag = 0;
                }
                else
                {
                        GpioDataRegs.GPASET.bit.GPIO6 = 1;
                        ucDogFlag = 1;
                }

                /*PFC�����ж�*/
                ulIoPfcStatus[0].all = ulIoPfcStatus[1].all;

                ulIoPfcStatus[1].half.uiPfcStatusl=ulIoPfcStatus[1].half.uiPfcStatusl&0x0010; //czk060906
                ulIoPfcStatus[1].half.uiPfcStatush=0x0000;              					  //czk060906

                if(GpioDataRegs.GPADAT.bit.GPIO30 == 0 && (uiActionReady >= 5))
                {
                        if(ucFanFaultCount++>40)
                        {
                                ucFanFaultCount=0;
                                ulIoPfcStatus[1].bit.B4 = 1;     //PFC�ķ��ȹ���
                                ulPfcStatus.bit.B4=1;
                        }
                }
                if(GpioDataRegs.GPADAT.bit.GPIO30 == 1)
                {
                        ucFanFaultCount=0;
                }

                //Pfc ������ж�
                if(tagMdlTemp.fd >=85.0)
                {
                        ulIoPfcStatus[1].bit.B9 = 1;
                }
                else if((tagMdlTemp.fd >=75.0)&&(ulPfcStatus.bit.B9==1))
                {
                        ulIoPfcStatus[1].bit.B9 = 1;
                }
                else
                {
                        ulIoPfcStatus[1].bit.B9 = 0;
                }

                //SCI ��ʱ�����
                if(iSciComFailCount >=10)
                {
                        ulIoPfcStatus[1].bit.B28 = 1;
                        iSciComFailCount = 11;
                }
                else
                {
                        ulIoPfcStatus[1].bit.B28 = 0;
                }

                //Pfc EEPROM error
                if(ucEepromErr)
                {
                        ulIoPfcStatus[1].bit.B5 = 1;
                }

                else
                {
                        ulIoPfcStatus[1].bit.B5 = 0;
                }
                //AC vab ��ѹ��Ƿѹ�ж�
                if(uiVoltAcab > uiVacUpLimit)
                {
                        ulIoPfcStatus[1].bit.B17 = 1;
                        ulIoPfcStatus[1].bit.B16 = 0;
                }
                else if((uiVoltAcab > (uiVacUpLimit-uiVacUpHyst)) && (ulPfcStatus.bit.B17 == 1))
                {
                        ulIoPfcStatus[1].bit.B17 = 1;
                        ulIoPfcStatus[1].bit.B16 = 0;
                }

                else if((uiVoltAcab < uiVacDnLimit)&&(uiActionReady >=2))
                {
                        ulIoPfcStatus[1].bit.B17 = 0;
                        ulIoPfcStatus[1].bit.B16 = 1;
                }
                else if((uiVoltAcab< (uiVacDnLimit+uiVacDnHyst)) && (ulPfcStatus.bit.B16 ==1))
                {
                        ulIoPfcStatus[1].bit.B17 = 0;
                        ulIoPfcStatus[1].bit.B16 = 1;
                }
                else
                {
                        ulIoPfcStatus[1].bit.B17 = 0;
                        ulIoPfcStatus[1].bit.B16 = 0;
                }
                //      if ((uiPfcVctrl&0x2)&&(uiBaseTimer6<12000))//dcdc on
                //      {
                //              ulIoPfcStatus[1].bit.B17 = 0;
                //      }

                //AC vbc ��ѹ��Ƿѹ�ж�
                if(uiVoltAcbc> uiVacUpLimit)
                {
                        ulIoPfcStatus[1].bit.B19 = 1;
                        ulIoPfcStatus[1].bit.B18 = 0;
                }
                else if((uiVoltAcbc > (uiVacUpLimit-uiVacUpHyst)) && (ulPfcStatus.bit.B19 ==1))
                {
                        ulIoPfcStatus[1].bit.B19 = 1;
                        ulIoPfcStatus[1].bit.B18 = 0;
                }
                else if((uiVoltAcbc < uiVacDnLimit)&&(uiActionReady >=2))
                {
                        ulIoPfcStatus[1].bit.B19 = 0;
                        ulIoPfcStatus[1].bit.B18 = 1;
                }
                else if((uiVoltAcbc < (uiVacDnLimit+uiVacDnHyst)) && (ulPfcStatus.bit.B18 ==1))
                {
                        ulIoPfcStatus[1].bit.B19 = 0;
                        ulIoPfcStatus[1].bit.B18 = 1;
                }
                else
                {
                        ulIoPfcStatus[1].bit.B19 = 0;
                        ulIoPfcStatus[1].bit.B18 = 0;
                }

                //AC vca ��ѹ��Ƿѹ�ж�
                if(uiVoltAcca > uiVacUpLimit)
                {
                        ulIoPfcStatus[1].bit.B21 = 1;
                        ulIoPfcStatus[1].bit.B20 = 0;
                }
                else if((uiVoltAcca  > (uiVacUpLimit-uiVacUpHyst)) && (ulPfcStatus.bit.B21 ==1))
                {
                        ulIoPfcStatus[1].bit.B21 = 1;
                        ulIoPfcStatus[1].bit.B20 = 0;
                }

                else if((uiVoltAcca  < uiVacDnLimit)&&(uiActionReady >=2))
                {
                        ulIoPfcStatus[1].bit.B21 = 0;
                        ulIoPfcStatus[1].bit.B20 = 1;
                }
                else if((uiVoltAcca  < (uiVacDnLimit+uiVacDnHyst)) && (ulPfcStatus.bit.B20 ==1))
                {
                        ulIoPfcStatus[1].bit.B21 = 0;
                        ulIoPfcStatus[1].bit.B20 = 1;
                }
                else
                {
                        ulIoPfcStatus[1].bit.B21 = 0;
                        ulIoPfcStatus[1].bit.B20 = 0;
                }
                //      if ((uiPfcVctrl&0x2)&&(uiBaseTimer6<12000))//dcdc on
                //       {
                //              ulIoPfcStatus[1].bit.B21 = 0;
                //      }

                //vp ��ѹ��Ƿѹ�ж�
                if ((uiVoltPfcUp> uiVpfcUpLimit)||(ucOverVpflag==1)||(Pfcisr.ui_Pfc_OvpFlag))
                {
                        if(uiVoltUpOverCount++>5)
                        {
                                uiVoltUpOverCount=10;
                                ulIoPfcStatus[1].bit.B23 = 1;
                                ulIoPfcStatus[1].bit.B22 = 0;
                        }

                }
                else if((uiVoltPfcUp> (uiVpfcUpLimit-uiVpfcUpHyst)) && (ulPfcStatus.bit.B23 == 1))
                {
                        ulIoPfcStatus[1].bit.B23 = 1;
                        ulIoPfcStatus[1].bit.B22 = 0;
                }

                else if((uiVoltPfcUp< uiVpfcDnLimit)&&(uiActionReady >=5)&&(Pfcisr.ui_Pfc_Ilimitflag==0))
                {
                        if(ulPfcStatus.bit.B0==1)
                        {
                                ulIoPfcStatus[1].bit.B23 = 0;
                                ulIoPfcStatus[1].bit.B22 = 1;
                        }
                }
                else if((uiVoltPfcUp < (uiVpfcDnLimit+uiVpfcDnHyst))&& (ulPfcStatus.bit.B22 == 1)&&(uiActionReady >=5)&&(Pfcisr.ui_Pfc_Ilimitflag==0))
                {
                        if(ulPfcStatus.bit.B0==1)
                        {
                                ulIoPfcStatus[1].bit.B23 = 0;
                                ulIoPfcStatus[1].bit.B22 = 1;
                        }
                }
                else
                {
                        ulIoPfcStatus[1].bit.B23 = 0;
                        ulIoPfcStatus[1].bit.B22 = 0;
                        uiVoltUpOverCount=0;
                }

                //vn ��ѹ��Ƿѹ�ж�

                if ((uiVoltPfcDn > uiVpfcUpLimit)||(ucOverVpflag==1)||(Pfcisr.ui_Pfc_OvnFlag))
                {
                        if(uiVoltDnOverCount++>5)
                        {
                                uiVoltDnOverCount=10;
                                ulIoPfcStatus[1].bit.B25 = 1;
                                ulIoPfcStatus[1].bit.B24 = 0;
                        }
                }
                else if((uiVoltPfcDn> (uiVpfcUpLimit-uiVpfcUpHyst))&& (ulPfcStatus.bit.B25 == 1))
                {
                        ulIoPfcStatus[1].bit.B25 = 1;
                        ulIoPfcStatus[1].bit.B24 = 0;
                }

                else if((uiVoltPfcDn< uiVpfcDnLimit)&&(uiActionReady >=5)&&(Pfcisr.ui_Pfc_Ilimitflag==0))
                {
                        if(ulPfcStatus.bit.B0==1)
                        {
                                ulIoPfcStatus[1].bit.B25 = 0;
                                ulIoPfcStatus[1].bit.B24 = 1;
                        }
                }

                else if((uiVoltPfcDn< (uiVpfcDnLimit+uiVpfcDnHyst))&& (ulPfcStatus.bit.B24 == 1)&&(uiActionReady >=5)&&(Pfcisr.ui_Pfc_Ilimitflag==0))
                {
                        if(ulPfcStatus.bit.B0==1)
                        {
                                ulIoPfcStatus[1].bit.B25 = 0;
                                ulIoPfcStatus[1].bit.B24 = 1;
                        }
                }
                else
                {
                        ulIoPfcStatus[1].bit.B25 = 0;
                        ulIoPfcStatus[1].bit.B24 = 0;
                        uiVoltDnOverCount=0;
                }


                //pfc ����ĸ�ߵ�ѹ��ƽ��bit30
                //pfc ����ĸ�ߵ�ѹ��ƽ��bit30
                if((abs(uiVoltPfcUp-uiVoltPfcDn)>=50)||(ucPfcUnflag))
                {
                        if(uiVoltBlaneOverCount++>5)
                        {
                                uiVoltBlaneOverCount=10;
                                ulIoPfcStatus[1].bit.B30 = 1;
                        }
                }
                else if((abs(uiVoltPfcUp-uiVoltPfcDn) >=25)&&(ulPfcStatus.bit.B30==1))
                {
                        ulIoPfcStatus[1].bit.B30 = 1;
                }
                else
                {
                        ulIoPfcStatus[1].bit.B30 = 0;
                        uiVoltBlaneOverCount=0;
                }
                //=========���಻ƽ��===========//
                if(((abs(uiVoltAcab-uiVoltAcbc))>=90)||((abs(uiVoltAcbc-uiVoltAcca))>90))
                {
                        ulIoPfcStatus[1].bit.B10 =1;
                }
                if(((abs(uiVoltAcab-uiVoltAcbc))<=50)&&((abs(uiVoltAcbc-uiVoltAcca))<=50))
                {
                        ulIoPfcStatus[1].bit.B10 =0;
                }

                //==================================//


                //H��ƽpfc����
                if(GpioDataRegs.GPADAT.bit.GPIO14)
                {
                        ulIoPfcStatus[1].bit.B27 = 1;
                }
                else
                {
                        ulIoPfcStatus[1].bit.B27 = 0;
                }

                //AC��ѹ ,������κ�һ���ѹ
                if((ulIoPfcStatus[1].bit.B21 && (! ulIoPfcStatus[1].bit.B20))
                   ||(ulIoPfcStatus[1].bit.B19 && (! ulIoPfcStatus[1].bit.B18))
                   ||(ulIoPfcStatus[1].bit.B17 && (! ulIoPfcStatus[1].bit.B16)))
                {
                        ulIoPfcStatus[1].bit.B8 = 1;
                        ulIoPfcStatus[1].bit.B7 = 0;
                        ulIoPfcStatus[1].bit.B6 = 1;
                }
                // ACͣ��---���඼Ƿѹ
                else if(((!ulIoPfcStatus[1].bit.B21) && ulIoPfcStatus[1].bit.B20)
                        &&((!ulIoPfcStatus[1].bit.B19) && ulIoPfcStatus[1].bit.B18)
                        &&((!ulIoPfcStatus[1].bit.B17)&& ulIoPfcStatus[1].bit.B16))
                {
                        ulIoPfcStatus[1].bit.B8 = 1;
                        ulIoPfcStatus[1].bit.B7 = 0;
                        ulIoPfcStatus[1].bit.B6 = 0;
                }
                //ACǷѹ, ����������ֻ������Ƿѹ
                else if((ulIoPfcStatus[1].bit.B20 + ulIoPfcStatus[1].bit.B18 + ulIoPfcStatus[1].bit.B16) ==2 )
                {
                        ulIoPfcStatus[1].bit.B8 = 0;
                        ulIoPfcStatus[1].bit.B7 = 1;
                        ulIoPfcStatus[1].bit.B6 = 1;
                }
                //AC ȱ��,����������ֻ��һ��Ƿѹ
                else if(((!ulIoPfcStatus[1].bit.B21) && ulIoPfcStatus[1].bit.B20)
                        ||((!ulIoPfcStatus[1].bit.B19) && ulIoPfcStatus[1].bit.B18)
                        ||((!ulIoPfcStatus[1].bit.B17)&& ulIoPfcStatus[1].bit.B16))
                {
                        ulIoPfcStatus[1].bit.B8 = 0;
                        ulIoPfcStatus[1].bit.B7 = 1;
                        ulIoPfcStatus[1].bit.B6 = 1;
                }
                /////////////czk030328  ac lose phase///////////
                else if((uiVoltAcab<80)||(uiVoltAcbc<80)||(uiVoltAcca<80)||(uiAdAcMaxa<80)||
                        (uiAdAcMaxb<80)||(uiAdAcMaxc<80))
                {
                        ulIoPfcStatus[1].bit.B8 = 0;
                        ulIoPfcStatus[1].bit.B7 = 1;
                        ulIoPfcStatus[1].bit.B6 = 0;
                }
                /////////////czk030328  ac lose phase///////////

                else
                {
                        ulIoPfcStatus[1].bit.B8 = 0;
                        ulIoPfcStatus[1].bit.B7 = 0;
                        ulIoPfcStatus[1].bit.B6 = 0;
                }

                //Pfc����                       +-BUS��ѹ/Ƿѹ/��ƽ��
                if(((ulIoPfcStatus[1].bit.B25 || ulIoPfcStatus[1].bit.B24
                     || ulIoPfcStatus[1].bit.B23 || ulIoPfcStatus[1].bit.B22|| ulIoPfcStatus[1].bit.B30)!= 0))
                {
                        ulIoPfcStatus[1].bit.B1 =1;
                }
                else
                {
                        ulIoPfcStatus[1].bit.B1= 0;
                }
                //hsr=========cxk=================//
                ulIoPfcStatus[1].bit.B15 = ulIoPfcStatus[1].bit.B30;//����BUS��ѹ���50V
                ulIoPfcStatus[1].bit.B14 = ulIoPfcStatus[1].bit.B25;//-BUS��ѹ������440V
                ulIoPfcStatus[1].bit.B13 = ulIoPfcStatus[1].bit.B24;//-BUSǷѹ������350V
                ulIoPfcStatus[1].bit.B12 = ulIoPfcStatus[1].bit.B23;//+BUS��ѹ������440V
                ulIoPfcStatus[1].bit.B11 = ulIoPfcStatus[1].bit.B22;//+BUSǷѹ������350V
                //==================cxk================//


                /*ģ��״̬/ �澯�˲�����ֵ*/
                if (ulIoPfcStatus[1].all == ulIoPfcStatus[0].all)
                {
                        ulPfcStatus.half.uiPfcStatusl =(ulPfcStatus.half.uiPfcStatusl&0x0001)|ulIoPfcStatus[1].half.uiPfcStatusl;
                        ulPfcStatus.half.uiPfcStatush=ulIoPfcStatus[1].half.uiPfcStatush;
                }

                //if((ulPfcStatus.half.uiPfcStatusl&0x03D2)||(ulPfcStatus.bit.B28)||(uiPfcVctrl&0x01))
                if((ulPfcStatus.half.uiPfcStatusl&0xFFD2)||(uiPfcVctrl&0x01))//uiPfcVctrl&0x01==1��DCDCָ��PFC�ػ�   //MXH REMOVE SCI COMMUNICATION FAIL CLOSE PFC  2011.1.20  //FAN  FAULT  REMOVE   2011.1.22
                {


                        GpioDataRegs.GPACLEAR.bit.GPIO14 = 1;//pfc off
                        uiBaseTimer5=0;
                        while(uiBaseTimer5<=25)//11.12us*8*125*25=278ms��
                        {
                                asm (" NOP ");
                                if(Pfcisr.ui_Pfc_MainTimer1>=125)
                                {
                                        Pfcisr.ui_Pfc_MainTimer1=0;
                                        uiBaseTimer5++;
                                }
                                KickDog();
                        }
                        EPwm1Regs.AQCSFRC.all = 0x05;               //PWM1A,PWM1B force low
                        EPwm2Regs.AQCSFRC.all = 0x05;
                        EPwm1Regs.CMPA.half.CMPA = EPWM1_MIN_CMPA;
                        EPwm1Regs.CMPB = EPWM1_MIN_CMPA;
                        EPwm2Regs.CMPA.half.CMPA = EPWM1_MIN_CMPA;
                        ulPfcStatus.bit.B0 =0;


                        uiActionReady=0;
                }

                if(uiActionReady>=3)
                {
                        if((uiVoltPfcUp>320)||(uiVoltPfcDn>320))
                        {
                                ucFanEnable=1;
                        }
                        else if((uiVoltPfcUp<300)&&(uiVoltPfcDn<300)&&(ucFanEnable==1)&&(ulPfcStatus.bit.B4==0))
                        {
                                ucFanEnable=2;
                        }
                }

                vFanControl();
        }
}
void vFanControl(void)
{
        float  ftempfan;

        if(ucFanEnable==1)
        {
                iTempDcdc0=(signed int)((signed int)uiTempDcdc0-50);
                iTempDcdc1=(signed int)((signed int)uiTempDcdc1-50);
                if(iTempDcdc1<=30) //hsr/20120628 modify  27->30
                {
//                        ftempfan = 60;
                    ftempfan = 65;
                }
                else if(iTempDcdc1 >= 65) //47������¶������������Ϊ��ת //70
                {
                        ftempfan = 120; //95
                }
                else
                {
                        //ftempfan = 53+ 1.85*((float)iTempDcdc0-27.0)+0.167*((float)uiDcCurr-120.0); //hsr/20120626 delete
                        //ftempfan = 53 + 3*((float)iTempDcdc0 - 27.0) + (float)uiDcCurr * 0.2; //hsr/20120626 add  70%��ת  ��ʵ��33A��uiDcCurr=33/0.3=110
                        //2580=(70-30)/(15-(-10))
//                        ftempfan = 60 + 0.813 * ((float)iTempDcdc1 - 27.0);
                        ftempfan = 65 + 0.813 * ((float)iTempDcdc1 - 27.0);
//                        if(ftempfan>95)
//                        {
//                                ftempfan=95;
//                        }
//                        if(ftempfan<60)
//                        {
//                                ftempfan=60;
//                        }
                        if(ftempfan > 120)
                        {
                                ftempfan=120;
                        }
                        if(ftempfan<65)
                        {
                                ftempfan=65;
                        }
                }
                if(ulPfcStatus.bit.B4 == 1||(uiPfcVctrl&0x01==1))
                {
                        ftempfan=26;
                }

                uiFanCmprOld=(unsigned int)ftempfan;
                Pfcisr.ui_Pfc_FanPwm=uiFanCmprOld;
        }
        else if(uiNeedFanFlag == 1)
        {
//                uiFanCmprOld=80;
//                Pfcisr.ui_Pfc_FanPwm=80; //MXH/20120807 modify  ��ʹBUSû����������ҲҪ����
                uiFanCmprOld=70;
                Pfcisr.ui_Pfc_FanPwm=70;  //MXH/20120807 modify  ��ʹBUSû����������ҲҪ����
        }
        else
        {
                uiFanCmprOld=26;
                Pfcisr.ui_Pfc_FanPwm=26; //MXH/20120807 modify  ��ʹBUSû����������ҲҪ����
        }

}

unsigned long Q15Vp  = 0,Q15Vn = 0;
void boostAdcTerment(void)
{
	unsigned int temp = 0;
	if(ucAdcSampFlag)
	{
		ucAdcSampFlag = 0;

        uiVoltAcbc = (unsigned long)Pfcisr.ui_Pfc_VbcRmsUse*7946>>15;
        uiVoltAcab = 0;
        uiVoltAcca = 0;

        temp = (unsigned long)Pfcisr.ui_Pfc_Adc_Vp*3910>>9;    //3.909677419354839e+03
        Q15Vp = Q15Vp >> 12;
        Q15Vp = Q15Vp*3891 + (unsigned long)temp *205;
        uiVoltPfcUp = Q15Vp >> 18; //0.05*2^15

        temp = (unsigned long)3910*Pfcisr.ui_Pfc_Adc_Vn>>9;
        Q15Vn = Q15Vn >> 12;
        Q15Vn = Q15Vn*3891 + (unsigned long)temp *205;
        uiVoltPfcDn = Q15Vn >> 18;

        uiVoltPfcAll= uiVoltPfcUp + uiVoltPfcDn;
        VsetMin = (uiVoltAcbc + 20)/2;
        if(uiVoltAcbc >= 460)
    	    InputCurMax = (unsigned long)Reciprolcal_ICutmax*31;
        else if(uiVoltAcbc <= 440)
    	    InputCurMax = (unsigned long)Reciprolcal_ICutmax*22;
	}
}

void  pfcAdcTreatment(void)
{
        Uint16 i,j;
        float   ftemp;
        if (ucAdcSampFlag)
        {
                ucAdcSampFlag = 0;
                for (i = 0; i <11; i++)
                {
                        for (j = 0; j < 40; j++)
                        {
                                ulAdcData[i][j] = ulAdcData[i][j+1];
                        }
                }

                ulAdcData[0][40] = Pfcisr.ui_Pfc_VabRmsUse;
                ulAdcData[1][40] = Pfcisr.ui_Pfc_VbcRmsUse;
                ulAdcData[2][40] = Pfcisr.ui_Pfc_VcaRmsUse;


                ulAdcData[3][40] = (unsigned int)AdcMirror.ADCRESULT6;
                ulAdcData[4][40] =(unsigned int)AdcMirror.ADCRESULT7;
                ulAdcData[5][40] = AdcMirror.ADCRESULT11;
                ulAdcData[6][40] = (unsigned int)AdcMirror.ADCRESULT8;
                ulAdcData[7][40] =(unsigned int)AdcMirror.ADCRESULT9;

                ulAdcData[8][40] =Pfcisr.ui_Pfc_Adc_VaMax-Pfcisr.ui_Pfc_Vin_Offset;
                ulAdcData[9][40] =Pfcisr.ui_Pfc_Adc_VbMax-Pfcisr.ui_Pfc_Vin_Offset;
                ulAdcData[10][40] =Pfcisr.ui_Pfc_Adc_VcMax-Pfcisr.ui_Pfc_Vin_Offset;

                Pfcisr.ui_Pfc_Adc_VaMax=0;
                Pfcisr.ui_Pfc_Adc_VbMax=0;
                Pfcisr.ui_Pfc_Adc_VcMax=0;


                for (i = 0; i < 11; i++)
                {
                        ulAdSum[i] = ulAdSum[i] + ulAdcData[i][40] - ulAdcData[i][0];
                }
                ftemp = 0.001831*((float)ulAdSum[5])-50.0;///////1�ȶ�Ӧ10mv��1��=10mv/3*4096=13.65cnt  1/13.65/40=0.001831
                if((ftemp>=(tagMdlTemp.fd+1.0))||(ftemp<=(tagMdlTemp.fd-1.0)))
                {
                        tagMdlTemp.fd=ftemp;
                        if (tagMdlTemp.fd > 150.0)
                        {
                                tagMdlTemp.fd = 150.0;
                        }
                        else if (tagMdlTemp.fd < -40.0)
                        {
                                tagMdlTemp.fd = -40.0;
                        }
                }
                iTempPfc=(signed int)tagMdlTemp.fd;

                /*��������ϵ��0.0059967291*/    //0.0059967291==3.3/550.3                1v=3.3/550.3/3*4096==8.19cnt

                ftemp=1.2*0.244333444*((float)ulAdSum[0])*fVacaSampSysa/120 + fVacaSampSysb; //???
                uiVabtemp2=uiVabtemp1;
                uiVabtemp1=Pfcisr.ui_Pfc_VabRmsUse;

                if(((abs(Pfcisr.ui_Pfc_VabRmsUse-uiVabtemp2)>uiVacline)||(ucfacflag==1))&&((uiPfcVctrl&0x40)==0))
                {
                        tagAcVoltab.fd =  1.2*0.244333444*((float)Pfcisr.ui_Pfc_VabRmsUse)*fVacaSampSysa/3.0 + fVacaSampSysb;
                        ucfacflag=1;
                }
                else
                {
                        tagAcVoltab.fd =0.96*tagAcVoltab.fd+0.04*ftemp;
                }

                ftemp=1.2*0.244333444*((float)ulAdSum[1])*fVacbSampSysa/120 + fVacbSampSysb;
                uiVbctemp2=uiVbctemp1;
                uiVbctemp1=Pfcisr.ui_Pfc_VbcRmsUse;
                if(((abs(Pfcisr.ui_Pfc_VbcRmsUse-uiVbctemp2)>uiVacline)||(ucfacflag==1))&&((uiPfcVctrl&0x40)==0))
                {
                        tagAcVoltbc.fd = 1.2*0.244333444*((float)Pfcisr.ui_Pfc_VbcRmsUse)*fVacbSampSysa/3.0 + fVacbSampSysb;
                        ucfacflag=1;
                }
                else
                {
                        tagAcVoltbc.fd =0.96*tagAcVoltbc.fd+0.04*ftemp;
                }

                ftemp=1.2*0.244333444*((float)ulAdSum[2])*fVaccSampSysa/120 + fVaccSampSysb;
                uiVcatemp2=uiVcatemp1;
                uiVcatemp1=Pfcisr.ui_Pfc_VcaRmsUse;
                if(((abs(Pfcisr.ui_Pfc_VcaRmsUse-uiVcatemp2)>uiVacline)||(ucfacflag==1))&&((uiPfcVctrl&0x40)==0))
                {
                        tagAcVoltca.fd = 1.2*0.244333444*((float)Pfcisr.ui_Pfc_VcaRmsUse)*fVaccSampSysa/3.0 + fVaccSampSysb;
                        ucfacflag=1;
                }
                else
                {
                        tagAcVoltca.fd =0.96*tagAcVoltca.fd+0.04*ftemp;
                }

                if(ucfacflag==1)
                {
                        uiBaseTimer4++;
                }

                if(uiBaseTimer4>=8)
                {
                        uiBaseTimer4=0;
                        ucfacflag=0;
                }

                if (tagAcVoltab.fd < 50)
                {
                        tagAcVoltab.fd = 0;
                }
                else if (tagAcVoltab.fd > (uiVacUpLimit+70))
                {
                        tagAcVoltab.fd = uiVacUpLimit+70;
                }

                if (tagAcVoltbc.fd < 50)
                {
                        tagAcVoltbc.fd = 0;
                }
                else if (tagAcVoltbc.fd > (uiVacUpLimit+70))
                {
                        tagAcVoltbc.fd = uiVacUpLimit+70;
                }

                if (tagAcVoltca.fd < 50)
                {
                        tagAcVoltca.fd = 0;
                }
                else if (tagAcVoltca.fd > (uiVacUpLimit+70))
                {
                        tagAcVoltca.fd = uiVacUpLimit+70;
                }

                uiVoltAcab=(unsigned int)tagAcVoltab.fd;
                uiVoltAcbc=(unsigned int)tagAcVoltbc.fd;
                uiVoltAcca=(unsigned int)tagAcVoltca.fd;
                /////////////////////////////////////////////////
                //Discription: VacRmsSqu for Ipfc set
                //km*160Vac*1.414*VacFactor*PIout/160Vrms^2 = 4260W/160Vac*1.414*IpfcFactor
                //km = PowerMax*IpfcFactor/(VacFactor*VpfcPIoutMax)
                //VpfcPIoutMax=0x7ff0
                //IpfcFactor=0.003*8*(5.1/3)*4096/3=92.84
                //VacFactor=3/2*(3.3/550.3)*4096/3=12.28 //
                //160Vac output 4260W, km = 0.983 ,so set Km=2
                //Q27:2^27*2/Vrms^2 = 268435456/Vrms^2


                //hsr/20120814 add begin   ���ѹ=(Vab+Vbc+Vca)/3/1.732=(Vab+Vbc+Vca)*0.1925
                uiVoltAcPhase = (Uint16)((((Uint32)uiVoltAcab + (Uint32)uiVoltAcbc + (Uint32)uiVoltAcca) * 197) >> 10);

                if(uiVoltAcPhase < 175)
                {
                        Pfcisr.ui_Pfc_VcSqrInv =5259;   //268435456/175^2   // 3227; //129332202/175^2==4223  //98835250/175^2==3227
                }
                else if(uiVoltAcPhase > 305)
                {
                        Pfcisr.ui_Pfc_VcSqrInv =1731;   //268435456/305^2         //1062; //129332202/305^2==1390
                }
                else
                {
                        udwTemp = (Uint32)uiVoltAcPhase * (Uint32)uiVoltAcPhase;
                        Pfcisr.ui_Pfc_VcSqrInv = (Uint16)(161061274/ udwTemp);
                }

                Pfcisr.ui_Pfc_VaSqrInv = Pfcisr.ui_Pfc_VcSqrInv;
                Pfcisr.ui_Pfc_VbSqrInv = Pfcisr.ui_Pfc_VcSqrInv;
                //hsr/20120814 add end

                tagAcVoltmin.fd=tagAcVoltab.fd;
                tagAcVoltmax.fd= tagAcVoltab.fd;

                if (tagAcVoltbc.fd<tagAcVoltmin.fd)
                {
                        tagAcVoltmin.fd=tagAcVoltbc.fd;
                }
                else
                {
                        tagAcVoltmax.fd=tagAcVoltbc.fd;
                }

                if (tagAcVoltca.fd<tagAcVoltmin.fd)
                {
                        tagAcVoltmin.fd=tagAcVoltca.fd;
                }
                if(tagAcVoltca.fd>tagAcVoltmax.fd)
                {
                        tagAcVoltmax.fd=tagAcVoltca.fd;
                }

                /////////////////AC phase voltage/////////
                uiAdAcMaxa = (unsigned int)(1.73*0.0030534224*(float)ulAdSum[8]);       //0.025*0.122136896
                uiAdAcMaxb = (unsigned int)(1.73*0.0030534224*(float)ulAdSum[9]);       //0.025*0.122136896
                uiAdAcMaxc = (unsigned int)(1.73*0.0030534224*(float)ulAdSum[10]);      //0.025*0.122136896

                /////////////////AC phase voltage/////////

                /*pfc����ϵ��0.007125891*/

                //     ftemp = 1.07*0.00256958*((float)ulAdSum[3])*fVpfcUpSampSys;
                ftemp = 1.161*0.00256958*((float)ulAdSum[3])*fVpfcUpSampSys;
                tagPfcVoltp.fd=tagPfcVoltp.fd*0.95+ftemp*0.05;

                //ftemp = 1.07*0.00256958*((float)ulAdSum[4])*fVpfcDnSampSys;
                ftemp = 1.161*0.00256958*((float)ulAdSum[4])*fVpfcDnSampSys;
                tagPfcVoltn.fd=tagPfcVoltn.fd*0.95+ftemp*0.05;

                tagPfcVolt.fd=(tagPfcVoltp.fd+tagPfcVoltn.fd)*fVpfcAllSampSys;

                uiVoltPfcAll=(unsigned int)tagPfcVolt.fd;
                uiVoltPfcUp=(unsigned int)tagPfcVoltp.fd;
                uiVoltPfcDn=(unsigned int)tagPfcVoltn.fd;

                ftemp = 1.07*0.00256958*((float)ulAdSum[6])*fVpfcUpSampSys;
                tagPfcVoltp1.fd=tagPfcVoltp1.fd*0.95+ftemp*0.05;

                ftemp = 1.07*0.00256958*((float)ulAdSum[7])*fVpfcDnSampSys;
                tagPfcVoltn1.fd=tagPfcVoltn1.fd*0.95+ftemp*0.05;

                VsetMin = 50;
        }
}

void    vMtimerTreat(void)
{
        static Uint32 FlagRelayCntTemp=0;

        if (CpuTimer0Regs.TCR.bit.TIF)  //5ms //25ms
        {
                CpuTimer0Regs.TCR.bit.TIF = 1;
                uiBaseTimer++;
                uiBaseTimer0++;
                uiSciComFailTime++;
                uiBaseTimer6++;
                uiBaseTimer7++;
                uiBaseTimer8++;
                if(uiActionReady <= 1)
                {
                        if(FlagRelayCntTemp < 12000)
                                FlagRelayCntTemp++;
                        else
                                uiNeedFanFlag=0;


                }
                else
                        FlagRelayCntTemp = 0;

                uFant++;
                uFant %= 72000;

                if(FanCnt <20000 )
                        FanCnt++;
                else
                        FanCnt = 0;


                if (uiSciComFailTime>400)
                {
                        uiSciComFail = 1;
                        uiSciComFailTime = 0;
                        iSciComFailCount ++;//debug by xinkai
                }
                if (uiActionReady == 1)
                {
                        if (uiBaseTimer0 >=300)//5ms*500=2.5s
                        {
                                uiActionReady=2;
                                uiBaseTimer0=300;
                        }

                }

                if (uiBaseTimer%24 == 0)
                {
//                        asm("NOP");

                        ucCircuitConFlag = 1;
                        //vWriteE2PROMSIG();
                }

                if (uiBaseTimer%14 == 0)
                {
                        ucIoSamConFlag = 1;
                }
                if (uiBaseTimer%4 == 0)
                {
                        ucAdcSampFlag = 1;
                }

                if(uiBaseTimer7 >=20)
                {
                        uiBaseTimer7 = 20;
                        Pfcisr.ui_Pfc_Vpi_para = 0;
                }

                if(uiBaseTimer6>=12000)
                {
                        uiBaseTimer6=12000;
                }
        }
}

void    vCircuitCal(void)
{
        if(ucCircuitConFlag)
        {
                ucCircuitConFlag=0;
                if(uiActionReady>=4)
                {
                    if(uiPfcVset<VsetMin)
                    {
                            uiPfcVset=VsetMin;
                    }
                    else if(uiPfcVset>425)
                    {
                                uiPfcVset=425;
                    }


                        if(uiPfcVsetuse<(uiPfcVset-2))
                        {
                                uiPfcVsetuse=uiPfcVsetuse+2;
                        }
                        else if(uiPfcVsetuse>(uiPfcVset+2))
                        {
                                uiPfcVsetuse=uiPfcVsetuse-2;
                        }
                        else
                        {
                                uiPfcVsetuse=uiPfcVset;
                        }
                        //      Pfcisr.ui_Pfc_Ref_Volt = (unsigned int)(dk_Vpfc*uiPfcVsetuse);
                        if(uiPfcVctrl&0x40)
                        {
                            Pfcisr.ui_Pfc_Ref_Volt = (unsigned int)((unsigned long)uiPfcVsetuse*Reciprolcal_Vpmax2>>12);
                    //            Pfcisr.ui_Pfc_Ref_Volt = (unsigned int)(dk_Vpfc*uiPfcVsetuse);
                        }
                }

                /////////////////////////Dynamic state detection. zym060908
                if(uiDcCurrMax-uiDcCurr > uiDcCurrDiff)
                {
                        uiDynamicFlag = 1;
                        uiBaseTimer8 = 0;
                }
                else
                {
                        if(uiBaseTimer8 >=400)
                        {
                                uiBaseTimer8 = 400;
                                uiDynamicFlag = 0;
                        }

                }
                //  uiDynamicFlag = 0;            //mxh test  2011.1.25
                /////////////////////////Dynamic state detection. zym060908

                uiDcPower = (unsigned int)(uiDcCurr * uiDcVolt);
///////////*************************************************/
                /*
                                    if (uiDcPower >= 54*35)
                                        Pfcisr.ui_Pfc_Isample_offset = 0x70; //�������0x70���������㲹�������Զ���
                                        else if(uiDcPower <=54*30)
                                        Pfcisr.ui_Pfc_Isample_offset = 0x48;
                                        */
/////////////////////*******************************************/
                if(uiDcPower <=54*35)
                        Pfcisr.ui_Pfc_Isample_offset = 0x48;
                else if ((uiDcPower >=54*35)&&(uiDcPower <= 54*80))
                        Pfcisr.ui_Pfc_Isample_offset = 0x48; //�������0x70���������㲹�������Զ���
                else
                {
                        Pfcisr.ui_Pfc_Isample_offset = 0x48; //�������0x100���������㲹�������Զ���
                }


                if(abs(uiVoltPfcUp-uiVoltPfcDn) >= 8)
                        Pfcisr.ui_Pfc_Vin_CompRatio = 120;
                else if(abs(uiVoltPfcUp-uiVoltPfcDn) < 5)
                        Pfcisr.ui_Pfc_Vin_CompRatio = 50;

                //              uiDcPower=2000;    //mxh test 2011.1.25


///////***********************************************************************/
                //  sc=7.0*(s+2*pi*1280)*(s+2*pi*1320)/[s*(s+2*pi*1700)],tustin, time=1/90k
                //  sc=6.66*(s+2*pi*1280)*(s+2*pi*1320)/[s*(s+2*pi*1700)],tustin, time=1/90k
                if(uiDcPower>=3204)      //267v* 24A    267*35A
                {
                        // sc=6.66*(s+2*pi*1280)*(s+2*pi*1320)/[s*(s+2*pi*1700)],tustin, time=1/90k
                        //Pfcisr.ui_Pfc_Ipi_K1=1933;  //Kv1_dzsp_shift
                        // Pfcisr.ui_Pfc_Ipi_K2=909;   //Kv2_dzsp_shift
                        // Pfcisr.ui_Pfc_Ipi_K3=7035;   //Kv3_dzsp_shift
                        // Pfcisr.ui_Pfc_Ipi_K4=12849; //Kv4_dzsp_shift
                        // Pfcisr.ui_Pfc_Ipi_K5=5867;       //Kv5_dzsp_shift
                        Pfcisr.ui_Pfc_Ipi_K1=1024;  //Kv1_dzsp_shift
                        Pfcisr.ui_Pfc_Ipi_K2=0;     //Kv2_dzsp_shift
                        Pfcisr.ui_Pfc_Ipi_K3=8194;  //Kv3_dzsp_shift
                        Pfcisr.ui_Pfc_Ipi_K4=7493; //Kv4_dzsp_shift
                        Pfcisr.ui_Pfc_Ipi_K5=0;        //Kv5_dzsp_shift
                }

                else if(uiDcPower<=2670)               // 20A  11.0*(s+2*pi*800)
                {
                        Pfcisr.ui_Pfc_Ipi_K1=1024;  //Kv1_dzsp_shift
                        Pfcisr.ui_Pfc_Ipi_K2=0;     //Kv2_dzsp_shift
                        Pfcisr.ui_Pfc_Ipi_K3=8194;  //Kv3_dzsp_shift
                        Pfcisr.ui_Pfc_Ipi_K4=7493; //Kv4_dzsp_shift
                        Pfcisr.ui_Pfc_Ipi_K5=0;        //Kv5_dzsp_shift
                }
                /********************************************ok**************/

                if(uiActionReady >=5)
                {
                        if((uiVoltPfcDn< 310)||(uiVoltPfcUp< 310))
                        {
                                ulPfcStatus.bit.B2=1;
                                uiBaseTimer9=0;
                        }
                        else if(((uiVoltPfcDn< 325)||(uiVoltPfcUp< 325))&&(ulPfcStatus.bit.B2==1))
                        {
                                ulPfcStatus.bit.B2=1;
                                uiBaseTimer9=0;
                        }
                        else
                        {
                                uiBaseTimer9++;
                                if(uiBaseTimer9>=50)
                                {
                                        ulPfcStatus.bit.B2=0;
                                        uiBaseTimer9=50;
                                }
                        }

                }

                if((abs(tagPfcVoltp1.fd-tagPfcVoltn1.fd)>=70.0)&&(uiActionReady >=5))
                {
                        ucPfcUnflag=1;
                }
                else if((abs(tagPfcVoltp1.fd-tagPfcVoltn1.fd) >=50.0)&&(ucPfcUnflag==1))
                {
                        ucPfcUnflag=1;
                }
                else
                {
                        ucPfcUnflag = 0;
                }

        }
}

void  vSendSciData(void)
{
        Uint16 i;
        ubitint  com_int ;
        Uint16 wCRCTemp;
        if(ucScisendFlag == 1)
        {
                ucScisendFlag = 0;
                if (uiSendCid == 1)
                {
                        ucCom_Txbuffer[1] = 1;
                        ucCom_Txbuffer[2] = 13+5;//13;//11;//hsr/20120726 modify
                        // uiTranslate_length = ucCom_Txbuffer[2]+2;

                        ucCom_Txbuffer[3] = (32*uiVoltAcab)/256;
                        ucCom_Txbuffer[4] = (32*uiVoltAcab)%256;
                        ucCom_Txbuffer[5] = (32*uiVoltAcbc)/256;
                        ucCom_Txbuffer[6] = (32*uiVoltAcbc)%256;
                        ucCom_Txbuffer[7] = (32*uiVoltAcca)/256;
                        ucCom_Txbuffer[8] = (32*uiVoltAcca)%256;

                        ucCom_Txbuffer[9] = ulPfcStatus.half.uiPfcStatusl/256;    //
                        ucCom_Txbuffer[10] = ulPfcStatus.half.uiPfcStatusl%256;


                        ucCom_Txbuffer[11] = iTempPfc+50;
                        ucCom_Txbuffer[12] = uiVoltPfcUp>>1;
                        ucCom_Txbuffer[13] = uiVoltPfcDn>>1;

                        ucCom_Txbuffer[14] = (unsigned char)(cPfcFirmwareVer /256); //hsr/20120726 add
                        ucCom_Txbuffer[15] = (unsigned char)(cPfcFirmwareVer%256);      //hsr/20120726 add
                }
                else if (uiSendCid == 11)
                {
                        ucCom_Txbuffer[1] = 11;
                        ucCom_Txbuffer[2] = 4+5;
                        //uiTranslate_length = ucCom_Txbuffer[2]+2;

                        ucCom_Txbuffer[3] = uiMemAddr0Value/256;
                        ucCom_Txbuffer[4] = uiMemAddr0Value%256;

                        ucCom_Txbuffer[5] = uiMemAddr1Value/256;
                        ucCom_Txbuffer[6] = uiMemAddr1Value%256;
                }
                //hsr/20120628 add begin
                else if(uiSendCid == 12)
                {
                        ucCom_Txbuffer[1] = 12;
                        ucCom_Txbuffer[2] = 4+5;
                        //  uiTranslate_length = ucCom_Txbuffer[2]+2;

                        uiFanRatio = (unsigned int)(fFanRatio_Temp * 1024.0);
                        ucCom_Txbuffer[3] = (unsigned char)((uiFanRatio >> 8) & 0x00FF);
                        ucCom_Txbuffer[4] = (unsigned char)(uiFanRatio & 0x00FF);

                        uiFanRatio = (unsigned int)(fFanRatio_Curr * 1024.0);
                        ucCom_Txbuffer[5] = (unsigned char)((uiFanRatio >> 8) & 0x00FF);
                        ucCom_Txbuffer[6] = (unsigned char)(uiFanRatio & 0x00FF);
                }
                //hsr/20120628 add end
                else if (uiSendCid == 20)                       // add for input current calibration V1.01, mhp
                {
                        ucCom_Txbuffer[1] = 20;
                        ucCom_Txbuffer[2] = 4+5;
                        //uiTranslate_length = ucCom_Txbuffer[2]+2;

                        ucCom_Txbuffer[3] = uiEpromRdAddr/256;
                        ucCom_Txbuffer[4] = uiEpromRdAddr%256;

                        ucCom_Txbuffer[5] = uiEpromRdValue/256;
                        ucCom_Txbuffer[6] = uiEpromRdValue%256;
                }

                //txd_asc(uiTranslate_length);

                // uiTranslate_length = uiTranslate_length*2;

                /* fill XOR check code */
                //   ucSendCheckChar = ucCom_Txbuffer[1];

                //   for (i=2; i<uiTranslate_length+1; i++)
                //   {
                //         ucSendCheckChar = ucSendCheckChar^ucCom_Txbuffer[i];
                // }

                //com_int.id = hex_asc(ucSendCheckChar) ;
                ucCom_Txbuffer[0] = 0x7e;
                uiTranslate_length = ucCom_Txbuffer[2];
                wCRCTemp = usMBCRC16(ucCom_Txbuffer,uiTranslate_length -2);
                ucCom_Txbuffer[uiTranslate_length-2] = wCRCTemp/256;
                ucCom_Txbuffer[uiTranslate_length-1] = wCRCTemp%256;

                uiTr_point=0;
                uiScisendData = 1;

                if(ucTest_ok==1)
                {
                        GpioDataRegs.GPASET.bit.GPIO11 = 1;
                        ucTest_ok=0;
                }
                else
                {
                        GpioDataRegs.GPACLEAR.bit.GPIO11 = 1;
                        ucTest_ok=1;
                }
        }

        if (uiScisendData)
        {
                if (SciaRegs.SCICTL2.all&0x80)
                {
                        if ( (uiTr_point>=uiTranslate_length) || (uiTranslate_length>100) )
                        {
                                uiTr_point = 0;
                                uiScisendData = 0;
                        }
                        else
                        {
                                SciaRegs.SCITXBUF = ucCom_Txbuffer[uiTr_point++];
                        }
                }
        }

}

void  vGetSciData(void)
{
        unsigned char data;
        Uint16 j;
        unsigned int  *  p;
        float ftemp,ftempb;
        asm(" NOP");

        if(SciaRegs.SCIFFRX.bit.RXFFST>=1)
        {
                data = SciaRegs.SCIRXBUF.all;

                /* ȷ�����յ����ݰ���С100�ֽڡ�*/
                if ( uiRe_point > 20 )
                {
                        uiRe_point = 0;
                        return;
                }

                ucCom_Rxbuffer[uiRe_point] = data;
                uiRe_point++;
                /* ȷ����ͷΪ0x7e��ͬʱ��֤���ݰ��м���0x7e��*/
                if ( (uiRe_point==0x01)  )
                {

                        if ( data != 0x7e )
                        {
                                uiRe_point = 0;
                        }
                }

                else if ((uiRe_point>=ucCom_Rxbuffer[2])&&(uiRe_point >= 3))   /*ȷ�����ݰ��յ���β*/
                {
                        ucReceive_ok = 1;
                }
                else
                {
                        // uiRe_point = 0;
                }
        }

        //�������մ���
        if (SciaRegs.SCIRXST.bit.RXERROR)
        {
                SciaRegs.SCICCR.all = 0x0027;
                SciaRegs.SCICTL1.all = 0x0003;
                SciaRegs.SCICTL2.all = 0x0000;

                SciaRegs.SCIHBAUD = 0x0000;
                SciaRegs.SCILBAUD = 0x00A2;

                SciaRegs.SCIRXBUF.all= 0x00;
                SciaRegs.SCITXBUF = 0x00;
                SciaRegs.SCICTL1.all = 0x0023;
                uiRe_point = 0;
                ucReceive_ok = 0;
        }

        if (ucReceive_ok)
        {

                uiReceiveCheckChar = ucCom_Rxbuffer[ucCom_Rxbuffer[2] -2]*256 +ucCom_Rxbuffer[ucCom_Rxbuffer[2] -1];
                if ( uiReceiveCheckChar == usMBCRC16(ucCom_Rxbuffer,ucCom_Rxbuffer[2] -2) )
                {
                        uiSciComFailTime = 0;
                        iSciComFailCount = 0;
                        uiSciComFail = 0;
                        //     return;//debug by xinkai
                        switch ( ucCom_Rxbuffer[1] )
                        {
                                case 1:
                                        uiPfcVset = ((ucCom_Rxbuffer[3]&0x00FF)<<8)|(ucCom_Rxbuffer[4]&0x00FF);
                                        uiPfcVctrl = ((ucCom_Rxbuffer[5]&0x00FF)<<8)|(ucCom_Rxbuffer[6]&0x00FF);
                                        uiTempDcdc0 = ucCom_Rxbuffer[7]&0x00FF;
                                        uiTempDcdc1 = ucCom_Rxbuffer[8]&0x00FF;
                                        uiDcVolt=(((ucCom_Rxbuffer[9]&0x00FF)<<8)|(ucCom_Rxbuffer[10]&0x00FF))>>10;
                                        uiDcCurr=ucCom_Rxbuffer[11]&0x00FF;
                                        uiDcCurrMax=ucCom_Rxbuffer[12]&0x00FF;

                                        uiSendCid=1;
                                        ucScisendFlag = 1;

                                        break;

                                case 5:
                                        ///////czk060906/////////
                                        uiSysaTemp = ((ucCom_Rxbuffer[3]&0x00FF)<<8)|(ucCom_Rxbuffer[4]&0x00FF);
                                        iSysbTemp = (signed int)(((ucCom_Rxbuffer[5]&0x00FF)<<8)|(ucCom_Rxbuffer[6]&0x00FF));
                                        uiSendCid=5;

                                        ftemp = 0.0009765625*(float)uiSysaTemp*fVacaSampSysa;
                                        ftempb= 0.0009765625*(float)uiSysaTemp*fVacaSampSysb+0.0078125*(float)iSysbTemp;
                                        if((ftemp > 0.8) && (ftemp <1.2)&&(ftempb > (-40)) && (ftempb <40))
                                        {

                                                uiEepromFlag=uiEepromFlag|0x0001;
                                                uiEepromFlag=uiEepromFlag|0x0002;
                                                fVacaSampSysa= ftemp;
                                                fVacaSampSysb= ftempb;

                                        }

                                        break;


                                case 6:
                                        ///////czk060906/////////
                                        uiSysaTemp = ((ucCom_Rxbuffer[3]&0x00FF)<<8)|(ucCom_Rxbuffer[4]&0x00FF);
                                        iSysbTemp = (signed int)(((ucCom_Rxbuffer[5]&0x00FF)<<8)|(ucCom_Rxbuffer[6]&0x00FF));
                                        uiSendCid=6;

                                        ftemp = 0.0009765625*(float)uiSysaTemp*fVacbSampSysa;
                                        ftempb= 0.0009765625*(float)uiSysaTemp*fVacbSampSysb+0.0078125*(float)iSysbTemp;
                                        if((ftemp > 0.8) && (ftemp <1.2)&&(ftempb > (-40)) && (ftempb <40))
                                        {
                                                fVacbSampSysa= ftemp;
                                                fVacbSampSysb= ftempb;
                                                uiEepromFlag=uiEepromFlag|0x0004;
                                                uiEepromFlag=uiEepromFlag|0x0008;
                                        }
                                        break;


                                case 7:

                                        ///////czk060906/////////
                                        uiSysaTemp = ((ucCom_Rxbuffer[3]&0x00FF)<<8)|(ucCom_Rxbuffer[4]&0x00FF);
                                        iSysbTemp = (signed int)(((ucCom_Rxbuffer[5]&0x00FF)<<8)|(ucCom_Rxbuffer[6]&0x00FF));
                                        uiSendCid=7;

                                        ftemp = 0.0009765625*(float)uiSysaTemp*fVaccSampSysa;
                                        ftempb= 0.0009765625*(float)uiSysaTemp*fVaccSampSysb+0.0078125*(float)iSysbTemp;
                                        if((ftemp > 0.8) && (ftemp <1.2)&&(ftempb > (-40)) && (ftempb <40))
                                        {
                                                fVaccSampSysa= ftemp;
                                                fVaccSampSysb= ftempb;
                                                uiEepromFlag=uiEepromFlag|0x0010;
                                                uiEepromFlag=uiEepromFlag|0x0020;
                                        }

                                        break;


                                case 8:
                                        //////pfc no use 060906/////////
                                        uiVpfcAllSampSys = ((ucCom_Rxbuffer[3]&0x00FF)<<8)|(ucCom_Rxbuffer[4]&0x00FF);
                                        uiVpfcUpSampSys = ((ucCom_Rxbuffer[5]&0x00FF)<<8)|(ucCom_Rxbuffer[6]&0x00FF);
                                        uiVpfcDnSampSys = ((ucCom_Rxbuffer[7]&0x00FF)<<8)|(ucCom_Rxbuffer[8]&0x00FF);
                                        uiSendCid=8;

                                        ftemp =  0.0009765625*(float)uiVpfcAllSampSys;
                                        if((ftemp > 0.5) && (ftemp <1.5))
                                        {
                                                fVpfcAllSampSys =  ftemp;
                                                uiEepromFlag=uiEepromFlag|0x0040;
                                        }
                                        ftemp =  0.0009765625*(float)uiVpfcUpSampSys;
                                        if((ftemp > 0.5) && (ftemp <1.5))
                                        {
                                                fVpfcUpSampSys =  ftemp;
                                                uiEepromFlag=uiEepromFlag|0x0080;
                                        }
                                        ftemp =  0.0009765625*(float)uiVpfcDnSampSys;
                                        if((ftemp > 0.5) && (ftemp <1.5))
                                        {
                                                fVpfcDnSampSys =  ftemp;
                                                uiEepromFlag=uiEepromFlag|0x0100;
                                        }
                                        break;

                                case 9:
                                        //////pfc no use 060906/////////
                                        uiVpfcAllCtrlSys = ((ucCom_Rxbuffer[3]&0x00FF)<<8)|(ucCom_Rxbuffer[4]&0x00FF);
                                        uiVpfcUpCtrlSys = ((ucCom_Rxbuffer[5]&0x00FF)<<8)|(ucCom_Rxbuffer[6]&0x00FF);
                                        uiVpfcDnCtrlSys = ((ucCom_Rxbuffer[7]&0x00FF)<<8)|(ucCom_Rxbuffer[8]&0x00FF);
                                        uiSendCid=9;

                                        ftemp =  0.0009765625*(float)uiVpfcAllCtrlSys;
                                        if((ftemp > 0.5) && (ftemp <1.5))
                                        {
                                                fVpfcAllCtrlSys =  ftemp;
                                                uiEepromFlag=uiEepromFlag|0x0200;
                                        }
                                        ftemp =  0.0009765625*(float)uiVpfcUpCtrlSys;
                                        if((ftemp > 0.5) && (ftemp <1.5))
                                        {
                                                fVpfcUpCtrlSys =  ftemp;
                                                uiEepromFlag=uiEepromFlag|0x0400;
                                        }
                                        ftemp = 0.0009765625*(float)uiVpfcDnCtrlSys;
                                        if((ftemp > 0.5) && (ftemp <1.5))
                                        {
                                                fVpfcDnCtrlSys =  ftemp;
                                                uiEepromFlag=uiEepromFlag|0x0800;
                                        }
                                        break;

                                case 10:
                                        uiMemWrAddr = ((ucCom_Rxbuffer[3]&0x00FF)<<8)|(ucCom_Rxbuffer[4]&0x00FF);
                                        uiMemWrValue = ((ucCom_Rxbuffer[5]&0x00FF)<<8)|(ucCom_Rxbuffer[6]&0x00FF);
                                        uiSendCid=10;
                                        p=(unsigned int *)uiMemWrAddr;
                                        *p=uiMemWrValue;
                                        break;

                                case 11:
                                        uiMemRdAddr0 = ((ucCom_Rxbuffer[3]&0x00FF)<<8)|(ucCom_Rxbuffer[4]&0x00FF);
                                        uiMemRdAddr1 = ((ucCom_Rxbuffer[5]&0x00FF)<<8)|(ucCom_Rxbuffer[6]&0x00FF);
                                        uiSendCid=11;
                                        ucScisendFlag = 1;
                                        p=(unsigned int *)uiMemRdAddr0;
                                        uiMemAddr0Value=*p;
                                        p=(unsigned int *)uiMemRdAddr1;
                                        uiMemAddr1Value=*p;
                                        break;
                                //hsr/20120628 add begin
                                case 12:
                                        uiFanRatio = (((unsigned int)ucCom_Rxbuffer[3])<<8)|(ucCom_Rxbuffer[4]); //DCDC��Q10����
                                        fFanRatio_Temp = (float)uiFanRatio / 1024.0;

                                        uiFanRatio = (((unsigned int)ucCom_Rxbuffer[5])<<8)|(ucCom_Rxbuffer[6]); //DCDC��Q10����
                                        fFanRatio_Curr = (float)uiFanRatio / 1024.0;

                                        uiSendCid=12;
                                        ucScisendFlag = 1;

                                        break;
                                //hsr/20120628 add end
                                case 20:
                                        uiEpromWrAddr = ((ucCom_Rxbuffer[3]&0x00FF)<<8)|(ucCom_Rxbuffer[4]&0x00FF);
                                        uiEpromWrValue = ((ucCom_Rxbuffer[5]&0x00FF)<<8)|(ucCom_Rxbuffer[6]&0x00FF);
                                        uiSendCid=20;
                                        uiEepromFlag=uiEepromFlag|0x1000;
                                        break;

                                default:
                                        ucCom_Rxbuffer[2] = NOVCOM ;    /*RTN ��Ч���� */
                                        break ;
                        }
                }
                ucReceive_ok=0;
                uiRe_point = 0;
        }

}

/******************************************************************
        �������� :      asc_hex
        ��ڲ��� :      ascl,asch--ASCII��
        ���ڲ��� :      ��Ӧ HEX��
        �������� :      ������ASCII��ϲ�Ϊһ����ӦHEX��
        �Ӻ���  :       ��
******************************************************************/
unsigned char asc_hex(unsigned char ascl, unsigned char asch)
{
        if ( asch > 0x3a )
        {
                asch = asch - 0x37;
        }
        else
        {
                asch = asch     - 0x30;
        }
        asch = asch <<4 ;

        if ( ascl > 0x3a )
        {
                ascl = ascl - 0x37;
        }
        else
        {
                ascl = ascl - 0x30;
        }
        asch = asch | ascl;

        return asch;
}

/******************************************************************
        �������� :      hex_asc
        ��ڲ��� :      hex--HEX��
        ���ڲ��� :      �ӦASCII��
        �������� :      ��һ��HEX���Ϊһ����INT����ݴ洢��ʵ����λ��ASCII��
        �Ӻ���   :      ��
******************************************************************/
unsigned int hex_asc( unsigned char hex )
{
        ubitint ascreg ;

        ascreg.bitdata.highchar = hex & 0x0f ;
        if ( ascreg.bitdata.highchar >= 10 )
        {
                ascreg.bitdata.highchar = ascreg.bitdata.highchar + 0x37 ;      /*37h*/
        }
        else
        {
                ascreg.bitdata.highchar = ascreg.bitdata.highchar + 0x30 ;      /*30h*/
        }

        ascreg.bitdata.lowchar = hex >> 4       ;
        if ( ascreg.bitdata.lowchar >= 10 )
        {
                ascreg.bitdata.lowchar = ascreg.bitdata.lowchar + 0x37 ;        /*37h*/
        }
        else
        {
                ascreg.bitdata.lowchar = ascreg.bitdata.lowchar + 0x30 ;        /*30h*/
        }
        return ascreg.id;
}

/******************************************************************
        �������� :      txd_asc
        ��ڲ��� :      len--豻�ֽ��?
        ���ڲ��� :      ��
        �������� :      ��len�����ݱ任ΪASCII�룬�洢��ͨ�Ż�����
        �Ӻ���    :     hex_asc
        �޸�              :
******************************************************************/
void txd_asc(unsigned int len)// len: ucCom_buffer[]ʵ��HEX����:CID+LEN+DAT
{
        unsigned int i ;

        ubitint  com_int ;

        for ( i=len; i>0; i--)
        {
                com_int.id = hex_asc(ucCom_Txbuffer[i]) ;
                ucCom_Txbuffer[i<<1] = com_int.bitdata.lowchar ;
                ucCom_Txbuffer[(i<<1)-1] = com_int.bitdata.highchar ;
        }
}


/************************************************/
/*��������:uSecond                                                      */
/*��������:delay 10΢��                                                 */
/*��ڲ���:uS(10΢��)                                                   */
/*���ڲ���:��                                                                   */
/*��Դ:��                                                               */
/*�Ӻ���:��                                                                             */
/*��������:2001.9.1                                                     */
/************************************************/
void    uSecond(unsigned int uS)
{
        unsigned int i,j;

        for (i = 0; i < uS; i++)
        {
                for (j = 0; j < 20; j++);       /*ѭ��delay */
                {
                        asm (" NOP ");
                }
                KickDog();
        }
}


Uint16 uiI2caWriteData(unsigned int uAddress, ubitfloat fTemp)
{

        int uiCount1;

        GpioDataRegs.GPACLEAR.bit.GPIO26 = 1;

        uiCount1 = 0;

        while (I2caRegs.I2CMDR.bit.STP == 1)
        {
                uiCount1 ++ ;
                if(uiCount1 > 6000)
                {
                        return I2C_STP_NOT_READY_ERROR;
                }
        }

        // Setup slave address
        I2caRegs.I2CSAR = 0x50;

        // Check if bus busy
        if (I2caRegs.I2CSTR.bit.BB == 1)
        {
                return I2C_BUS_BUSY_ERROR;
        }

        I2caRegs.I2CCNT = 6;

        // Setup data to send
        I2caRegs.I2CDXR = (unsigned char)(uAddress>> 8);
        I2caRegs.I2CDXR = (unsigned char)(uAddress & 0x00ff);

        I2caRegs.I2CDXR = fTemp.intdata[0].bitdata.highchar;
        I2caRegs.I2CDXR = fTemp.intdata[0].bitdata.lowchar;
        I2caRegs.I2CDXR = fTemp.intdata[1].bitdata.highchar;
        I2caRegs.I2CDXR = fTemp.intdata[1].bitdata.lowchar;

        // Send start as master transmitter
        I2caRegs.I2CMDR.all = 0x6E20;

        //uSecond(500);
        if (IER&0x0004)                         // add for input current calibration V1.01, mhp
        {
                uSecond(6000);
        }
        else
        {
                uSecond(32000);
        }


        GpioDataRegs.GPASET.bit.GPIO26 = 1;

        if(uiI2caReadData(uAddress)== I2C_SUCCESS)
        {
                if (fTemp.fd!=fRdTemp.fd)
                {
                        return I2C_ERROR;
                }
        }
        else
        {
                return  I2C_ERROR;
        }

        return I2C_SUCCESS;
}


Uint16 uiI2caReadData(unsigned int uAddress)
{
        Uint16  i,uiCount2,uiCount3,uiCount4;


        uiCount2 = 0;
        while (I2caRegs.I2CMDR.bit.STP == 1)
        {
                uiCount2 ++ ;
                if(uiCount2 > 6000)
                {
                        return I2C_STP_NOT_READY_ERROR;
                }
        }

        //I2caRegs.I2CSAR = msg->SlaveAddress;
        I2caRegs.I2CSAR = 0x50;

        // Check if bus busy
        if (I2caRegs.I2CSTR.bit.BB == 1)
        {
                return I2C_BUS_BUSY_ERROR;
        }

        I2caRegs.I2CCNT = 2;
        I2caRegs.I2CDXR = (unsigned char)(uAddress>> 8);
        I2caRegs.I2CDXR = (unsigned char)(uAddress & 0x00ff);
        I2caRegs.I2CMDR.all = 0x6620;// Send data to setup EEPROM address
        I2caRegs.I2CSTR.bit.SCD=1;

        uiCount3 = 0;
        uiCount4 = 0;
        while (I2caRegs.I2CSTR.bit.ARDY!=1)
        {
                uiCount3 ++ ;
                if(uiCount3 > 4000)
                {
                        return I2C_ERROR;
                }

        }

        I2caRegs.I2CCNT = 4;
        I2caRegs.I2CMDR.all = 0x6C20;
        while (I2caRegs.I2CSTR.bit.SCD!=1)
        {
                uiCount4 ++ ;
                if(uiCount4 > 6000)
                {
                        return I2C_ERROR;
                }
        }

        for (i = 0; i < 4; i++)
        {
                uiRdMsgBuffer[i] = I2caRegs.I2CDRR;
        }

        fRdTemp.intdata[0].bitdata.highchar = uiRdMsgBuffer[0]&0x00ff;
        fRdTemp.intdata[0].bitdata.lowchar = uiRdMsgBuffer[1]&0x00ff;
        fRdTemp.intdata[1].bitdata.highchar = uiRdMsgBuffer[2]&0x00ff;
        fRdTemp.intdata[1].bitdata.lowchar = uiRdMsgBuffer[3]&0x00ff;

        return I2C_SUCCESS;
}


/*************************************************/
/* дeepromĳ��ַ�еĸ�����,ͬʱ����У��             */
/*************************************************/
unsigned char ucWriteFloatDataThree(unsigned int uAddress, ubitfloat fTemp)
{
        unsigned int uiCodeType;
        ubitfloat  ubitfData;

        ubitfData.fd = fTemp.fd;

        uiCodeType = uiI2caWriteData(uAddress, ubitfData);
        uiCodeType = uiCodeType|uiI2caWriteData(uAddress+256, ubitfData);
        uiCodeType = uiCodeType|uiI2caWriteData(uAddress+512, ubitfData);

        if (uiCodeType == I2C_SUCCESS)
        {
                return  RECOK;                                                  /* �ɹ� */
        }
        else
        {
                return  NOVCOM;                                         /* ���ɹ� */
        }
}


/*************************************************/
/* �eepromĳ��ַ�еĸ�����,ͬʱ����У��             */
/*************************************************/
float fReadFloatDataThree(unsigned int uAddress)
{
        ubitfloat ubitfTmp;
        float    ftemp1,ftemp2,ftemp3;

        ucReadEepromOk=0;
        ftemp1 = 0xFFFFFFFF;
        ftemp2 = 0xFFFFFFFF;
        ftemp3 = 0xFFFFFFFF;

        if(uiI2caReadData(uAddress)== I2C_SUCCESS)
        {
                ftemp1=fRdTemp.fd;
        }

        if(uiI2caReadData(uAddress+256)== I2C_SUCCESS)
        {
                ftemp2=fRdTemp.fd;
        }

        if(uiI2caReadData(uAddress+512)== I2C_SUCCESS)
        {
                ftemp3=fRdTemp.fd;
        }

        if((ftemp1==ftemp2)&&(ftemp1==ftemp3))
        {
                return ftemp1;
        }

        else if((ftemp1==ftemp2)&&(ftemp1!=ftemp3))
        {
                ubitfTmp.fd=ftemp1;
                if(uiI2caWriteData(uAddress+512, ubitfTmp)!=I2C_SUCCESS)
                {
                        ucReadEepromOk=1;
                }

                return ftemp1;
        }
        else if((ftemp1!=ftemp2)&&(ftemp2==ftemp3))
        {
                ubitfTmp.fd=ftemp2;
                if(uiI2caWriteData(uAddress, ubitfTmp)!=I2C_SUCCESS)
                {
                        ucReadEepromOk=1;
                }

                return ftemp2;
        }
        else if((ftemp1==ftemp3)&&(ftemp1!=ftemp2))
        {
                ubitfTmp.fd=ftemp1;
                if(uiI2caWriteData(uAddress+256, ubitfTmp)!=I2C_SUCCESS)
                {
                        ucReadEepromOk=1;
                }

                return ftemp1;
        }
        else
        {
                ucReadEepromOk=1;
                return ftemp1;
        }


}

/************************************************/
/* ����ͨѶ���Ҫдeeprom�ĸ�����*/
/************************************************/
void    vWriteE2PROMSIG(void)
{
        float ftempa;

        if(uiEepromFlag)
        {
                if(uiEepromFlag&0x0001)
                {
                        vWriteFloatDataSig (4,fVacaSampSysa);
                        if(ucWriteNumber==0)
                        {
                                uiEepromFlag=uiEepromFlag&0xfffe;
                        }

                }
                else if(uiEepromFlag&0x0002)
                {
                        vWriteFloatDataSig (8,fVacaSampSysb);
                        if(ucWriteNumber==0)
                        {
                                uiEepromFlag=uiEepromFlag&0xfffd;
                        }
                }

                else if(uiEepromFlag&0x0004)
                {
                        vWriteFloatDataSig (12,fVacbSampSysa);
                        if(ucWriteNumber==0)
                        {
                                uiEepromFlag=uiEepromFlag&0xfffb;
                        }
                }

                else if(uiEepromFlag&0x0008)
                {
                        vWriteFloatDataSig(16,fVacbSampSysb);
                        if(ucWriteNumber==0)
                        {
                                uiEepromFlag=uiEepromFlag&0xfff7;
                        }

                }
                else if(uiEepromFlag&0x0010)
                {
                        vWriteFloatDataSig(20,fVaccSampSysa);
                        if(ucWriteNumber==0)
                        {
                                uiEepromFlag=uiEepromFlag&0xffef;
                        }

                }
                else if(uiEepromFlag&0x0020)
                {
                        vWriteFloatDataSig(24,fVaccSampSysb);
                        if(ucWriteNumber==0)
                        {
                                uiEepromFlag=uiEepromFlag&0xffdf;
                        }

                }

                else if(uiEepromFlag&0x1000)
                {
                        if((uiEpromWrAddr==4)||(uiEpromWrAddr==12)||(uiEpromWrAddr==20))
                        {
                                vWriteFloatDataSig(uiEpromWrAddr,((float)((signed int)uiEpromWrValue))*0.0009765625);
                                if(ucWriteNumber==0)
                                {
                                        uiEepromFlag=uiEepromFlag&0xefff;
                                }

                        }
                        else if((uiEpromWrAddr==8)||(uiEpromWrAddr==16)||(uiEpromWrAddr==24)
                                ||(uiEpromWrAddr==32)||(uiEpromWrAddr==40)||(uiEpromWrAddr==48))
                        {
                                vWriteFloatDataSig(uiEpromWrAddr,((float)((signed int)uiEpromWrValue))*0.0078125);
                                if(ucWriteNumber==0)
                                {
                                        uiEepromFlag=uiEepromFlag&0xefff;

                                        uiEpromRdAddr = uiEpromWrAddr;          // add for input current calibration V1.01, mhp
                                        ftempa=fReadFloatDataThree(uiEpromRdAddr);
                                        if ((ftempa>=(-250))&&(ftempa<=250)&&(ucReadEepromOk==0))
                                        {
                                                uiEpromRdValue = (int)(ftempa*128.0);
                                        }
                                        else
                                        {
                                                uiEpromRdValue=0;
                                        }
                                        uiSendCid=20;
                                        ucScisendFlag = 1;
                                }

                        }
                        else
                        {
                                vWriteFloatDataSig(uiEpromWrAddr,(float)((signed int)uiEpromWrValue));
                                if(ucWriteNumber==0)
                                {
                                        uiEepromFlag=uiEepromFlag&0xefff;

                                        uiEpromRdAddr = uiEpromWrAddr;          // add for input current calibration V1.01, mhp
                                        ftempa=fReadFloatDataThree(uiEpromRdAddr);
                                        if ((ftempa>=800)&&(ftempa<=1300)&&(ucReadEepromOk==0))
                                        {
                                                uiEpromRdValue = (int)(ftempa);
                                        }
                                        else
                                        {
                                                uiEpromRdValue=1024;
                                        }
                                        uiSendCid=20;
                                        ucScisendFlag = 1;
                                }
                        }
                }
        }
}

/*************************************************/
/* дeepromĳ��ַ�еĸ�����   */
/*************************************************/
void    vWriteFloatDataSig(unsigned int uAddress, float fTemp)
{
        ubitfloat  ubitfData;
        unsigned int uiCodeType;

        ubitfData.fd = fTemp;
        ucWriteNumber++;
        if(ucWriteNumber==1)
        {
                uiCodeType = uiI2caWriteData(uAddress, ubitfData);
        }
        else if(ucWriteNumber==2)
        {
                uiCodeType = uiCodeType|uiI2caWriteData(uAddress+256, ubitfData);
        }
        else if(ucWriteNumber==3)
        {
                uiCodeType = uiCodeType|uiI2caWriteData(uAddress+512, ubitfData);
                ucWriteNumber=0;
        }
        else
        {
                ucWriteNumber=0;
        }
}


void vLimitInit()
{
        float    ftemp1,ftemp2;
        unsigned char ucCodeType;
        ubitfloat    ubitfloatftemp1;

        ucCodeType = 0;
        uiVersionNoSw = 103;

        if(uiI2caReadData(0) == I2C_SUCCESS)
        {
                ubitfloatftemp1.lData = fRdTemp.lData;
        }

        if (ubitfloatftemp1.lData == 0x55AA55AA)
        {
                /**********************************************/
                ftemp1=fReadFloatDataThree(4);
                ucCodeType=ucReadEepromOk;
                ftemp2=fReadFloatDataThree(8);
                if ((ftemp1>=0.8)&&(ftemp1<=1.2)&&(ftemp2>=(-40))&&(ftemp2<=40)&&(ucCodeType==0)&&(ucReadEepromOk==0))
                {
                        fVacaSampSysa = ftemp1;
                        fVacaSampSysb = ftemp2;
                }
                else
                {
                        fVacaSampSysa = 0.9392;
                        fVacaSampSysb = 22.64;
                        ucEepromErr=1;
                }
                /**********************************************/
                ftemp1=fReadFloatDataThree(12);
                ucCodeType=ucReadEepromOk;
                ftemp2=fReadFloatDataThree(16);
                if ((ftemp1>=0.8)&&(ftemp1<=1.2)&&(ftemp2>=(-40))&&(ftemp2<=40)&&(ucCodeType==0)&&(ucReadEepromOk==0))
                {
                        fVacbSampSysa = ftemp1;
                        fVacbSampSysb = ftemp2;
                }
                else
                {
                        fVacbSampSysa = 0.935;
                        fVacbSampSysb = 23.68;
                        ucEepromErr=2;
                }
                /**********************************************/
                ftemp1=fReadFloatDataThree(20);
                ucCodeType=ucReadEepromOk;
                ftemp2=fReadFloatDataThree(24);
                if ((ftemp1>=0.8)&&(ftemp1<=1.2)&&(ftemp2>=(-40))&&(ftemp2<=40)&&(ucCodeType==0)&&(ucReadEepromOk==0))
                {
                        fVaccSampSysa = ftemp1;
                        fVaccSampSysb = ftemp2;
                }
                else
                {
                        fVaccSampSysa = 0.937;
                        fVaccSampSysb = 23.21;
                        ucEepromErr=3;
                }

                /**********************************************/
                ftemp1=fReadFloatDataThree(28);
                ucCodeType=ucReadEepromOk;
                ftemp2=fReadFloatDataThree(32);
                if ((ftemp1>=800)&&(ftemp1<=1300)&&(ftemp2>=(-100))&&(ftemp2<=100)&&(ucCodeType==0)&&(ucReadEepromOk==0))
                {

                        Pfcisr.iIaSampSysA=(int)(ftemp1*16);
                        Pfcisr.iIaSampSysB=(int)ftemp2;

                }
                else
                {
                        Pfcisr.iIaSampSysA=16384;
                        Pfcisr.iIaSampSysB=0;
                }
                /**********************************************/

                /**********************************************/
                ftemp1=fReadFloatDataThree(36);
                ucCodeType=ucReadEepromOk;
                ftemp2=fReadFloatDataThree(40);
                if ((ftemp1>=800)&&(ftemp1<=1300)&&(ftemp2>=(-100))&&(ftemp2<=100)&&(ucCodeType==0)&&(ucReadEepromOk==0))
                {
                        Pfcisr.iIbSampSysA=(int)(ftemp1*16);
                        Pfcisr.iIbSampSysB=(int)ftemp2;

                }
                else
                {
                        Pfcisr.iIbSampSysA=16384;
                        Pfcisr.iIbSampSysB=0;
                }
                /**********************************************/
                /**********************************************/
                ftemp1=fReadFloatDataThree(44);
                ucCodeType=ucReadEepromOk;
                ftemp2=fReadFloatDataThree(48);
                if ((ftemp1>=800)&&(ftemp1<=1300)&&(ftemp2>=(-100))&&(ftemp2<=100)&&(ucCodeType==0)&&(ucReadEepromOk==0))
                {
                        Pfcisr.iIcSampSysA=(int)(ftemp1*16);
                        Pfcisr.iIcSampSysB=(int)ftemp2;
                }
                else
                {
                        Pfcisr.iIcSampSysA=16384;
                        Pfcisr.iIcSampSysB=0;
                }
        }
        else
        {
                ubitfloatftemp1.intdata[0].id = 0x55AA;
                ubitfloatftemp1.intdata[1].id = 0x55AA;
                ucCodeType = ucWriteFloatDataThree(0,ubitfloatftemp1);
                if (ucCodeType == NOVCOM)
                {
                        ucCodeType = ucWriteFloatDataThree(0,ubitfloatftemp1);
                }
                fVacaSampSysa = 0.9392;
                fVacaSampSysb = 22.64;
                fVacbSampSysa = 0.935;
                fVacbSampSysb = 23.68;
                fVaccSampSysa = 0.937;
                fVaccSampSysb = 23.21;
                Pfcisr.iIaSampSysA=16384;
                Pfcisr.iIbSampSysA=16384;
                Pfcisr.iIcSampSysA=16384;
                Pfcisr.iIaSampSysB=0;
                Pfcisr.iIbSampSysB=0;
                Pfcisr.iIcSampSysB=0;
        }
}

//===========================================================================
// No more.
//===========================================================================

