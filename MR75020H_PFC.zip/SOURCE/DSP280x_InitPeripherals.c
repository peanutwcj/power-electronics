//#########################################################
//
// FILE:	DSP28_InitPeripherals.c
//
// TITLE:	DSP28 Device Initialization To Default State.
//
//#########################################################
//#########################################################

#define RAM_FUNC_LOAD   0x3EC000    // Source location in Flash
#define RAM_FUNC_LENGTH 0x000080    // Number of 32-bit values to copy
#define RAM_FUNC_RUN    0x008000    // Destination location in RAM

#include "DSP280x_Device.h"

//-------------------------------------------------------------------------
// InitPeripherals:
//-------------------------------------------------------------------------
// The following function initializes the peripherals to a default state.
// It calls each of the peripherals default initialization functions.
// This function should be executed at boot time or on a soft reset.
//
void InitPeripherals(void)
{

//	InitFlash(); 		//czk060906
	
	// Initialize CPU Timers To default State:
	InitCpuTimers();

	// Initialize Event Manager Peripheral To default State:
	InitEPwm();
	
	// Initialize ADC Peripheral To default State:
	InitAdc();
	
	// Initialize SCI Peripherals To default State:
	InitSci();

	// Initializes the I2C To default State:
	InitI2C();
}

//=========================================================
// No more.
//=========================================================
