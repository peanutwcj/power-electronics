//#########################################################
//
// FILE:   DSP280x_EPwm.c
//
// TITLE:  DSP280x ePWM Initialization & Support Functions.
//
//#########################################################
// Running on TMS320LF280xA   PFC part?  h741Au1(1.00)               
// External clock is 20MHz, PLL * 10/2 , CPU-Clock 100 MHz	      
// Date: from May 23, 2005 to Oct 30, 2006  , (C) www & mhp & lsy & lyg
// Version:1.00     Change Date: May 24, 2005 , 
//#########################################################

#include "DSP280x_Device.h"     // DSP280x Headerfile Include File

//---------------------------------------------------------------------------
// InitEPwm: 
//---------------------------------------------------------------------------
// This function initializes the ePWM(s) to a known state.
//
void InitEPwm(void)
{
	// Initialize TZ1/2/3/4
	
	InitTzGpio();  //define I/O to TZ function

	EALLOW;
	          EPwm1Regs.TZSEL.bit.CBC1 = TZ_ENABLE;	//Enable TZ1 as a CBC trip source
	//EPwm1Regs.TZSEL.bit.CBC3 = TZ_ENABLE;	//Enable TZ3 as a CBC trip source
	//EPwm1Regs.TZSEL.bit.CBC4 = TZ_ENABLE;	//Enable TZ4 as a CBC trip source
	          EPwm1Regs.TZSEL.bit.CBC5 = TZ_ENABLE;	//Enable TZ5 as a CBC trip source
	          EPwm1Regs.TZSEL.bit.CBC6 = TZ_ENABLE;	//Enable TZ6 as a CBC trip source
	          EPwm2Regs.TZSEL.bit.CBC1 = TZ_ENABLE;	//Enable TZ1 as a CBC trip source
	//EPwm2Regs.TZSEL.bit.CBC3 = TZ_ENABLE;	//Enable TZ3 as a CBC trip source
	//EPwm2Regs.TZSEL.bit.CBC4 = TZ_ENABLE;	//Enable TZ4 as a CBC trip source
	          EPwm2Regs.TZSEL.bit.CBC5 = TZ_ENABLE;	//Enable TZ5 as a CBC trip source
	          EPwm2Regs.TZSEL.bit.CBC6 = TZ_ENABLE;	//Enable TZ6 as a CBC trip source

	// What do we want the TZ1 and TZ2 to do?
	EPwm1Regs.TZCTL.bit.TZA = TZ_FORCE_LO;	//EPwmxA=Lo state czk060825
	EPwm1Regs.TZCTL.bit.TZB = TZ_FORCE_LO;	//EPwmxB=Lo state czk060825

	EPwm2Regs.TZCTL.bit.TZA = TZ_FORCE_LO;	//EPwmxA=Lo state czk060825
	EPwm2Regs.TZCTL.bit.TZB = TZ_FORCE_LO;	//EPwmxB=Lo state czk060825

	// Enable TZ interrupt
	EPwm1Regs.TZEINT.bit.OST = 0;	//disable

	GpioCtrlRegs.GPAQSEL1.bit.GPIO12 = 1;  // Qualification using 3 samples. (TZ1)	
	//GpioCtrlRegs.GPAQSEL1.bit.GPIO14 = 1;  // Qualification using 3 samples. (TZ3)
	//GpioCtrlRegs.GPAQSEL1.bit.GPIO15 = 1;  // Qualification using 3 samples. (TZ4)
	GpioCtrlRegs.GPAQSEL2.bit.GPIO16 = 1;  // Qualification using 3 samples. (TZ5)
	GpioCtrlRegs.GPAQSEL2.bit.GPIO17 = 1;  // Qualification using 3 samples. (TZ6)
	EDIS;


	// Initialize ePWM1/2/3/4/5/6

	InitEPwmGpio();

	EALLOW;
	SysCtrlRegs.PCLKCR0.bit.TBCLKSYNC = 0;      // Stop all the TB clocks
	EDIS;

	//////mhping   060906////////////
	// force all PWM to low
	EPwm1Regs.AQSFRC.bit.RLDCSF = 0;	//Active Register Reload from shadow options
	EPwm2Regs.AQSFRC.bit.RLDCSF = 0;	//Load on event CTR=0	
	EPwm3Regs.AQSFRC.bit.RLDCSF = 0;

	EPwm1Regs.AQCSFRC.all = 0x05;		//PWM1A,PWM1B force low
	EPwm2Regs.AQCSFRC.all = 0x05;		//PWM2A,PWM2B force low�
	//EPwm3Regs.AQCSFRC.all = 0x05;		//PWM3A,FAN force low�czk060906

	//////mhping 060906////////////
	
	//ePWM1 setup   
	EPwm1Regs.TBPRD = EPWM1_TIMER_TBPRD; /// //1/(11.12us*2)==45kHz
	EPwm1Regs.TBPHS.half.TBPHS = 0;		
	EPwm1Regs.TBCTL.bit.CTRMODE = TB_COUNT_UPDOWN;    // Count up/dn
	// Allow each timer to be sync'ed
	EPwm1Regs.TBCTL.bit.PHSEN = TB_DISABLE;		
	// Setup Sync
	EPwm1Regs.TBCTL.bit.SYNCOSEL = TB_CTR_ZERO;  
	//TBCLK=SYSCLKOUT/(HSPCLKDIV * CLKDIV)=SYSCLKOUT
	EPwm1Regs.TBCTL.bit.CLKDIV = TB_DIV1;		
	EPwm1Regs.TBCTL.bit.HSPCLKDIV = TB_DIV1;	

	/*
	/////////mhping060906//////
	EPwm1Regs.ETSEL.bit.INTSEL = ET_CTR_PRD;			// Select INT on Zero event
	EPwm1Regs.ETSEL.bit.INTEN = EPWM1_INT_ENABLE;		// Enable INT
	EPwm1Regs.ETPS.bit.INTPRD = ET_1ST;				// Generate INT on 1st event
	/////////mhping060906//////
	*/

	/////////lsyang diff//////////
	EPwm1Regs.TBCTL.bit.PRDLD = TB_SHADOW;		
	EPwm1Regs.TBCTL.bit.PHSDIR = TB_UP;			
	

	
	//EPwm1Regs.ETSEL.bit.INTSEL = ET_CTR_ZERO;     // Select INT on Zero event
	//EPwm1Regs.ETSEL.bit.INTEN = EPWM1_INT_ENABLE;  // Enable INT
	//EPwm1Regs.ETPS.bit.INTPRD = ET_1ST;           // Generate INT on 1st event
	/*EPwm1Regs.ETSEL.bit.SOCAEN = 0;				//Enables SOCA pulse
	EPwm1Regs.ETSEL.bit.SOCASEL = ET_CTR_ZERO;			//Enable CNTR = zero event
	EPwm1Regs.ETPS.bit.SOCAPRD = ET_1ST;        // Generate pulse on 1st event 
	EPwm1Regs.ETSEL.bit.SOCBEN = 0;				//Enables SOCA pulse
	EPwm1Regs.ETSEL.bit.SOCBSEL = ET_CTR_ZERO;			//Enable CNTR = zero event
	EPwm1Regs.ETPS.bit.SOCBPRD = ET_1ST;        // Generate pulse on 1st event */

	// for PWM  wave
	EPwm1Regs.CMPA.half.CMPA = EPWM1_MIN_CMPA;	
	EPwm1Regs.CMPB = EPWM1_MIN_CMPB;			
	/////////lsyang diff//////////

	EPwm1Regs.CMPCTL.bit.LOADAMODE = CC_CTR_ZERO_PRD;	
	EPwm1Regs.CMPCTL.bit.LOADBMODE = CC_CTR_ZERO_PRD;
	/////////lsyang diff//////////
	EPwm1Regs.CMPCTL.bit.SHDWAMODE = CC_SHADOW;		
	EPwm1Regs.CMPCTL.bit.SHDWBMODE = CC_SHADOW;	
	/////////lsyang diff//////////
	EPwm1Regs.AQCTLA.bit.CAU = AQ_CLEAR;	// Set PWM1A on event A, up count
	EPwm1Regs.AQCTLA.bit.CAD = AQ_SET;	// Clear PWM1A on event A, down count
	EPwm1Regs.AQCTLB.bit.CBU = AQ_CLEAR;	// Set PWM1A on event A, up count
	EPwm1Regs.AQCTLB.bit.CBD = AQ_SET;	// Clear PWM1A on event A, down count

     /*
	 /////////////mhping////////////
	/////deadband//////////
	EPwm1Regs.DBCTL.bit.OUT_MODE = DBB_ENABLE;
		EPwm1Regs.DBCTL.bit.POLSEL = DB_ACTV_HI;
		EPwm1Regs.DBRED = 19;      //only for 2812      BJG
	
		EPwm1Regs.CMPA.half.CMPA = EPwm1Regs.DBRED;
		EPwm1Regs.CMPB = EPWM1_MIN_CMPB;              
	//////////HRPWM//////////////////
		EALLOW;
		EPwm1Regs.HRCNFG.bit.HRLOAD = HR_CTR_ZERO;
		EPwm1Regs.HRCNFG.bit.EDGMODE = HR_FEP;
		EPwm1Regs.HRCNFG.bit.CTLMODE = HR_CMP;
		//(frac(PWMDuty*PWMperiod)*MEP_SF) << 8) + 0180h
		//MEP_SF = (10ns/180ps) = 55
		//eg. (frac(0.2016*500)*55<<8)+180h 
		//CMPA = 100, CMPAHR=0.8*55<<8+180h =44<<8+180h = 2D80h
		EPwm1Regs.CMPA.half.CMPAHR = 0x0180;
		EDIS;

	 /////////////mhping////////////
     */
	//EALLOW;
	//EPwm1Regs.HRCNFG.bit.HRLOAD = HR_CTR_ZERO;
	//EPwm1Regs.HRCNFG.bit.EDGMODE = HR_BEP;
	//EPwm1Regs.HRCNFG.bit.CTLMODE = HR_CMP;
	//(frac(PWMDuty*PWMperiod)*MEP_SF) << 8) + 0180h
	//MEP_SF = (10ns/180ps) = 55
	//eg. (frac(0.2016*500)*55<<8)+180h 
	//CMPA = 100, CMPAHR=0.8*55<<8+180h =44<<8+180h = 2D80h
	//EPwm1Regs.CMPA.half.CMPAHR = 0x2D80;
	//EPwm1Regs.TBPHS.half.TBPHSHR = 0x2D80;
	//EPwm1Regs.HRCNFG.bit.CTLMODE = HR_PHS;
	//EDIS;
	//EPwm1Regs.AQCSFRC.all = 0x05;		//PWM1A,PWM1B force low
	//EPwm2Regs.AQCSFRC.all = 0x05;		//PWM2A,PWM2B force low 

	//ePWM2 setup
	// Setup Sync
	EPwm2Regs.TBCTL.bit.SYNCOSEL = TB_SYNC_IN;  
	// Allow each timer to be sync'ed
	EPwm2Regs.TBCTL.bit.PHSEN = TB_ENABLE;	
	EPwm2Regs.TBPHS.half.TBPHS = 2;		
   
	EPwm2Regs.TBPRD = EPWM1_TIMER_TBPRD;
	EPwm2Regs.TBCTL.bit.CTRMODE = TB_COUNT_UPDOWN;    // Count up/dn

	//TBCLK=SYSCLKOUT/(HSPCLKDIV * CLKDIV)=SYSCLKOUT
	EPwm2Regs.TBCTL.bit.CLKDIV = TB_DIV1;		//Timebase clock pre-scale
	EPwm2Regs.TBCTL.bit.HSPCLKDIV = TB_DIV1;	
	

	EPwm2Regs.TBCTL.bit.PRDLD = TB_SHADOW;
	EPwm2Regs.TBCTL.bit.PHSDIR = TB_UP;			//Phase Direction
	
	/////////set ADC start of conversion  trip/////////
	EPwm2Regs.ETSEL.bit.INTSEL = ET_CTR_ZERO;     // Select INT on Zero event
	EPwm2Regs.ETSEL.bit.INTEN = 0;  
	//EPwm2Regs.ETPS.bit.INTPRD = ET_1ST;           // Generate INT on 1st event
	EPwm2Regs.ETSEL.bit.SOCAEN = 0;				//Does not Enables SOCA pulse(ENable ADC SOCs )
	//EPwm2Regs.ETSEL.bit.SOCASEL = ET_CTR_ZERO;			//Enable CNTR = zero event
	//EPwm2Regs.ETPS.bit.SOCAPRD = ET_1ST;        // Generate pulse on 1st event 

	// for PWM  wave
	EPwm2Regs.CMPA.half.CMPA = EPWM1_MIN_CMPA;		
	EPwm2Regs.CMPB = EPWM1_MIN_CMPB;				
	EPwm2Regs.CMPCTL.bit.LOADAMODE = CC_CTR_ZERO_PRD;
	EPwm2Regs.CMPCTL.bit.LOADBMODE = CC_CTR_ZERO_PRD;
	EPwm2Regs.CMPCTL.bit.SHDWAMODE = CC_SHADOW;
	EPwm2Regs.CMPCTL.bit.SHDWBMODE = CC_SHADOW;
	EPwm2Regs.AQCTLA.bit.CAU = AQ_CLEAR;	// Set PWM1A on event A, up count
	EPwm2Regs.AQCTLA.bit.CAD = AQ_SET;	// Clear PWM1A on event A, down count
	EPwm2Regs.AQCTLB.bit.CBU = AQ_CLEAR;	// Set PWM1A on event A, up count
	EPwm2Regs.AQCTLB.bit.CBD = AQ_SET;	// Clear PWM1A on event A, down count
	//EALLOW;
	//EPwm2Regs.HRCNFG.bit.HRLOAD = HR_CTR_ZERO;
	//EPwm2Regs.HRCNFG.bit.EDGMODE = HR_BEP;
	//EPwm2Regs.HRCNFG.bit.CTLMODE = HR_CMP;
	//(frac(PWMDuty*PWMperiod)*MEP_SF) << 8) + 0180h
	//MEP_SF = (10ns/180ps) = 55
	//eg. (frac(0.2016*500)*55<<8)+180h 
	//CMPA = 100, CMPAHR=0.8*55<<8+180h =44<<8+180h = 2D80h
	//EPwm2Regs.CMPA.half.CMPAHR = 0x2D80;
	//EDIS;


	//ePWM3 setup
	// Setup Sync
	EPwm3Regs.TBCTL.bit.SYNCOSEL = TB_SYNC_DISABLE;  // Pass through 

	// Allow each timer to be sync'ed
	EPwm3Regs.TBCTL.bit.PHSEN = TB_ENABLE;	
	EPwm3Regs.TBPHS.half.TBPHS = 0;
   
	EPwm3Regs.TBPRD = 556;//415---120k//500---100k//556--90K
	EPwm3Regs.TBCTL.bit.CTRMODE = TB_COUNT_UPDOWN;    // Count up/dn
	EPwm3Regs.TBCTL.bit.PRDLD = TB_SHADOW;
	EPwm3Regs.TBCTL.bit.PHSDIR = TB_UP;			//Phase Direction
	//TBCLK=SYSCLKOUT/(HSPCLKDIV * CLKDIV)=SYSCLKOUT
	EPwm3Regs.TBCTL.bit.CLKDIV = TB_DIV1;		//Timebase clock pre-scale
	EPwm3Regs.TBCTL.bit.HSPCLKDIV = TB_DIV1;	//High speed time pre-scale


	EPwm3Regs.ETSEL.bit.INTSEL = ET_CTR_ZERO;     // Select INT on Zero event
	EPwm3Regs.ETSEL.bit.INTEN = EPWM1_INT_ENABLE;  
	EPwm3Regs.ETPS.bit.INTPRD = ET_1ST;           // Generate INT on 1st event
	
	/////lsy///////
	//EPwm3Regs.ETSEL.bit.SOCAEN = 0;				//disables SOCA pulse
	/////lsy/////////
	EPwm3Regs.ETSEL.bit.SOCAEN = 1;				//Eables SOCA pulse
	/////change by czk060906 let adc start early

	EPwm3Regs.ETSEL.bit.SOCASEL = ET_CTR_ZERO;			//Enable CNTR = zero event
	EPwm3Regs.ETPS.bit.SOCAPRD = ET_1ST;        // Generate pulse on 1st event 
	EPwm3Regs.ETSEL.bit.SOCBEN = 0;				//disables SOCB pulse
	EPwm3Regs.ETSEL.bit.SOCBSEL = ET_CTR_ZERO;			//Enable CNTR = zero event
	EPwm3Regs.ETPS.bit.SOCBPRD = ET_1ST;        // Generate pulse on 1st event 
	
	// for PWM  wave
	EPwm3Regs.CMPA.half.CMPA = EPWM1_MIN_CMPA;
	EPwm3Regs.CMPB = EPWM1_MIN_CMPB;
	EPwm3Regs.CMPCTL.bit.LOADAMODE = CC_CTR_ZERO_PRD;
	EPwm3Regs.CMPCTL.bit.LOADBMODE = CC_CTR_ZERO_PRD;
	EPwm3Regs.CMPCTL.bit.SHDWAMODE = CC_SHADOW;
	EPwm3Regs.CMPCTL.bit.SHDWBMODE = CC_SHADOW;
	EPwm3Regs.AQCTLA.bit.CAU = AQ_CLEAR;	// Set PWM1A on event A, up count
	EPwm3Regs.AQCTLA.bit.CAD = AQ_SET;	// Clear PWM1A on event A, down count
	EPwm3Regs.AQCTLB.bit.CBU = AQ_CLEAR;	// Set PWM1A on event A, up count
	EPwm3Regs.AQCTLB.bit.CBD = AQ_SET;	// Clear PWM1A on event A, down count
	//EALLOW;
	//EPwm3Regs.HRCNFG.bit.HRLOAD = HR_CTR_ZERO;
	//EPwm3Regs.HRCNFG.bit.EDGMODE = HR_BEP;
	//EPwm3Regs.HRCNFG.bit.CTLMODE = HR_CMP;
	//(frac(PWMDuty*PWMperiod)*MEP_SF) << 8) + 0180h
	//MEP_SF = (10ns/180ps) = 55
	//eg. (frac(0.2016*500)*55<<8)+180h 
	//CMPA = 100, CMPAHR=0.8*55<<8+180h =44<<8+180h = 2D80h
	//EPwm3Regs.CMPA.half.CMPAHR = 0x2D80;
	//EDIS;
	
	//EALLOW;
	//SysCtrlRegs.PCLKCR0.bit.TBCLKSYNC = 1;         // Start all the timers synced
	//EDIS;

	///////czk060906//////////
	EALLOW;
	SysCtrlRegs.PCLKCR0.bit.TBCLKSYNC = 1;         // Start all the timers synced
	EDIS;
	///////czk060906//////////
}

//---------------------------------------------------------------------------
// Example: InitEPwmGpio: 
//---------------------------------------------------------------------------
// This function initializes GPIO pins to function as ePWM pins
//
// Each GPIO pin can be configured as a GPIO pin or up to 3 different
// peripheral functional pins. By default all pins come up as GPIO
// inputs after reset.  
// 

void InitEPwmGpio(void)
{
   InitEPwm1Gpio();
   InitEPwm2Gpio();
   InitEPwm3Gpio();
   //InitEPwm6Gpio();
   //InitEPwm5Gpio();
}

void InitEPwm1Gpio(void)
{
   EALLOW;
   
	/* Enable internal pull-up for the selected pins */
	// Pull-ups can be enabled or disabled by the user. 
	// This will enable the pullups for the specified pins.
	// Comment out other unwanted lines.

    GpioCtrlRegs.GPAPUD.bit.GPIO0 = 0;    // Enable pull-up on GPIO0 (EPWM1A)
    GpioCtrlRegs.GPAPUD.bit.GPIO1 = 0;    // Enable pull-up on GPIO1 (EPWM1B)   
   
	/* Configure ePWM-1 pins using GPIO regs*/
	// This specifies which of the possible GPIO pins will be ePWM1 functional pins.
	// Comment out other unwanted lines.

    GpioCtrlRegs.GPAMUX1.bit.GPIO0 = 1;   // Configure GPIO0 as EPWM1A
    GpioCtrlRegs.GPAMUX1.bit.GPIO1 = 1;   // Configure GPIO1 as EPWM1B
   
    EDIS;
}

void InitEPwm2Gpio(void)
{
   EALLOW;
	
	/* Enable internal pull-up for the selected pins */
	// Pull-ups can be enabled or disabled by the user. 
	// This will enable the pullups for the specified pins.
	// Comment out other unwanted lines.

    GpioCtrlRegs.GPAPUD.bit.GPIO2 = 0;    // Enable pull-up on GPIO2 (EPWM2A)
    GpioCtrlRegs.GPAPUD.bit.GPIO3 = 0;    // Enable pull-up on GPIO3 (EPWM3B)

	/* Configure ePWM-2 pins using GPIO regs*/
	// This specifies which of the possible GPIO pins will be ePWM2 functional pins.
	// Comment out other unwanted lines.

    GpioCtrlRegs.GPAMUX1.bit.GPIO2 = 1;   // Configure GPIO2 as EPWM2A
    GpioCtrlRegs.GPAMUX1.bit.GPIO3 = 1;   // Configure GPIO3 as EPWM2B
   
    EDIS;
}

void InitEPwm3Gpio(void)
{
   EALLOW;
   
	/* Enable internal pull-up for the selected pins */
	// Pull-ups can be enabled or disabled by the user. 
	// This will enable the pullups for the specified pins.
	// Comment out other unwanted lines.

    GpioCtrlRegs.GPAPUD.bit.GPIO4 = 0;    // Enable pull-up on GPIO4 (EPWM3A)
    GpioCtrlRegs.GPAPUD.bit.GPIO5 = 0;    // Enable pull-up on GPIO5 (EPWM3B)
       
	/* Configure ePWM-3 pins using GPIO regs*/
	// This specifies which of the possible GPIO pins will be ePWM3 functional pins.
	// Comment out other unwanted lines.

    GpioCtrlRegs.GPAMUX1.bit.GPIO4 = 0;   // Configure GPIO4 as EPWM3A
    GpioCtrlRegs.GPAMUX1.bit.GPIO5 = 1;   // Configure GPIO5 as EPWM3B
	
    EDIS;
}


//---------------------------------------------------------------------------
// Example: InitEPwmSyncGpio: 
//---------------------------------------------------------------------------
// This function initializes GPIO pins to function as ePWM Synch pins
//

void InitEPwmSyncGpio(void)
{

   EALLOW;

	/* Configure EPWMSYNCI  */
   
	/* Enable internal pull-up for the selected pins */
	// Pull-ups can be enabled or disabled by the user. 
	// This will enable the pullups for the specified pins.
	// Comment out other unwanted lines.

   GpioCtrlRegs.GPAPUD.bit.GPIO6 = 0;    // Enable pull-up on GPIO6 (EPWMSYNCI)
	// GpioCtrlRegs.GPBPUD.bit.GPIO32 = 0;   // Enable pull-up on GPIO32 (EPWMSYNCI)    

	/* Set qualification for selected pins to asynch only */
	// This will select synch to SYSCLKOUT for the selected pins.
	// Comment out other unwanted lines.

   GpioCtrlRegs.GPAQSEL1.bit.GPIO6 = 0;   // Synch to SYSCLKOUT GPIO6 (EPWMSYNCI)
	// GpioCtrlRegs.GPBQSEL1.bit.GPIO32 = 0;  // Synch to SYSCLKOUT GPIO32 (EPWMSYNCI)    

	/* Configure EPwmSync pins using GPIO regs*/
	// This specifies which of the possible GPIO pins will be EPwmSync functional pins.
	// Comment out other unwanted lines.   

   GpioCtrlRegs.GPAMUX1.bit.GPIO6 = 2;    // Enable pull-up on GPIO6 (EPWMSYNCI)
	// GpioCtrlRegs.GPBMUX1.bit.GPIO32 = 2;   // Enable pull-up on GPIO32 (EPWMSYNCI)    



	/* Configure EPWMSYNC0  */

	/* Enable internal pull-up for the selected pins */
	// Pull-ups can be enabled or disabled by the user. 
	// This will enable the pullups for the specified pins.
	// Comment out other unwanted lines.

	// GpioCtrlRegs.GPAPUD.bit.GPIO6 = 0;    // Enable pull-up on GPIO6 (EPWMSYNC0)
   GpioCtrlRegs.GPBPUD.bit.GPIO33 = 0;   // Enable pull-up on GPIO33 (EPWMSYNC0)    

	// GpioCtrlRegs.GPAMUX1.bit.GPIO6 = 3;    // Enable pull-up on GPIO6 (EPWMSYNC0)
   GpioCtrlRegs.GPBMUX1.bit.GPIO33 = 2;   // Enable pull-up on GPIO33 (EPWMSYNC0)    

}


//---------------------------------------------------------------------------
// Example: InitTzGpio: 
//---------------------------------------------------------------------------
// This function initializes GPIO pins to function as Trip Zone (TZ) pins
//
// Each GPIO pin can be configured as a GPIO pin or up to 3 different
// peripheral functional pins. By default all pins come up as GPIO
// inputs after reset.  
// 

void InitTzGpio(void)
{
   EALLOW;
   
	/* Enable internal pull-up for the selected pins */
	// Pull-ups can be enabled or disabled by the user. 
	// This will enable the pullups for the specified pins.
	// Comment out other unwanted lines.
   GpioCtrlRegs.GPAPUD.bit.GPIO12 = 0;    

   //GpioCtrlRegs.GPAPUD.bit.GPIO14 = 0;    // Enable pull-up on GPIO14 (TZ3)
   //GpioCtrlRegs.GPAPUD.bit.GPIO15 = 0;    // Enable pull-up on GPIO15 (TZ4)
   GpioCtrlRegs.GPAPUD.bit.GPIO16 = 0;   
   GpioCtrlRegs.GPAPUD.bit.GPIO17 = 0;    

   
	/* Set qualification for selected pins to asynch only */
	// Inputs are synchronized to SYSCLKOUT by default.  
	// This will select asynch (no qualification) for the selected pins.
	// Comment out other unwanted lines.

   GpioCtrlRegs.GPAQSEL1.bit.GPIO12 = 1;  

   //GpioCtrlRegs.GPAQSEL1.bit.GPIO14 = 1;  // Asynch input GPIO14 (TZ3)
   //GpioCtrlRegs.GPAQSEL1.bit.GPIO15 = 1;  // Asynch input GPIO15 (TZ4)
   GpioCtrlRegs.GPAQSEL2.bit.GPIO16 = 1;  
   GpioCtrlRegs.GPAQSEL2.bit.GPIO17 = 1;  
   
	/* Configure TZ pins using GPIO regs*/
	// This specifies which of the possible GPIO pins will be TZ functional pins.
	// Comment out other unwanted lines.   
   GpioCtrlRegs.GPAMUX1.bit.GPIO12 = 1;  // Configure GPIO12 as TZ1

   //GpioCtrlRegs.GPAMUX1.bit.GPIO14 = 1;  // Configure GPIO14 as TZ3
   //GpioCtrlRegs.GPAMUX1.bit.GPIO15 = 1;  // Configure GPIO15 as TZ4
   GpioCtrlRegs.GPAMUX2.bit.GPIO16 = 3;  // Configure GPIO16 as TZ5
   GpioCtrlRegs.GPAMUX2.bit.GPIO17 = 3;  // Configure GPIO17 as TZ6

   EDIS;
}



//===========================================================================
// End of file.
//===========================================================================
